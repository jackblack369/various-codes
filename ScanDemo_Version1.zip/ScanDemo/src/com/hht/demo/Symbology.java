package com.hht.demo;

import android.app.Activity;
import android.content.Intent;
import android.util.Log;

public class Symbology {
	
	private String name = "" ;
	private boolean checked = false ;
	private String IntentEnable = "";
	private String IntentDisable = "";
	private Activity app;
	
	public Symbology() {}
	
	public Symbology( String name ){
		this.name = name ;
		this.checked = false;
	}
	
	public Symbology( String name, boolean checked ) {
		this.name = name ;
		this.checked = checked ;
	}
	
	public Symbology(Activity app,  String name, boolean checked, String IntentEnable, String IntentDisable ) {
		this.app = app;
		this.name = name ;
		this.checked = checked ;
		this.IntentEnable = IntentEnable;
		this.IntentDisable = IntentDisable;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public boolean isChecked() {
		return checked;
	}
	
	public void setChecked(boolean checked) {
		this.checked = checked;
		SetDecoder();
	}
	
	public String toString() {
		return name ; 
	}
	
	public void toggleChecked() {
		checked = !checked ;
		SetDecoder();
	}
	
	private void SetDecoder()
	{
		if (checked)
			EnableDecoder();
		else
			DisableDecoder();
	}
	
	 public void EnableDecoder(){
		  Log.v("CodeSetting", "EnableDecoder");
		  Intent i = new Intent();
		  i.setAction(com.hht.emdk.datawedge.SCANNERINPUTPLUGIN);
		  i.putExtra(com.hht.emdk.datawedge.EXTRA_PARAMETER, IntentEnable);
		  app.sendBroadcast(i);
	  }
	  
	  public void DisableDecoder(){
		  Log.v("CodeSetting", "DisableDecoder");
		  Intent i = new Intent();
		  i.setAction(com.hht.emdk.datawedge.SCANNERINPUTPLUGIN);
		  i.putExtra(com.hht.emdk.datawedge.EXTRA_PARAMETER, IntentDisable);
		  app.sendBroadcast(i);
	  }
}
