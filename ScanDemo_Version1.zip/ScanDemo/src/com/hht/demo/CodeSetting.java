package com.hht.demo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.TextView;

public class CodeSetting extends Activity{
	
	//private Activity MainActivity;

  
  private ListView mainListView ;
  public Symbology[] decoders ;
  private ArrayAdapter<Symbology> listAdapter ;
  

 
  private String strupca, strupce0, strupce1, strean8, strean13;
  private String strcode128, strcode39, strcode93, strcode11, stri2of5;
  private String strd2of5, strcodabar, strmsi, strchinese2of5, strkorean3of5;
  private String strmatrix2of5, struspostnet, strusplanet, strukpostal, strjapanesepostal;
  private String straustralianpostal, strdutchpostal, strusps4cb, strus4state, strgs1dataBar;
  private String strgs1dataBarlimited, strgs1dataBarX, strcompositeab, strcompositec, strpdf417;
  private String strmicroPDF, strdatamatrix, strmaxicode, strqrcode, strmicroQR;
  private String straztec, strtrioptic39, strdiscrete2of5, strtlc39;
  
  private CheckBox chUPCA = null;
  
  boolean bCODE39Enabled = false;
  boolean bCODABAREnabled = false;
  boolean bCODE128Enabled = false;
  boolean bD25Enabled = false;
  boolean bI25Enabled = false;
  boolean bCODE93Enabled = false;
  boolean bUPCAEnabled = false;
  boolean bUPCEEnabled = false;
  boolean bEAN8Enabled = false;
  boolean bEAN8ZeroExtendEnabled = false;
  boolean bEAN13Enabled = false;
  boolean bCODE11Enabled = false;
  boolean bMSIEnabled = false;
  boolean bEAN128Enabled = false;
  boolean bUPCE1Enabled = false;
  boolean bTRIOPTICEnabled = false;
  boolean bISBT_128Enabled = false;
  boolean bRSS_14Enabled = false;
  boolean bRSS_LIMEnabled = false;
  boolean bRSS_EXPEnabled = false;
  boolean bCHINAEnabled = false;
  boolean bMATRIX_25Enabled = false;
  
  boolean bC39_Cnv32_Enabled = false;
  boolean bC39_C32Prefix_Enabled = false;
  boolean bC39_ChkVerify_Enabled = false;
  boolean bC39_TxChkDgt_Enabled = false;
  boolean bC39_FullASCII_Enabled = false;
  
  boolean bCB_CLSI_Enabled = false;
  boolean bCB_NOTIS_Enabled = false;  
  
  boolean bC11_ChkVerify_Enabled = false;
  boolean bC11_TxChkDgt_Enabled = false;	  
  
  boolean bI25_CnvEAN13_Enabled = false;
  boolean bI25_ChkVerify_Enabled = false;
  boolean bI25_TxChkDgt_Enabled = false;
  
  boolean bBOOKLANDEnabled = false;
  
  boolean bUPCA_TxChkDgt_Enabled = false;
  boolean bUPCE_TxChkDgt_Enabled = false;
  boolean bUPCE1_TxChkDgt_Enabled = false;

  boolean bUPCA_Preamble_Enabled = false;
  boolean bUPCE_Preamble_Enabled = false;
  boolean bUPCE1_Preamble_Enabled = false;
  
  boolean bUPCE_CnvUPCA_Enabled = false;
  boolean bUPCE1_CnvUPCA_Enabled = false;  
  
  private BarcodeSettingBroadcastReceiver intentScannerSettingReceiver = new BarcodeSettingBroadcastReceiver();

 
  public class BarcodeSettingBroadcastReceiver extends BroadcastReceiver {
	    @Override
	    public void onReceive(Context context, Intent intent) {
	    	
	    	bCODE39Enabled = intent.getBooleanExtra(com.hht.emdk.datawedge.CODE39_ENABLED, false);
	    	bCODABAREnabled = intent.getBooleanExtra(com.hht.emdk.datawedge.CODABAR_ENABLED, false);
	    	bCODE128Enabled = intent.getBooleanExtra(com.hht.emdk.datawedge.CODE128_ENABLED, false);
	    	bD25Enabled = intent.getBooleanExtra(com.hht.emdk.datawedge.D25_ENABLED, false);
	    	bI25Enabled = intent.getBooleanExtra(com.hht.emdk.datawedge.I25_ENABLED, false);
	    	bCODE93Enabled = intent.getBooleanExtra(com.hht.emdk.datawedge.CODE93_ENABLED, false);
	    	bUPCAEnabled = intent.getBooleanExtra(com.hht.emdk.datawedge.UPCA_ENABLED, false);
	    	bUPCEEnabled = intent.getBooleanExtra(com.hht.emdk.datawedge.UPCE_ENABLED, false);
	    	bEAN8Enabled  = intent.getBooleanExtra(com.hht.emdk.datawedge.EAN8_ENABLED, false);
	    	bEAN8ZeroExtendEnabled  = intent.getBooleanExtra(com.hht.emdk.datawedge.EAN8_ZEROEXTEND_ENABLED, false);
	    	bEAN13Enabled = intent.getBooleanExtra(com.hht.emdk.datawedge.EAN13_ENABLED, false);
	    	bCODE11Enabled = intent.getBooleanExtra(com.hht.emdk.datawedge.CODE11_ENABLED, false);
	    	bMSIEnabled = intent.getBooleanExtra(com.hht.emdk.datawedge.MSI_ENABLED, false);
	    	bEAN128Enabled = intent.getBooleanExtra(com.hht.emdk.datawedge.EAN128_ENABLED, false);
	    	bUPCE1Enabled = intent.getBooleanExtra(com.hht.emdk.datawedge.UPCE1_ENABLED, false);
	    	bTRIOPTICEnabled = intent.getBooleanExtra(com.hht.emdk.datawedge.TRIOPTIC_ENABLED, false);
	    	bISBT_128Enabled = intent.getBooleanExtra(com.hht.emdk.datawedge.ISBT_128_ENABLED, false);
	    	bRSS_14Enabled = intent.getBooleanExtra(com.hht.emdk.datawedge.RSS_14_ENABLED, false);
	    	bRSS_LIMEnabled = intent.getBooleanExtra(com.hht.emdk.datawedge.RSS_LIM_ENABLED, false);
	    	bRSS_EXPEnabled = intent.getBooleanExtra(com.hht.emdk.datawedge.RSS_EXP_ENABLED, false);
	    	bCHINAEnabled = intent.getBooleanExtra(com.hht.emdk.datawedge.CHINA_ENABLED, false);
    	
	    	bC39_Cnv32_Enabled = intent.getBooleanExtra(com.hht.emdk.datawedge.CNVT_CODE39_TO_32_ENABLED, false);
	    	bC39_C32Prefix_Enabled = intent.getBooleanExtra(com.hht.emdk.datawedge.CODE32_PREFIX_ENABLED, false);
	    	bC39_ChkVerify_Enabled = intent.getBooleanExtra(com.hht.emdk.datawedge.CODE39_VER_CHK_DGT_ENABLED , false);
	    	bC39_TxChkDgt_Enabled = intent.getBooleanExtra(com.hht.emdk.datawedge.CODE39_REPORT_CHK_DGT_ENABLED, false);
	    	bC39_FullASCII_Enabled = intent.getBooleanExtra(com.hht.emdk.datawedge.CODE39_FULL_ASCII_ENABLED, false);
	    	
	    	bCB_CLSI_Enabled = intent.getBooleanExtra(com.hht.emdk.datawedge.CODABAR_CLSI_ENABLED, false);
	    	bCB_NOTIS_Enabled = intent.getBooleanExtra(com.hht.emdk.datawedge.CODABAR_NOTIS_ENABLED, false);
	    	
	    	bC11_ChkVerify_Enabled = intent.getBooleanExtra(com.hht.emdk.datawedge.CODE11_VER_CHK_DGT_ENABLED, false);
	    	bC11_TxChkDgt_Enabled = intent.getBooleanExtra(com.hht.emdk.datawedge.CODE11_REPORT_CHK_DGT_ENABLED, false);
	    	
	    	bI25_CnvEAN13_Enabled = intent.getBooleanExtra(com.hht.emdk.datawedge.CNVT_I25_TO_EAN13_ENABLED, false);
	    	bI25_ChkVerify_Enabled = intent.getBooleanExtra(com.hht.emdk.datawedge.I25_VER_CHK_DGT_ENABLED, false);
	    	bI25_TxChkDgt_Enabled = intent.getBooleanExtra(com.hht.emdk.datawedge.I25_REPORT_CHK_DGT_ENABLED, false);
	    	
	    	bBOOKLANDEnabled = intent.getBooleanExtra(com.hht.emdk.datawedge.BOOKLAND_ISBN_ENABLED, false);
	    	
	    	bUPCA_TxChkDgt_Enabled = intent.getBooleanExtra(com.hht.emdk.datawedge.UPCA_REPORT_CHK_DGT_ENABLED, false);
	    	bUPCE_TxChkDgt_Enabled = intent.getBooleanExtra(com.hht.emdk.datawedge.UPCE_REPORT_CHK_DGT_ENABLED, false);
	    	bUPCE1_TxChkDgt_Enabled = intent.getBooleanExtra(com.hht.emdk.datawedge.UPCE1_REPORT_CHK_DGT_ENABLED, false);
	    	
	    	bUPCA_Preamble_Enabled = intent.getBooleanExtra(com.hht.emdk.datawedge.UPCA_PREAMBLE_ENABLED, false);
	    	bUPCE_Preamble_Enabled = intent.getBooleanExtra(com.hht.emdk.datawedge.UPCE_PREAMBLE_ENABLED, false);
	    	bUPCE1_Preamble_Enabled = intent.getBooleanExtra(com.hht.emdk.datawedge.UPCE1_PREAMBLE_ENABLED, false);
	    	
	    	bUPCE_CnvUPCA_Enabled = intent.getBooleanExtra(com.hht.emdk.datawedge.CNVT_UPCE_TO_UPCA_ENABLED, false);
	    	bUPCE1_CnvUPCA_Enabled = intent.getBooleanExtra(com.hht.emdk.datawedge.CNVT_UPCE1_TO_UPCA_ENABLED, false);

	    	CodeSettingScreen();
	    }
  }
  
  //------------------------------------------------------
  // Called with the activity is first created.
  @Override
  public void onCreate(Bundle savedInstanceState)
  {		
	  super.onCreate(savedInstanceState);
	  
	  IntentFilter intentFilter = new IntentFilter(com.hht.emdk.datawedge.CODE_PARAMETER);
	  registerReceiver(intentScannerSettingReceiver, intentFilter);
	  
	  Intent i = new Intent();
	  i.setAction(com.hht.emdk.datawedge.SCANNERINPUTPLUGIN);
	  i.putExtra(com.hht.emdk.datawedge.EXTRA_PARAMETER, com.hht.emdk.datawedge.SCANNERSETTING);
	  sendBroadcast(i);
  }
  
  private void DecoderNameSetup()
  {
	  /*
	  strupca = MainActivity.getString(R.string.upca);
	  strupce0 = MainActivity.getString(R.string.upce0);
	  strupce1 = MainActivity.getString(R.string.upce1);
	  strean8 = MainActivity.getString(R.string.ean8);
	  strean13 = MainActivity.getString(R.string.ean13);
	  strcode128 = MainActivity.getString(R.string.code128);
	  strcode39 = MainActivity.getString(R.string.code39);
	  strcode93 = MainActivity.getString(R.string.code93);
	  strcode11 = MainActivity.getString(R.string.code11);
	  stri2of5 = MainActivity.getString(R.string.i2of5);
	  strd2of5 = MainActivity.getString(R.string.d2of5);
	  strcodabar = MainActivity.getString(R.string.codabar);
	  strmsi = MainActivity.getString(R.string.msi);
	  strchinese2of5 = MainActivity.getString(R.string.chinese2of5);
	  strkorean3of5 = MainActivity.getString(R.string.korean3of5);
	  strmatrix2of5 = MainActivity.getString(R.string.matrix2of5);
	  struspostnet = MainActivity.getString(R.string.uspostnet);
	  strusplanet = MainActivity.getString(R.string.usplanet);
	  strukpostal = MainActivity.getString(R.string.ukpostal);
	  strjapanesepostal = MainActivity.getString(R.string.japanesepostal);
	  straustralianpostal = MainActivity.getString(R.string.australianpostal);
	  strdutchpostal = MainActivity.getString(R.string.dutchpostal);
	  strusps4cb = MainActivity.getString(R.string.usps4cb);
	  strus4state = MainActivity.getString(R.string.us4state);
	  strgs1dataBar = MainActivity.getString(R.string.gs1dataBar);
	  strgs1dataBarlimited = MainActivity.getString(R.string.gs1dataBarlimited);
	  strgs1dataBarX = MainActivity.getString(R.string.gs1dataBarX);
	  strcompositeab = MainActivity.getString(R.string.compositeab);
	  strcompositec = MainActivity.getString(R.string.compositec);
	  strpdf417 = MainActivity.getString(R.string.pdf417);
	  strmicroPDF = MainActivity.getString(R.string.microPDF);
	  strdatamatrix = MainActivity.getString(R.string.datamatrix);
	  strmaxicode = MainActivity.getString(R.string.maxicode);
	  strqrcode = MainActivity.getString(R.string.qrcode);
	  strmicroQR = MainActivity.getString(R.string.microQR);
	  straztec = MainActivity.getString(R.string.aztec);
	  strtrioptic39 = MainActivity.getString(R.string.trioptic39);
	  strdiscrete2of5 = MainActivity.getString(R.string.discrete2of5);
	  strtlc39 = MainActivity.getString(R.string.tlc39);*/
  }
  
  /** Called when the activity is first created. */
  public void CodeSettingScreen() {
	  
	  setContentView(R.layout.codemenu);
	  DecoderNameSetup();
	  
	  //Find the ListView resource.
	  mainListView = (ListView) this.findViewById( R.id.mainListView );
	  
	  // When item is tapped, toggle checked properties of CheckBox and Decoders.
	  mainListView.setOnItemClickListener(new AdapterView.OnItemClickListener() 
	  {
		  public void onItemClick( AdapterView<?> parent, View item, int position, long id) 
		  {
			  Symbology decoder = listAdapter.getItem( position );
	    	  decoder.toggleChecked();
	    	  SymbologyViewHolder viewHolder = (SymbologyViewHolder) item.getTag();
	    	  viewHolder.getCheckBox().setChecked( decoder.isChecked());
	      }
	  });


	  if ( decoders == null ) {
	    	decoders = new Symbology[] {
	    			new Symbology(this, "CODE39", bCODE39Enabled, com.hht.emdk.datawedge.ENABLE_CODE39, com.hht.emdk.datawedge.DISABLE_CODE39),
	    			
	    			new Symbology(this, "CODE39 - CODE32 Prefix", bC39_C32Prefix_Enabled, com.hht.emdk.datawedge.ENABLE_CODE32_PREFIX , com.hht.emdk.datawedge.DISABLE_CODE32_PREFIX),
	    			new Symbology(this, "CODE39 - Cnvt to CODE32", bC39_Cnv32_Enabled, com.hht.emdk.datawedge.ENABLE_CNVT_CODE39_TO_32, com.hht.emdk.datawedge.DISABLE_CNVT_CODE39_TO_32),
	    			new Symbology(this, "CODE39 - Full ASCII", bC39_FullASCII_Enabled, com.hht.emdk.datawedge.ENABLE_CODE39_FULL_ASCII, com.hht.emdk.datawedge.DISABLE_CODE39_FULL_ASCII),
	    			new Symbology(this, "CODE39 - Report Check Digit", bC39_TxChkDgt_Enabled, com.hht.emdk.datawedge.ENABLE_CODE39_REPORT_CHK_DGT, com.hht.emdk.datawedge.DISABLE_CODE39_REPORT_CHK_DGT),
	    			new Symbology(this, "CODE39 - Verify Check Digit", bC39_ChkVerify_Enabled, com.hht.emdk.datawedge.ENABLE_CODE39_VER_CHK_DGT, com.hht.emdk.datawedge.DISABLE_CODE39_VER_CHK_DGT),
	    			
	    			new Symbology(this, "CODABAR", bCODABAREnabled, com.hht.emdk.datawedge.ENABLE_CODABAR, com.hht.emdk.datawedge.DISABLE_CODABAR),
	    			new Symbology(this, "CODABAR - CLSI", bCB_CLSI_Enabled, com.hht.emdk.datawedge.ENABLE_CODABAR_CLSI, com.hht.emdk.datawedge.DISABLE_CODABAR_CLSI),
	    			new Symbology(this, "CODABAR - NOTIS", bCB_NOTIS_Enabled, com.hht.emdk.datawedge.ENABLE_CODABAR_NOTIS, com.hht.emdk.datawedge.DISABLE_CODABAR_NOTIS),
	    			
	    			new Symbology(this, "CODE128", bCODE128Enabled, com.hht.emdk.datawedge.ENABLE_CODE128, com.hht.emdk.datawedge.DISABLE_CODE128),
	    			new Symbology(this, "D25", bD25Enabled, com.hht.emdk.datawedge.ENABLE_D25, com.hht.emdk.datawedge.DISABLE_D25),
	    			new Symbology(this, "I25", bI25Enabled, com.hht.emdk.datawedge.ENABLE_I25, com.hht.emdk.datawedge.DISABLE_I25),
	    			new Symbology(this, "I25 - Cnvt to EAN13", bI25_CnvEAN13_Enabled, com.hht.emdk.datawedge.ENABLE_CNVT_I25_TO_EAN13, com.hht.emdk.datawedge.DISABLE_CNVT_I25_TO_EAN13),
	    			new Symbology(this, "I25 - Report Check Digit", bI25_TxChkDgt_Enabled, com.hht.emdk.datawedge.ENABLE_I25_REPORT_CHK_DGT, com.hht.emdk.datawedge.DISABLE_I25_REPORT_CHK_DGT),
	    			new Symbology(this, "I25 - Verify Check Digit", bI25_ChkVerify_Enabled, com.hht.emdk.datawedge.ENABLE_I25_VER_CHK_DGT, com.hht.emdk.datawedge.DISABLE_I25_VER_CHK_DGT),
	    			
	    			new Symbology(this, "CODE93", bCODE93Enabled, com.hht.emdk.datawedge.ENABLE_CODE93, com.hht.emdk.datawedge.DISABLE_CODE93),
	    			new Symbology(this, "UPCA", bUPCAEnabled, com.hht.emdk.datawedge.ENABLE_UPCA, com.hht.emdk.datawedge.DISABLE_UPCA),
	    			new Symbology(this, "UPCA - Report Check Digit", bUPCA_TxChkDgt_Enabled, com.hht.emdk.datawedge.ENABLE_UPCA_REPORT_CHK_DGT, com.hht.emdk.datawedge.DISABLE_UPCA_REPORT_CHK_DGT),
	    			new Symbology(this, "UPCA - Preamble", bUPCA_Preamble_Enabled, com.hht.emdk.datawedge.ENABLE_UPCA_PREAMBLE, com.hht.emdk.datawedge.DISABLE_UPCA_PREAMBLE),
	    			
	    			new Symbology(this, "UPCE", bUPCEEnabled, com.hht.emdk.datawedge.ENABLE_UPCE, com.hht.emdk.datawedge.DISABLE_UPCE),
	    			new Symbology(this, "UPCE - Report Check Digit", bUPCE_TxChkDgt_Enabled, com.hht.emdk.datawedge.ENABLE_UPCE_REPORT_CHK_DGT, com.hht.emdk.datawedge.DISABLE_UPCE_REPORT_CHK_DGT),
	    			new Symbology(this, "UPCE - Preamble", bUPCE_Preamble_Enabled, com.hht.emdk.datawedge.ENABLE_UPCE_PREAMBLE, com.hht.emdk.datawedge.DISABLE_UPCE_PREAMBLE),
	    			new Symbology(this, "UPCE - Cnvt to UPCA", bUPCE_CnvUPCA_Enabled, com.hht.emdk.datawedge.ENABLE_CNVT_UPCE_TO_UPCA, com.hht.emdk.datawedge.DISABLE_CNVT_UPCE_TO_UPCA),
	    			
	    			new Symbology(this, "UPCE1", bUPCE1Enabled, com.hht.emdk.datawedge.ENABLE_UPCE1, com.hht.emdk.datawedge.DISABLE_UPCE1),
	    			new Symbology(this, "UPCE1 - Report Check Digit", bUPCE1_TxChkDgt_Enabled, com.hht.emdk.datawedge.ENABLE_UPCE1_REPORT_CHK_DGT, com.hht.emdk.datawedge.DISABLE_UPCE1_REPORT_CHK_DGT),
	    			new Symbology(this, "UPCE1 - Preamble", bUPCE1_Preamble_Enabled, com.hht.emdk.datawedge.ENABLE_UPCE1_PREAMBLE, com.hht.emdk.datawedge.DISABLE_UPCE1_PREAMBLE),
	    			new Symbology(this, "UPCE1 - Cnvt to UPCA", bUPCE1_CnvUPCA_Enabled, com.hht.emdk.datawedge.ENABLE_CNVT_UPCE1_TO_UPCA, com.hht.emdk.datawedge.DISABLE_CNVT_UPCE1_TO_UPCA),
	    			
	    			new Symbology(this, "EAN8", bEAN8Enabled, com.hht.emdk.datawedge.ENABLE_EAN8, com.hht.emdk.datawedge.DISABLE_EAN8),
	    			new Symbology(this, "EAN8 - Zero Extend", bEAN8ZeroExtendEnabled, com.hht.emdk.datawedge.ENABLE_EAN8_ZEROEXTEND, com.hht.emdk.datawedge.DISABLE_EAN8_ZEROEXTEND),	    			
	    			new Symbology(this, "EAN13", bEAN13Enabled, com.hht.emdk.datawedge.ENABLE_EAN13, com.hht.emdk.datawedge.DISABLE_EAN13),
	    			new Symbology(this, "EAN128", bEAN128Enabled, com.hht.emdk.datawedge.ENABLE_EAN128, com.hht.emdk.datawedge.DISABLE_EAN128),
	    			new Symbology(this, "EAN Bookland", bBOOKLANDEnabled, com.hht.emdk.datawedge.ENABLE_BOOKLAND_ISBN, com.hht.emdk.datawedge.DISABLE_BOOKLAND_ISBN),
	    			new Symbology(this, "TRIOPTIC", bTRIOPTICEnabled, com.hht.emdk.datawedge.ENABLE_TRIOPTIC, com.hht.emdk.datawedge.DISABLE_TRIOPTIC),	    			
	    			new Symbology(this, "ISBT", bISBT_128Enabled, com.hht.emdk.datawedge.ENABLE_ISBT_128, com.hht.emdk.datawedge.DISABLE_ISBT_128),
	    			
	    			new Symbology(this, "CODE11", bCODE11Enabled, com.hht.emdk.datawedge.ENABLE_CODE11, com.hht.emdk.datawedge.DISABLE_CODE11),
	    			new Symbology(this, "CODE11 - Report Check Digit", bC11_TxChkDgt_Enabled, com.hht.emdk.datawedge.ENABLE_CODE11_REPORT_CHK_DGT, com.hht.emdk.datawedge.DISABLE_CODE11_REPORT_CHK_DGT),
	    			new Symbology(this, "CODE11 - Verify Check Digit", bC11_ChkVerify_Enabled, com.hht.emdk.datawedge.ENABLE_CODE11_VER_CHK_DGT, com.hht.emdk.datawedge.DISABLE_CODE11_VER_CHK_DGT),
	    			
	    			new Symbology(this, "MSI", bMSIEnabled, com.hht.emdk.datawedge.ENABLE_MSI, com.hht.emdk.datawedge.DISABLE_MSI),
	    			
	    				    			
	    			new Symbology(this, "RSS 14", bRSS_14Enabled, com.hht.emdk.datawedge.ENABLE_RSS_14, com.hht.emdk.datawedge.DISABLE_RSS_14),	    			
	    			new Symbology(this, "RSS LIM", bRSS_LIMEnabled, com.hht.emdk.datawedge.ENABLE_RSS_LIM, com.hht.emdk.datawedge.DISABLE_RSS_LIM),
	    			new Symbology(this, "RSS EXP", bRSS_EXPEnabled, com.hht.emdk.datawedge.ENABLE_RSS_EXP, com.hht.emdk.datawedge.DISABLE_RSS_EXP),
	    			new Symbology(this, "CHINESE 25", bCHINAEnabled, com.hht.emdk.datawedge.ENABLE_CHINA, com.hht.emdk.datawedge.DISABLE_CHINA)
	    	};
	  }
	    
	  ArrayList<Symbology> decoderList = new ArrayList<Symbology>();
	  decoderList.addAll( Arrays.asList(decoders) );
	  
	  // Set our custom array adapter as the ListView's adapter.
	  listAdapter = new SymbologyArrayAdapter(this, decoderList);
	  mainListView.setAdapter( listAdapter );
  }
  
 

  
  public Object onRetainNonConfigurationInstance() {
	  return decoders ;
  }
}
