package com.hht.demo;

import com.hht.demo.R;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;


import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import com.hht.emdk.datawedge;


public class SDLguiActivity extends Activity
{
	static SDLguiActivity app = null;

	//UI
	private TextView tvStat = null;
	private TextView tvData = null;
	private CheckBox chBeep = null;
	private CheckBox chVibrate = null;
	private Button buttonCodeParam;
	private Button buttonDfl;
	private Button buttonProp;
	
	//Mode State
	private boolean beepMode 		= true; 		// decode beep enable
	private boolean vibrateMode 	= true; 		// decode vibrate enable

	//Counter
	private int decodes 			= 0;
	
	//Listen to decoded result
	private BarcodeDataBroadcastReceiver intentBarcodeDataReceiver = new BarcodeDataBroadcastReceiver();

	// ------------------------------------------------------
	public SDLguiActivity()
	{
		app = this;
	}

	// ------------------------------------------------------
	// Called with the activity is first created.
	@Override
	public void onCreate(Bundle savedInstanceState)
	{		
		super.onCreate(savedInstanceState);

		setContentView(R.layout.main);		// Inflate our UI from its XML layout description.

		// Hook up button presses to the appropriate event handler.
		((Button) findViewById(R.id.buttonDec)).setOnClickListener(mDecodeListener);
		((Button) findViewById(R.id.buttonCodeParam)).setOnClickListener(mCodeSettingListener);
		((Button) findViewById(R.id.buttonDfl)).setOnClickListener(mDefaultListener);
		((Button) findViewById(R.id.buttonProp)).setOnClickListener(mPropListener);
		((CheckBox) findViewById(R.id.checkBeep)).setOnClickListener(mCheckBeepListener);
		((CheckBox) findViewById(R.id.checkVibrate)).setOnClickListener(mCheckVibrateListener);
		
		// ui items
		tvStat = (TextView) findViewById(R.id.textStatus);
		tvData = (TextView) findViewById(R.id.textDecode);
		//edPnum = (EditText) findViewById(R.id.editPnum);
		//edPval = (EditText) findViewById(R.id.editPval);
		chBeep = (CheckBox) findViewById(R.id.checkBeep);
		chBeep.setChecked(beepMode);
		
		chVibrate = (CheckBox) findViewById(R.id.checkVibrate);
		chVibrate.setChecked(vibrateMode);
		
		buttonCodeParam = (Button) findViewById(R.id.buttonCodeParam);
		buttonDfl = (Button) findViewById(R.id.buttonDfl);
		buttonProp = (Button) findViewById(R.id.buttonProp);
		
		IntentFilter intentFilter = new IntentFilter("DATA_SCAN");
		registerReceiver(intentBarcodeDataReceiver, intentFilter);

		//Default ON
		chBeep.setChecked(beepMode);
		chBeep.setChecked(vibrateMode);
	}
	
	//-----------------------------------------------------
	@Override
	protected void onPause()
	{
		DisableJanamScanner();
		super.onPause();
	}

	// ------------------------------------------------------
	// Called when the activity is about to start interacting with the user.
	@Override
	protected void onResume()
	{		
		super.onResume();
		EnableJanamScanner();
	}

	// Beep Setting
	OnClickListener mCheckBeepListener = new OnClickListener()
	{
		public void onClick(View v)
		{
			beepMode = ((CheckBox) v).isChecked();
			Intent BeepSoundIntent = new Intent();
			BeepSoundIntent.setAction(com.hht.emdk.datawedge.SOFTSCANTRIGGER);
			if (beepMode)
				BeepSoundIntent.putExtra(com.hht.emdk.datawedge.EXTRA_PARAMETER, com.hht.emdk.datawedge.ENABLE_BEEP);
			else
				BeepSoundIntent.putExtra(com.hht.emdk.datawedge.EXTRA_PARAMETER, com.hht.emdk.datawedge.DISABLE_BEEP);
			app.sendBroadcast(BeepSoundIntent);
		}
	};
	
	// Vibrate Setting
	OnClickListener mCheckVibrateListener = new OnClickListener()
	{
		public void onClick(View v)
		{
			vibrateMode = ((CheckBox) v).isChecked();
			Intent VibrateIntent = new Intent();
			VibrateIntent.setAction(com.hht.emdk.datawedge.SOFTSCANTRIGGER);
			if (vibrateMode)
				VibrateIntent.putExtra(com.hht.emdk.datawedge.EXTRA_PARAMETER, com.hht.emdk.datawedge.ENABLE_VIBRATE);
			else
				VibrateIntent.putExtra(com.hht.emdk.datawedge.EXTRA_PARAMETER, com.hht.emdk.datawedge.DISABLE_VIBRATE);
			app.sendBroadcast(VibrateIntent);
		}
	};

	// Decode
	OnClickListener mDecodeListener = new OnClickListener()
	{
		public void onClick(View v)
		{
			StartScanner();
		}
	};
	
	// Decoder Setting
	OnClickListener mCodeSettingListener = new OnClickListener()
	{
		public void onClick(View v)
		{
			Intent myIntent = new Intent(SDLguiActivity.this, CodeSetting.class);
			SDLguiActivity.this.startActivity(myIntent);
		}
	};
	
	// Default Setting
	OnClickListener mDefaultListener = new OnClickListener()
	{
		public void onClick(View v)
		{
			  Intent i = new Intent();
			  i.setAction(com.hht.emdk.datawedge.SCANNERINPUTPLUGIN);
			  i.putExtra(com.hht.emdk.datawedge.EXTRA_PARAMETER, com.hht.emdk.datawedge.SET_DEFAULT_SETTING);
			  app.sendBroadcast(i);
		}
	};

	// ------------------------------------------------------
	// callback for properties button press
	OnClickListener mPropListener = new OnClickListener()
	{
		public void onClick(View v)
		{
			doGetProp();
		}
	};	
	
	// ----------------------------------------
	// get properties
	private void doGetProp()
	{
		String s = "Version 1.0\r\nCopyright 2015\t\t";
		AlertDialog.Builder dlg = new AlertDialog.Builder(this);
		if (dlg != null)
		{
			dlg.setTitle("HHT ScanDemo");
			dlg.setMessage(s);
			dlg.setPositiveButton("ok", null);
			dlg.show();
		}
	}
	

	// ----------------------------------------
	 // display status string
	private void dspStat(String s)
	{
		tvStat.setText(s);
	}

	// ----------------------------------------
	// display status resource id
	private void dspStat(int id)
	{
		tvStat.setText("  ");
		tvStat.setText(id);
	}

	// ----------------------------------------
	// display error msg
	private void dspErr(String s)
	{
		tvStat.setText("ERROR " + s);
	}

	// ----------------------------------------
	// display status string
	private void dspData(String s)
	{
		tvData.setText("  ");
		tvData.setText(s);
	}

	// ----------------------------------------
	// start a decode session
	private void doDecode()
	{		
		StartScanner();
		dspData("");
		dspStat(R.string.decoding);	
	}
	
	// ----------------------------------------
	// BarCodeReader.DecodeCallback override
	public void onDecodeComplete(int symbology, int length, String Barcode)
	{
		if (length > 0)
		{
			++decodes;			
			dspStat("[" + decodes + "] type: " + symbology + " len: " + length);
			dspData(Barcode);
		}
		else	// no-decode
		{
			dspData("");
		}
	}
	
	public void StartScanner()
    {
        Intent scannerIntent = new Intent();
        scannerIntent.setAction(com.hht.emdk.datawedge.SOFTSCANTRIGGER);
        scannerIntent.putExtra(com.hht.emdk.datawedge.EXTRA_PARAMETER, com.hht.emdk.datawedge.START_SCANNING);
        app.sendBroadcast(scannerIntent);
    }

    public void StopScanner()
    {
    	Intent scannerIntent = new Intent();
    	scannerIntent.setAction(com.hht.emdk.datawedge.SOFTSCANTRIGGER);
    	scannerIntent.putExtra(com.hht.emdk.datawedge.EXTRA_PARAMETER, com.hht.emdk.datawedge.STOP_SCANNING);
    	app.sendBroadcast(scannerIntent);
    }
	
	public void DisableJanamScanner()
    {
		Intent TriggerButtonIntent = new Intent();
		TriggerButtonIntent.setAction(com.hht.emdk.datawedge.SOFTSCANTRIGGER);
		TriggerButtonIntent.putExtra(com.hht.emdk.datawedge.EXTRA_PARAMETER, com.hht.emdk.datawedge.DISABLE_TRIGGERBUTTON);
		app.sendBroadcast(TriggerButtonIntent);
		
		Intent BeepSoundIntent = new Intent();
		BeepSoundIntent.setAction(com.hht.emdk.datawedge.SOFTSCANTRIGGER);
		BeepSoundIntent.putExtra(com.hht.emdk.datawedge.EXTRA_PARAMETER, com.hht.emdk.datawedge.DISABLE_BEEP);
		app.sendBroadcast(BeepSoundIntent);
		
		Intent i = new Intent();
		i.setAction(com.hht.emdk.datawedge.SCANNERINPUTPLUGIN);
		i.putExtra(com.hht.emdk.datawedge.EXTRA_PARAMETER, "DISABLE_PLUGIN");
		app.sendBroadcast(i);
    }

    public void EnableJanamScanner()
    {
    	Intent i = new Intent();
    	i.setAction(com.hht.emdk.datawedge.SCANNERINPUTPLUGIN);
    	i.putExtra(com.hht.emdk.datawedge.EXTRA_PARAMETER, "ENABLE_PLUGIN");
    	app.sendBroadcast(i);
    	
    	Intent TriggerButtonIntent = new Intent();
    	TriggerButtonIntent.setAction(com.hht.emdk.datawedge.SOFTSCANTRIGGER);
    	TriggerButtonIntent.putExtra(com.hht.emdk.datawedge.EXTRA_PARAMETER, com.hht.emdk.datawedge.ENABLE_TRIGGERBUTTON);
    	app.sendBroadcast(TriggerButtonIntent);
    	
    	Intent BeepSoundIntent = new Intent();
    	BeepSoundIntent.setAction(com.hht.emdk.datawedge.SOFTSCANTRIGGER);
    	BeepSoundIntent.putExtra(com.hht.emdk.datawedge.EXTRA_PARAMETER, com.hht.emdk.datawedge.ENABLE_BEEP);
    	app.sendBroadcast(BeepSoundIntent);
    	
    	Intent VibrateIntent = new Intent();
    	VibrateIntent.setAction(com.hht.emdk.datawedge.SOFTSCANTRIGGER);
    	VibrateIntent.putExtra(com.hht.emdk.datawedge.EXTRA_PARAMETER, com.hht.emdk.datawedge.ENABLE_VIBRATE);
    	app.sendBroadcast(VibrateIntent);
      
      //Intent CodeIntent = new Intent();
      //CodeIntent.setAction(SCANNERINPUTPLUGIN);
      //CodeIntent.putExtra(EXTRA_PARAMETER, ENABLE_EAN13);
      //CodeIntent.putExtra(EXTRA_PARAMETER, DISABLE_EAN13);
     // app.sendBroadcast(CodeIntent);
    }
	
	
	private class BarcodeDataBroadcastReceiver extends BroadcastReceiver {
		@Override
		public void onReceive(Context arg0, Intent arg1) {
			String Barcode = arg1.getStringExtra(com.hht.emdk.datawedge.DATA_STRING);
			int type = arg1.getIntExtra(com.hht.emdk.datawedge.DATA_TYPE, 0);
			int length = arg1.getIntExtra(com.hht.emdk.datawedge.DATA_LENGTH, 0);
			onDecodeComplete(type, length, Barcode);
		}
	}	
}//end-class
