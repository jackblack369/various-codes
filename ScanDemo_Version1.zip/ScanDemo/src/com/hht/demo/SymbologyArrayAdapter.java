package com.hht.demo;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.TextView;

public class SymbologyArrayAdapter extends ArrayAdapter<Symbology> {
	
	private LayoutInflater inflater;
	
	public SymbologyArrayAdapter( Context context, List<Symbology> planetList ) {
		super( context, R.layout.simplerow, R.id.rowTextView, planetList );
		
		// Cache the LayoutInflate to avoid asking for a new one each time.
		inflater = LayoutInflater.from(context) ;
	}
	
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		
		Symbology decoder = (Symbology) this.getItem( position ); 
		
		// The child views in each row.
		CheckBox checkBox ; 
		TextView textView ; 
		
		// Create a new row view
		if ( convertView == null ) {
			
			convertView = inflater.inflate(R.layout.simplerow, null);
			textView = (TextView) convertView.findViewById( R.id.rowTextView );
			checkBox = (CheckBox) convertView.findViewById( R.id.CheckBox01 );
			convertView.setTag( new SymbologyViewHolder(textView,checkBox) );
			
			checkBox.setOnClickListener( new View.OnClickListener() {
				public void onClick(View v) {
					CheckBox cb = (CheckBox) v ;
					Symbology s = (Symbology) cb.getTag();
					s.setChecked( cb.isChecked() );
				}
			});
		}
		else {
			SymbologyViewHolder viewHolder = (SymbologyViewHolder) convertView.getTag();
			checkBox = viewHolder.getCheckBox() ;
			textView = viewHolder.getTextView() ;
		}
		
		checkBox.setTag( decoder ); 
		checkBox.setChecked( decoder.isChecked() );
		textView.setText( decoder.getName() );      
		return convertView;
	}
}
