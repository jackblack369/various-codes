

INSERT INTO installer VALUES ('p2','log6', sequenceIns.NEXTVAL,SYSDATE,NULL);
INSERT INTO installer VALUES ('p8','log1', sequenceIns.NEXTVAL,SYSDATE,NULL);
INSERT INTO installer VALUES ('p10','log1', sequenceIns.NEXTVAL,SYSDATE,NULL);

COMMIT;

UPDATE Segment seg  
 SET seg.nbSalle =
	(SELECT COUNT(*) 
	 FROM   Salle sal 
	 WHERE  seg.indIP = sal.indIP);

UPDATE Segment seg  
 SET seg.nbPoste =
	(SELECT COUNT(*) 
	 FROM   Poste pos
	 WHERE  seg.indIP = pos.indIP);


UPDATE Logiciel l 
  SET l.nbInstall =
	(SELECT COUNT(*) 
	 FROM   Installer i 
	 WHERE  l.nLog = i.nLog);

UPDATE Poste p 
  SET p.nbLog = 
	(SELECT COUNT(*) 
	 FROM   Installer i 
	 WHERE  p.nPoste = i.nPoste);

COMMIT;
