DESC Segment;
DESC Salle;
DESC Poste;
DESC Logiciel;
DESC Installer;
DESC Types;