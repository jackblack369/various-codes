
CREATE OR REPLACE PROCEDURE installLogSeg (param1 IN VARCHAR2, param2 IN VARCHAR2, param3 IN VARCHAR2, 
 param4 IN DATE, param5 IN VARCHAR2, param6 IN VARCHAR2, param7 IN NUMBER) IS
 CURSOR  curseur IS SELECT p.nomPoste, p.nPoste, s.nomSalle
   FROM  Poste p, Salle s
   WHERE p.indIP  = param1 AND p.typePoste = param6
   AND   p.nSalle = s.nSalle;
BEGIN
	INSERT INTO Logiciel VALUES (param2,param3,param4,param5,param6,param7,0);
	DBMS_OUTPUT.PUT_LINE(param3 || ' stock� dans la table Logiciel');
	
	FOR enreg IN curseur LOOP
	   INSERT INTO Installer VALUES(enreg .nPoste, param2, sequenceIns.NEXTVAL ,SYSDATE, 
		NUMTODSINTERVAL(SYSDATE-param4,'DAY'));
	   DBMS_OUTPUT.PUT_LINE('Installation sur '|| enreg.nomPoste ||' dans ' || enreg.nomSalle);
	END LOOP;
	
	COMMIT;
END installLogSeg ;
/

SET SERVEROUT ON
EXECUTE installLogSeg('130.120.80', 'log99','Blaster', '05-09-2003', '9.9', 'PCWS', 999.9 )

SELECT * FROM Logiciel;
SELECT * FROM Installer;
