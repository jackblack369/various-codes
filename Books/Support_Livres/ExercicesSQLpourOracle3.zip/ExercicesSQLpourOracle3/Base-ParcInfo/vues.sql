-- 

CREATE VIEW LogicielsUnix
  AS SELECT *
     FROM   Logiciel 
     WHERE  typeLog = 'UNIX';

DESC LogicielsUnix
SELECT * FROM LogicielsUnix;

CREATE VIEW Poste0 (nPos0, nomPoste0, nSalle0, TypePoste0, indIP, ad0)
  AS SELECT nPoste, nomPoste, nSalle, typePoste, indIP, ad
     FROM   Poste 
     WHERE  indIP IN
	    (SELECT indIP 
	     FROM   Segment
	     WHERE  etage = 0);
DESC Poste0
SELECT * FROM Poste0;

INSERT INTO Poste0 
       VALUES ('p15','Bidon15', 's01','UNIX','130.120.80','20');

INSERT INTO Poste0 
       VALUES ('p16', 'Bidon16','s21','UNIX','130.120.82','20');

-- les deux sont pr�sents ....
SELECT * FROM Poste;

-- seul le poste p15 est pr�sent ....
SELECT * FROM Poste0;

DELETE FROM Poste WHERE nPoste IN ('p15','p16');
SELECT * FROM Poste;


CREATE VIEW SallePrix (nSalle, nomSalle, nbPoste, prixLocation)
	AS SELECT nSalle, nomSalle, nbPoste, nbPoste*100
	FROM Salle;

SELECT * FROM SallePrix;

SELECT * FROM SallePrix
	WHERE prixLocation > 150;


ALTER TABLE Types ADD tarif NUMBER(3);

UPDATE Types SET tarif=50   WHERE typeLP ='TX';
UPDATE Types SET tarif=100  WHERE typeLP ='PCWS';
UPDATE Types SET tarif=120  WHERE typeLP ='PCNT';
UPDATE Types SET tarif=200  WHERE typeLP ='UNIX';
UPDATE Types SET tarif=80   WHERE typeLP ='NC';
UPDATE Types SET tarif=400  WHERE typeLP  ='BeOS';
COMMIT;

SELECT * FROM Types;

--
DROP VIEW SalleInterm�diaire;

CREATE VIEW SalleInterm�diaire(nSalle, typePoste, nombre, tarif)
  AS SELECT p.nSalle, p.typePoste, COUNT(p.nPoste), t.tarif
     FROM   Poste p, Types t
     WHERE  p.typePoste = t.typeLP
     GROUP  BY p.nSalle, p.typePoste, t.tarif;

SELECT * FROM SalleInterm�diaire;


DROP VIEW SallePrixTotal;
CREATE VIEW SallePrixTotal(nSalle, PrixR�el)
  AS SELECT   nSalle, SUM(nombre*tarif) 
     FROM     SalleInterm�diaire
     GROUP BY nSalle;

SELECT * FROM SallePrixTotal;

SELECT * FROM SallePrixTotal
	WHERE PrixR�el = (SELECT MIN(PrixR�el) FROM SallePrixTotal);


--Avec contraintes

CREATE OR REPLACE VIEW Poste0 (nPos0, nomPoste0, nSalle0, TypePoste0, indIP, ad0)
  AS SELECT nPoste, nomPoste, nSalle, typePoste, indIP, ad
     FROM   Poste 
     WHERE  indIP IN
	    (SELECT indIP 
	     FROM   Segment
	     WHERE  etage = 0)
  WITH CHECK OPTION CONSTRAINT wco_Poste0;

SELECT * FROM Poste0;
INSERT INTO Poste0 VALUES
	('p16','Bidon15', 's21','UNIX','130.120.82','20');



DROP VIEW Installer0;
CREATE OR REPLACE VIEW Installer0 (nPoste, nLog, num, dateIns)
  AS SELECT nPoste, nLog, numIns, dateIns FROM Installer
      WHERE nLog NOT IN 
	(SELECT nLog 
	 FROM   Logiciel
	 WHERE  typeLog = 'PCNT')
      AND nPoste IN
	(SELECT nPoste
	 FROM   Poste
	 WHERE  indIP IN 
		(SELECT indIP 
		 FROM   Segment
		 WHERE  etage=0 ))
  WITH CHECK OPTION CONSTRAINT wco_Installer0;
SELECT * FROM Installer0;

INSERT INTO Installer0 VALUES('p11','log7',sequenceIns.NEXTVAL,SYSDATE);
INSERT INTO Installer0 VALUES('p1','log7' ,sequenceIns.NEXTVAL, SYSDATE);

--bonne installation
INSERT INTO Installer0 VALUES('p6','log2' ,sequenceIns.NEXTVAL, SYSDATE);


--

CREATE  VIEW SallePoste (nomSalle, nomPoste, adrIP, nomTypePoste)
  AS SELECT s.nomSalle, p.nomPoste, p.indIP||'.'||p.ad, t.nomType
     FROM   Salle s, Poste p, Types t
     WHERE  s.nSalle    = p.nSalle
     AND    p.typePoste = t.typeLP;

SELECT * FROM SallePoste;



