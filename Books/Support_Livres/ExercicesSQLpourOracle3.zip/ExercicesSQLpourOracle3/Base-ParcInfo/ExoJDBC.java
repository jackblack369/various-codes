import java.sql.*;
import java.util.ArrayList;

public class ExoJDBC {
	public static Connection cx;
	public static ResultSet rs, rs2;
	public static Statement etat;
	public static Statement etatModifiable;
	public static CallableStatement cetat;
	
	public static ArrayList getSalles() 
	{
 		ArrayList tableauR�sultat = new ArrayList();
 		try {
 			 etat = cx.createStatement();
			 rs = etat.executeQuery("SELECT * FROM Salle");
			 String [] ligne = null;
			while (rs.next()) {
				ligne = new String[4];
				ligne[0] = rs.getString(1);
				ligne[1] = rs.getString(2);
				ligne[2] = (new Integer(rs.getInt(3))).toString();
				ligne[3] = rs.getString(4);
				tableauR�sultat.add(ligne);
				}
			rs.close();
			etat.close();
			}
		catch (SQLException ex) {
    		while (ex != null) {
    			System.out.println ("Statut SQL  : "+ex.getSQLState());
	 			System.out.println ("Message     : "+ex.getMessage());
	 			System.out.println ("Code erreur : "+ex.getErrorCode());
	 			ex = ex.getNextException();
	 			}
			}
		return tableauR�sultat;
		}
	
	
	
	public static void deleteSalle(int nl) 
	{				
 	try {
 		etatModifiable = cx.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
	  						   ResultSet.CONCUR_UPDATABLE);
		cx.setAutoCommit(false);
		rs2 = etatModifiable.executeQuery("SELECT s.* FROM Salle s");
		if (rs2.absolute(nl)) 
		  {	rs2.deleteRow(); cx.commit();
		 	System.out.println("Salle supprim�e");} 
		else System.out.println("D�sol�, pas de "+ nl +" �me salle !");
		rs2.close();
		etatModifiable.close();
     	}
		catch (SQLException ex) {
    		while (ex != null) {
    			System.out.println ("Statut SQL  : "+ex.getSQLState());
	 			System.out.println ("Message     : "+ex.getMessage());
	 			System.out.println ("Code erreur : "+ex.getErrorCode());
	 			ex = ex.getNextException();
	 			}
	 		}
		}
	
	public static int deleteSallePL(String ns) {
 		int result = 0;
 		try {cetat = cx.prepareCall("{? = call supprimeSalle(?)}");
			 cetat.registerOutParameter(1,java.sql.Types.INTEGER);
			 cetat.setString(2,ns);
			 cetat.execute();
			 result = cetat.getInt(1);
			 cetat.close(); }
		catch (SQLException ex) {
    		while (ex != null) {
    			System.out.println ("Statut SQL  : "+ex.getSQLState());
	 			System.out.println ("Message     : "+ex.getMessage());
	 			System.out.println ("Code erreur : "+ex.getErrorCode());
	 			ex = ex.getNextException(); } }
	 	return result;}
	
	public static void main(String args[]) 
	{
	try {

 	DriverManager.registerDriver (new oracle.jdbc.driver.OracleDriver());
 	cx = DriverManager.getConnection
	("jdbc:oracle:thin:@CAMPAROLS:1521:BDSoutou","soutou","ingres");
	
	ArrayList lignes = getSalles();
	System.out.println("Liste des salles :\n");
	System.out.println("nSalle\tnomSalle  \tnbPoste\tindIP");
	System.out.println("------------------------------------------");
	String[] lig;
	for (int i=0;i<lignes.size();i++) 
	{	lig=(String [])lignes.get(i);
		System.out.println(lig[0]+"  \t"+lig[1]+"  \t"+lig[2]+"  \t"+lig[3]);}
	System.out.println();

//Pb int�grit�
//	System.out.println("Salle 6 � supprimer");
//	deleteSalle(6);
		
// dern�re nouvelle salle pas rattach�e
//	System.out.println("Salle 7 � supprimer");
//	deleteSalle(7);

	int excep = deleteSallePL("s9");
	if (excep==0) 
	    System.out.println("Salle 9 supprim�e");
		else
		System.out.println("Suppression impossible, code retour : "+excep);

// Pas de salle		
	excep = deleteSallePL("s90");
	if (excep==0) 
	    System.out.println("Salle 90 supprim�e");
		else
		System.out.println("Suppression impossible, code retour : "+excep);

// Fils pr�sents
	excep = deleteSallePL("s01");
	if (excep==0) 
	    System.out.println("Salle ?? supprim�e");
		else
		System.out.println("Suppression impossible, code retour : "+excep);
		
			
	}
	catch (SQLException ex) {
   	while (ex != null) {
    	System.out.println ("Statut SQL  : "+ex.getSQLState());
		System.out.println ("Message     : "+ex.getMessage());
		System.out.println ("Code erreur : "+ex.getErrorCode());
		ex = ex.getNextException(); } }
	}
}
