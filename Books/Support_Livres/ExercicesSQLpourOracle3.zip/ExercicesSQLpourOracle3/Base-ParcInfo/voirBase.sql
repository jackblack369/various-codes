


SELECT * FROM Segment;
SELECT * FROM Salle;
SELECT * FROM Poste;
SELECT * FROM Logiciel;
SELECT * FROM Installer;
SELECT * FROM Types;
