--

UPDATE vehicule SET capacite=6 WHERE type_vehicule=0;

UPDATE vehicule SET capacite=1 WHERE type_vehicule=1;

UPDATE vehicule SET capacite=3 WHERE type_vehicule=2;

--

INSERT INTO chantierinterdits VALUES  ('CH4','1');
INSERT INTO chantierinterdits VALUES  ('CH2','0');

--

INSERT INTO droitsconduite VALUES ('E1','0');
INSERT INTO droitsconduite VALUES ('E1','2');

INSERT INTO droitsconduite VALUES ('E2','0');
INSERT INTO droitsconduite VALUES ('E2','2');

INSERT INTO droitsconduite VALUES ('E3','0');
INSERT INTO droitsconduite VALUES ('E3','1');
INSERT INTO droitsconduite VALUES ('E3','2');

INSERT INTO droitsconduite VALUES ('E10','2');

INSERT INTO droitsconduite VALUES ('E5','2');

SELECT * FROM vehicule;
SELECT * FROM visite;
SELECT * FROM chantierinterdits;
SELECT * FROM droitsconduite;

