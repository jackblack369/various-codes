CLEAR COLS
SET PAGESIZE 50

COL date_jour FORMAT A10
COL type_vehicule FORMAT A13
COL n_emp FORMAT A5
COL n_conducteur FORMAT A12
COL n_transporte FORMAT A12

spool base.lst

SELECT * FROM employe;
SELECT * FROM chantier; 
SELECT * FROM vehicule;
SELECT * FROM visite;
SELECT * FROM transporter;
SELECT * FROM chantierinterdits;
SELECT * FROM droitsconduite;

spool off

