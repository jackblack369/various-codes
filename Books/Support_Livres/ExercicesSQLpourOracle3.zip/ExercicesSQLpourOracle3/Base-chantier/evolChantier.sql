
ALTER TABLE vehicule 
	ADD capacite NUMBER;

CREATE TABLE chantierinterdits
 (n_chantier VARCHAR(10), type_vehicule VARCHAR(20),
 CONSTRAINT pk_chaninter          PRIMARY KEY(n_chantier,type_vehicule),
 CONSTRAINT fk_chaninter_chantier FOREIGN KEY(n_chantier) REFERENCES chantier(n_chantier));

CREATE TABLE droitsconduite
 (n_conducteur VARCHAR(4), type_vehicule VARCHAR(20),
 CONSTRAINT pk_droits         PRIMARY KEY(n_conducteur,type_vehicule),
 CONSTRAINT fk_droits_employe FOREIGN KEY(n_conducteur) REFERENCES employe(n_emp));

ALTER TABLE visite
	ADD temps_trajet AS (kilometres/40);

