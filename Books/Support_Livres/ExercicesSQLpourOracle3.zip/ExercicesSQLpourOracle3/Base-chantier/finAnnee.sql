
CREATE OR REPLACE PROCEDURE finAnnee  IS
 CURSOR curseur IS 
	SELECT n_vehicule FROM Vehicule FOR UPDATE OF kilometrage;
 v_km NUMBER;
 v_nbvis NUMBER;
BEGIN
	DBMS_OUTPUT.PUT_LINE('d�but ');
	FOR enreg IN curseur LOOP
		DBMS_OUTPUT.PUT_LINE('Vehicule : ' || enreg.n_vehicule);
		SELECT SUM(kilometres),COUNT(DISTINCT (n_chantier)) 
			INTO v_km, v_nbvis FROM visite 
			WHERE n_vehicule  = enreg.n_vehicule;
		DBMS_OUTPUT.PUT_LINE(v_nbvis  || ' visites faites par ' || enreg.n_vehicule );
		IF (v_km IS NOT NULL) THEN
		  UPDATE vehicule SET kilometrage = kilometrage +  v_km
			WHERE CURRENT OF curseur;
		  DBMS_OUTPUT.PUT_LINE('vehicule modifie ' || enreg.n_vehicule || ' de ' || v_km || ' km.');
		END IF;
	END LOOP;
	DELETE FROM transporter;
	DELETE FROM visite;
	COMMIT;
END finAnnee ;
/
SHOW ERROR


SELECT * FROM vehicule;

SET SERVEROUT ON
EXECUTE finAnnee ();

SELECT * FROM vehicule;
SELECT * FROM visite;
SELECT * FROM transporter;