
--sous SQL*Plus start C:\Donnees\Livres\Livres-Eyrolles\SQLpourOracle3\Base-chantier\tout.sql
-- lance le tout


start C:\Donnees\Livres\Livres-Eyrolles\SQLpourOracle3\Base-chantier\creaChantier.sql

start C:\Donnees\Livres\Livres-Eyrolles\SQLpourOracle3\Base-chantier\inschantier.sql

start C:\Donnees\Livres\Livres-Eyrolles\SQLpourOracle3\Base-chantier\evolChantier.sql

start C:\Donnees\Livres\Livres-Eyrolles\SQLpourOracle3\Base-chantier\majChantier.sql

start C:\Donnees\Livres\Livres-Eyrolles\SQLpourOracle3\Base-chantier\voirChantier.sql

start C:\Donnees\Livres\Livres-Eyrolles\SQLpourOracle3\Base-chantier\reqChantier.sql

start C:\Donnees\Livres\Livres-Eyrolles\SQLpourOracle3\Base-chantier\vueChantier.sql

--start C:\Donnees\Livres\Livres-Eyrolles\SQLpourOracle3\Base-chantier\finAnnee.sql