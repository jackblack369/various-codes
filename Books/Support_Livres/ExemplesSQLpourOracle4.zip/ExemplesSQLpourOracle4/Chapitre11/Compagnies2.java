import java.sql.*;
import oracle.jdbc.*;
public class Compagnies2 
{public static String retourneCode() throws SQLException 
	{String codeComp = null;
	 try
	   {// �talissement de la connexion (par d�faut) au serveur
//	   Connection cx = DriverManager.getConnection("jdbc:default:connection:");
	    DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
        Connection cx = DriverManager.getConnection("jdbc:oracle:thin:@CAMPAROLS:1521:BDSoutou","soutou","ingres");

	   String sql = "SELECT comp FROM Compagnie WHERE nomComp ='Air France'";
	   Statement stmt = cx.createStatement();
	   ResultSet rs = stmt.executeQuery(sql);
	   rs.next();
	   codeComp = rs.getString(1);
	   rs.close();
	   stmt.close();
	   }  catch (SQLException e) { System.err.println(e.getMessage());} 
	 return codeComp;
    }
}
