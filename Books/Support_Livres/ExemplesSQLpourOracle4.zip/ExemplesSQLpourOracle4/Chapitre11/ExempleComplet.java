import java.sql.*;
import oracle.jdbc.*;
public class ExempleComplet 
{	public static void main (String[] args)
	{
	 System.out.println("Valeurs des param�tres : ");
	 int i;
	 for (i=0; i < args.length; i++)
	 	System.out.println("param�tre "+i+" = "+args[i]);
		
	}
	public static int insereEtCompteComp(String param1, String param2) throws SQLException 
	{int retour = 0;
		try
	   {Connection cx = DriverManager.getConnection("jdbc:default:connection:");
	   String instruction = "INSERT INTO Compagnie VALUES (?,?)";
	   PreparedStatement �tatPr�par� = cx.prepareStatement(instruction);
	   �tatPr�par�.setString(1, param1);
	   �tatPr�par�.setString(2, param2);
	   �tatPr�par�.executeUpdate();
	   System.out.println("insertion r�alis�e.");
	   instruction = "SELECT COUNT(comp) FROM Compagnie";
	   System.out.println("avant executeQuery  : ");
	   �tatPr�par� = cx.prepareStatement(instruction);
	   ResultSet rs = �tatPr�par�.executeQuery(instruction);
	   	   System.out.println("apr�s executeQuery  : ");
	   rs.next();
	   retour = rs.getInt(1);
	   System.out.println("Comptage  : "+retour);
       �tatPr�par�.close();
	   cx.close(); 
	   System.out.println("Insertion r�alis�e.");
	   }  catch (SQLException e) { System.err.println(e.getMessage());} 
    return retour;}    
}
