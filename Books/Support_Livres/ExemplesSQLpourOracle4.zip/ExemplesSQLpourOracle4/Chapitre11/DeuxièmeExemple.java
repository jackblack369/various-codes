public class Deuxi�meExemple
{
	public static void affiche(String param1) 
	{System.out.println("La compagnie "+param1+" a �t� d�truite.");}
}
 