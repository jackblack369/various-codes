
-- Fetch multilignes

SET TIMING ON

SET ARRAYSIZE 1
SET AUTOTRACE TRACEONLY
SELECT a.adhid, a.nom, a.tel, a.date_nais
       FROM  Adherentbis a;
SET AUTOTRACE OFF

SET ARRAYSIZE 100
SELECT a.adhid, a.nom, a.tel, a.date_nais
       FROM  Adherentbis a;
SET AUTOTRACE OFF

SET TIMING OFF

