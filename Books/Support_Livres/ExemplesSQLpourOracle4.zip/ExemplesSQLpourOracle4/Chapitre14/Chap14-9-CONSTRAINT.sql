
-- NOT NULL 

ALTER TABLE Sport 
      ADD federation VARCHAR(10);

UPDATE Sport SET federation = ' ';

ALTER TABLE Sport 
      ADD CONSTRAINT ck_federation 
      CHECK (federation IS NOT NULL);

ALTER TABLE Sport 
      DROP CONSTRAINT ck_federation;

ALTER TABLE Sport 
      MODIFY federation NOT NULL;

-- UNIQUE

ALTER TABLE Adherent 
      ADD CONSTRAINT un_nom_prenom_tel UNIQUE (nom,prenom,tel);

SELECT object_name 
       FROM user_objects WHERE object_type='INDEX';

-- un_nom_prenom_tel devient le nom de l'index

ALTER TABLE Adherent 
      DISABLE CONSTRAINT un_nom_prenom_tel;

SELECT object_name 
       FROM user_objects WHERE object_type='INDEX';

ALTER TABLE Adherent 
      DROP CONSTRAINT un_nom_prenom_tel;