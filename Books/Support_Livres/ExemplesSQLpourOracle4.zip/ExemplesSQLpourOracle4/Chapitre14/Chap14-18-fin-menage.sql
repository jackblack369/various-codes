

--

DROP MATERIALIZED VIEW catalogue_sports;
DROP MATERIALIZED VIEW Adherent_hommes;

DROP INDEX adh_escrime_pingpong_nom_idx;
DROP MATERIALIZED VIEW adh_escrime_pingpong;

--

DROP TABLE   Operateurs_iot;

--

DROP TABLE   Appels_detail;
DROP CLUSTER appels_sorted_hash_cluster;
--

DROP TABLE   Adherent_single_hash_cluster;
DROP CLUSTER adh_single_ash_cluster;

--

DROP TABLE   Operateurs_hash_cluster;
DROP TABLE   Adherent_hash_cluster;
DROP CLUSTER ope_adh_hash_cluster;

--

DROP INDEX   idx_ope_adh_cluster;
DROP TABLE   Adherent_cluster;
DROP TABLE   Operateurs_cluster;
DROP CLUSTER ope_adh_cluster;
DROP TABLE   Operateurs2;

--

DROP FUNCTION f_tel_null;

--

DROP TABLE Pratiquebis;
DROP TABLE Adherentbis;
DROP TABLE temp;

--

DROP TABLE Pratique;
DROP TABLE Adherent;
DROP TABLE Sport;

--sous SYSTEM

DROP TABLESPACE tbs_cluster INCLUDING CONTENTS;
DROP TABLESPACE tbs_part1 INCLUDING CONTENTS;
DROP TABLESPACE tbs_part2 INCLUDING CONTENTS;
DROP TABLESPACE tbs_part3 INCLUDING CONTENTS;
DROP TABLESPACE tbs_part4 INCLUDING CONTENTS;
DROP TABLESPACE tbs_index INCLUDING CONTENTS;
