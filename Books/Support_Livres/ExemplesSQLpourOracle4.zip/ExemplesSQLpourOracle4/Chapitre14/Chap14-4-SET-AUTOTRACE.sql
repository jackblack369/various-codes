
--sous sys

start ?\sqlplus\admin\plustrce.sql
-- ? d�signe automatiquement ORACLE_HOME

-- modifiez "soutou" par votre nom de user

GRANT plustrace TO soutou;

-- pour pouvoir lancer OEM 

GRANT SELECT ANY DICTIONARY TO soutou;

-- sous votre user

SET AUTOTRACE ON

SELECT adhid, prenom, nom 
  FROM Adherent 
  WHERE TO_CHAR(DATE_NAIS,'YYYY')='1995'
  AND TO_CHAR(DATE_NAIS,'MM')='05'
  AND civilite = 'Mme.'
  ORDER BY nom;

SET AUTOTRACE OFF
