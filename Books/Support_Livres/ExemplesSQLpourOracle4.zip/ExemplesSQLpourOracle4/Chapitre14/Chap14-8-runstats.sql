-- Run stats
 
-- sous SYS AS SYSDBA, en modifiant votre nom de user

GRANT SELECT ON sys.v_$TIMER TO soutou;
GRANT SELECT ON sys.v_$MYSTAT TO soutou;
GRANT SELECT ON sys.v_$LATCH TO soutou;
GRANT SELECT ON sys.v_$STATNAME TO soutou;
GRANT CREATE VIEW TO soutou;

-- sous votre user

-->lancer runstats.sql

start C:\temp\runstats.sql

CREATE PROCEDURE test_plsql AS
BEGIN
 LOCK TABLE Adherent IN EXCLUSIVE MODE;
 FOR rec IN 
  (SELECT Adherent.*, rowid AS rid 
          FROM Adherent)
  LOOP
    UPDATE Adherent 
           SET solde = solde * 1.1 
           WHERE rowid = rec.rid;
  END LOOP;
  COMMIT;
END test_plsql;
/

CREATE PROCEDURE test_sql AS
BEGIN
  UPDATE Adherent 
         SET solde = solde * 1.1;
  COMMIT;
END test_sql;
/


SET SERVEROUT ON;
BEGIN
 runstats_pkg.rs_start;
 test_plsql;
 runstats_pkg.rs_middle;
 test_sql;
 runstats_pkg.rs_stop(50);
END;
/

DROP PROCEDURE test_plsql;
DROP PROCEDURE test_sql;
