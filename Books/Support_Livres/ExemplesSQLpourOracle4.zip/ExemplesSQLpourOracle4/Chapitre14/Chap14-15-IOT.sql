
-- tables IOT

CREATE TABLE Operateurs_iot
 (opeid       CHAR(4) NOT NULL,
  nomope      VARCHAR(25) NOT NULL, 
  creaope     DATE NOT NULL,
  siegesocial VARCHAR(15) NOT NULL,
  nbclients   NUMBER(7) NOT NULL,
  CONSTRAINT pk_Operateurs_iot PRIMARY KEY (opeid))
  ORGANIZATION INDEX
  TABLESPACE tbs_index
  INCLUDING  creaope
  PCTTHRESHOLD 20
  OVERFLOW TABLESPACE users;

INSERT /*+ APPEND */ INTO Operateurs_iot SELECT * FROM Operateurs2;
--> 40000 lignes

-- collecte des stats

EXECUTE DBMS_STATS.GATHER_SCHEMA_STATS(ownname=>'SOUTOU',cascade=>true);

select opeid from operateurs2 where opeid like 'F%';
select opeid from operateurs2 where opeid like 'a%';

SET TIMING ON

SET AUTOTRACE ON
SELECT    /*+ FULL(a) */ o.opeid, o.nomope, o.creaope 
    FROM  Operateurs_iot o
    WHERE o.opeid IN ('....','....','....',...);
SELECT    o.opeid, o.nomope, o.creaope
    FROM  Operateurs_iot o
    WHERE o.opeid IN ('....','....','....',...);
SELECT    o.opeid, o.nomope, o.creaope
    FROM  Operateurs2 o 
    WHERE o.opeid IN ('....','....','....',...);
SET AUTOTRACE OFF