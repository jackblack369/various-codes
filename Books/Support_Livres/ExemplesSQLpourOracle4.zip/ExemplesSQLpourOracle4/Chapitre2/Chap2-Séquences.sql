
CREATE TABLE Affreter
	(numAff  NUMBER(5),comp CHAR(4), immat CHAR(6), dateAff DATE, nbPax NUMBER(3),
	CONSTRAINT pk_Affreter PRIMARY KEY (numAff));

CREATE TABLE Passager
	(numPax NUMBER(6), nom CHAR(15), siege CHAR(4), dernierVol NUMBER(5),
	CONSTRAINT pk_Passager PRIMARY KEY(numPax),
	CONSTRAINT fk_Pax_vol_Affreter FOREIGN KEY(dernierVol) REFERENCES Affreter(numAff));

CREATE SEQUENCE seqAff
  MAXVALUE 10000
  NOMINVALUE;

CREATE SEQUENCE seqPax
  INCREMENT BY 10
  START WITH 100
  MAXVALUE 100000
  NOMINVALUE;

-- ALTER

SELECT seqAff.CURRVAL "seqaff CUR" FROM DUAL;
SELECT seqPax.CURRVAL "seqPax CUR" FROM DUAL;


INSERT INTO Affreter VALUES (seqAff.NEXTVAL,'AF', 'F-WTSS', '13-05-2003', 85);

SELECT seqAff.CURRVAL "seqaff CUR" FROM DUAL;
SELECT seqPax.CURRVAL "seqPax CUR" FROM DUAL;


INSERT INTO Affreter VALUES (seqAff.NEXTVAL,'SING', 'F-GAFU', '05-02-2003', 155);

SELECT seqAff.CURRVAL "seqaff CUR" FROM DUAL;
SELECT seqPax.CURRVAL "seqPax CUR" FROM DUAL;

SELECT * FROM Affreter ;

INSERT INTO Passager VALUES (seqPax.NEXTVAL, 'Payrissat', '7A', seqAff.CURRVAL);

SELECT seqAff.CURRVAL "seqaff CUR" FROM DUAL;
SELECT seqPax.CURRVAL "seqPax CUR" FROM DUAL;

INSERT INTO Affreter VALUES (seqAff.NEXTVAL,'AF', 'F-WTSS', '15-05-2003', 82);

SELECT seqAff.CURRVAL "seqaff CUR" FROM DUAL;
SELECT seqPax.CURRVAL "seqPax CUR" FROM DUAL;

SELECT * FROM Passager ;
SELECT * FROM Affreter ;

INSERT INTO Passager VALUES (seqPax.NEXTVAL, 'Castaings', '2E', seqAff.CURRVAL);

SELECT * FROM Passager ;

SELECT seqAff.CURRVAL "seqAff (CURRVAL)" ,
       seqPax.CURRVAL "seqPax  (CURRVAL)" FROM DUAL;

SELECT seqAff.NEXTVAL "seqAff (NEXTVAL)", 
       seqPax.NEXTVAL "seqPax (NEXTVAL)" FROM DUAL;
--

ALTER SEQUENCE seqAff INCREMENT BY 5 MAXVALUE 850;

ALTER SEQUENCE seqPax INCREMENT BY 5 MAXVALUE 95000;

DROP SEQUENCE seqAff;
DROP SEQUENCE seqPax;

DROP TABLE Passager;
DROP TABLE Affreter;

