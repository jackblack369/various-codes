-- structures contr�les
SET SERVEROUTPUT ON

--CASE
DECLARE
  v_mention CHAR(2);
  v_note NUMBER(4,2) := 9.8;
BEGIN
IF v_note >= 16 THEN
   v_mention := 'TB';
  ELSIF v_note >= 14 THEN
    v_mention := 'B';
    ELSIF v_note >= 12  THEN
      v_mention := 'AB';
      ELSIF v_note >= 10  THEN
        v_mention := 'P';
      ELSE
        v_mention := 'R';
END IF;
DBMS_OUTPUT.PUT_LINE ('Mention : '||v_mention );
END;
/


DECLARE
  v_mention CHAR(2);
  v_note NUMBER(4,2) := 9.8;
BEGIN
CASE 
   WHEN v_note >= 16 THEN v_mention := 'TB';
   WHEN v_note >= 14 THEN v_mention := 'B';
   WHEN v_note >= 12 THEN v_mention := 'AB';
   WHEN v_note >= 10 THEN v_mention := 'P';
   ELSE                   v_mention := 'R';
END CASE;
DBMS_OUTPUT.PUT_LINE ('Mention : '||v_mention );
END;
/

--TQ
DECLARE
  v_somme     NUMBER(4) := 0;
  v_entier    NUMBER(3) := 1;
 BEGIN
  WHILE (v_entier <= 100) LOOP
    v_somme  := v_somme + v_entier;
    v_entier := v_entier + 1;
  END LOOP;    
  DBMS_OUTPUT.PUT_LINE ('Somme des 100 premiers = ' || v_somme);
END;
/

DECLARE
  v_t�l�phone CHAR(14)  := '06-76-85-14-89';
  v_trouv�    BOOLEAN   := FALSE;
  v_indice    NUMBER(2) := 1;
BEGIN
  WHILE (v_indice <= 14 AND NOT v_trouv�) LOOP
    IF SUBSTR(v_t�l�phone,v_indice,1) = '4' THEN
      v_trouv� := TRUE;
    ELSE
      v_indice := v_indice + 1;
    END IF;
  END LOOP;   
  IF v_trouv� THEN
    DBMS_OUTPUT.PUT_LINE ('Trouv� 4 � l''indice : ' || v_indice);
  END IF;
END;
/

--R�p�ter
DECLARE
  v_somme     NUMBER(4) := 0;
  v_entier    NUMBER(3) := 1;
 BEGIN
  LOOP
    v_somme  := v_somme + v_entier;
    v_entier := v_entier + 1;
    EXIT WHEN v_entier > 100;
  END LOOP;    
  DBMS_OUTPUT.PUT_LINE ('Somme des 100 premiers = ' || v_somme);
END;
/

DECLARE
  v_t�l�phone CHAR(14)  := '06-76-85-14-89';
  v_trouv�    BOOLEAN   := FALSE;
  v_indice    NUMBER(2) := 1;
BEGIN
 LOOP
  IF SUBSTR(v_t�l�phone,v_indice,1) = '4' THEN
    v_trouv� := TRUE;
  ELSE
    v_indice := v_indice + 1;
  END IF;
 EXIT WHEN (v_indice > 14 OR v_trouv�);
  END LOOP;   
  IF v_trouv� THEN
    DBMS_OUTPUT.PUT_LINE ('Trouv� 4 � l''indice : ' || v_indice);
  END IF;
END;
/

--Pour
DECLARE
  v_somme     NUMBER(4) := 0;
--  v_entier    NUMBER(3);
 BEGIN
  FOR v_entier IN 1 ..100 LOOP
    v_somme  := v_somme + v_entier;
  END LOOP;    
  DBMS_OUTPUT.PUT_LINE ('Somme des 100 premiers = ' || v_somme);
END;
/

DECLARE
  v_t�l�phone CHAR(14)  := '06-76-85-14-89';
  v_trouv�    BOOLEAN   := FALSE;
  v_indice    NUMBER(2);
  v_compteur  NUMBER(2);
BEGIN
 FOR v_compteur IN 1 ..14 LOOP
  IF SUBSTR(v_t�l�phone,v_compteur,1)= '4' AND NOT v_trouv� THEN
    v_trouv� := TRUE;
    v_indice := v_compteur;
  END IF;
  END LOOP;   
  IF v_trouv� THEN
    DBMS_OUTPUT.PUT_LINE ('Trouv� 4 � l''indice : ' || v_indice);
  END IF;
END;
/

---�tiquette 
SET SERVEROUTPUT ON

DECLARE
  v_carteBleue NUMBER(4) := 8595;
  v_test       NUMBER(4) := 0000;
  v_unit�      NUMBER(2);
  v_dizaine    NUMBER(3);  
  v_centaine   NUMBER(4);
  v_millier    NUMBER(5);
BEGIN
v_millier := 0;
<<principal>>
LOOP
 v_centaine := 0;
 LOOP
  v_dizaine := 0;
  LOOP
   v_unit� := 0;
   LOOP
     EXIT principal WHEN v_test = v_carteBleue;
     EXIT WHEN v_unit� = 11;
     v_test  := v_test + 1;
     v_unit� := v_unit� + 1;
   END LOOP;
   v_dizaine  := v_dizaine + 10;
   EXIT WHEN v_dizaine = 100;
  END LOOP;
  v_centaine := v_centaine + 100;
  EXIT WHEN v_centaine = 1000;
 END LOOP;
 v_millier := v_millier + 1000;
 EXIT WHEN v_millier = 10000;
END LOOP principal;
DBMS_OUTPUT.PUT_LINE ('le code CB est : ' || v_test);
END; 
/












