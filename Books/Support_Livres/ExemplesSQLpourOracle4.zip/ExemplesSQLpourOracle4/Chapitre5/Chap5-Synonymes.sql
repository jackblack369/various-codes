
CREATE TABLE Pilote (brevet VARCHAR2(4), nom VARCHAR2(20));
INSERT INTO Pilote VALUES ('PL-1', 'Agn�s Labat');

CREATE TABLE Compagnie (comp VARCHAR2(4), nomComp VARCHAR2(20));
INSERT INTO Compagnie VALUES ('AF', 'Air France');

CREATE VIEW VuePilote AS SELECT * FROM Pilote;
CREATE SYNONYM Navigant1 FOR Pilote;
CREATE SYNONYM Navigant2 FOR soutou.Pilote;
CREATE PUBLIC SYNONYM Navigant3 FOR VuePilote; 
CREATE SYNONYM Soci�t�s1 FOR Pilote;
CREATE OR REPLACE SYNONYM Soci�t�s1 FOR Compagnie;

SELECT * FROM Navigant1 ;
SELECT * FROM Navigant2 ;
SELECT * FROM Navigant3 ;
SELECT * FROM Soci�t�s1;

--
DROP USER Paul;
CREATE USER Paul
    IDENTIFIED BY Pok�mon
    DEFAULT TABLESPACE USERS
    QUOTA 10M ON USERS
    TEMPORARY TABLESPACE TEMP
    QUOTA 5M ON TEMP;

GRANT CONNECT TO Paul;
GRANT INSERT,SELECT ON Navigant2 TO Paul;
GRANT SELECT        ON Navigant3 TO Paul;
--
connect Paul/Pok�mon@cxbdsoutou
--bug normal
SELECT * FROM Navigant2;
SELECT * FROM Soutou.Navigant2;
INSERT INTO Soutou.Navigant2 VALUES('PL-2', 'Jean Turcat');
--public
SELECT * FROM Navigant3;

--connect soutou/...
CREATE SYNONYM Navigant4 FOR Naviguant2;
DROP SYNONYM Navigant2;
SELECT * FROM Navigant4;


--drop
DROP USER Paul;
DROP SYNONYM Soci�t�s1;
DROP SYNONYM Navigant1;
DROP SYNONYM Navigant2;
DROP SYNONYM Navigant3;
DROP VIEW VuePilote;
DROP TABLE Compagnie ;
DROP TABLE Pilote;