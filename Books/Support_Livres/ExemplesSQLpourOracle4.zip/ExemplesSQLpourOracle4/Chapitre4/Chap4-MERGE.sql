---MERGE
CREATE TABLE Primes
	(brevet CHAR(6), nom CHAR(20), paye NUMBER(7,2), compa CHAR(4));

CREATE TABLE Vol 
	(brevet CHAR(6), dateVol DATE, bonus NUMBER(3));

INSERT INTO Primes VALUES ('PL-1', 'Aur�lia Ente', 100, 'AF');
INSERT INTO Primes VALUES ('PL-2', 'Agn�s Bidal', 100, 'AF');
INSERT INTO Primes VALUES ('PL-3', 'Sylvie Payrissat', 0, 'SING');


INSERT INTO Vol VALUES ('PL-1', SYSDATE-10, 50);
INSERT INTO Vol VALUES ('PL-3', SYSDATE,    40);
INSERT INTO Vol VALUES ('PL-4', SYSDATE,    20);

SELECT * FROM Vol ;
SELECT * FROM Primes ;

MERGE INTO Primes p
   USING (SELECT brevet, bonus FROM Vol) v
   ON    (p.brevet = v.brevet)
   WHEN MATCHED THEN UPDATE SET p.paye = p.paye + v.bonus
   WHEN NOT MATCHED THEN INSERT (brevet, paye) VALUES (v.brevet, v.bonus);

SELECT * FROM Vol ;
SELECT * FROM Primes ;


DROP TABLE Vol ;
DROP TABLE Primes;