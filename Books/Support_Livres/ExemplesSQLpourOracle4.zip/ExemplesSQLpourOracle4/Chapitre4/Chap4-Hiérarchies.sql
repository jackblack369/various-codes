
CREATE TABLE Trajets
	(d�part VARCHAR2(10), arriv�e VARCHAR2(10), tempsVol NUMBER(5,2));

INSERT INTO Trajets VALUES ('Paris', 'Blagnac', 1);
INSERT INTO Trajets VALUES ('Paris', 'Lyon', 0.8);
INSERT INTO Trajets VALUES ('Paris', 'Marseille', 0.9);
	INSERT INTO Trajets VALUES ('Blagnac', 'Pau', 0.4);
	INSERT INTO Trajets VALUES ('Lyon', 'Grenoble', 0.3);
	INSERT INTO Trajets VALUES ('Lyon', 'Valence', 0.2);
		INSERT INTO Trajets VALUES ('Grenoble', 'Gap', 0.35);
		INSERT INTO Trajets VALUES ('Valence', 'Ales', 0.25);
	INSERT INTO Trajets VALUES ('Marseille', 'Frejus', 0.2);
	INSERT INTO Trajets VALUES ('Marseille', 'Toulon', 0.15);
	INSERT INTO Trajets VALUES ('Marseille', 'Nimes', 0.35);


SELECT * FROM Trajets;


--bas en haut
SELECT LEVEL,arriv�e,d�part,tempsVol 
FROM Trajets
START WITH d�part='Paris'
CONNECT BY PRIOR d�part = arriv�e;

--haut en bas de Lyon
SELECT LEVEL, d�part, arriv�e, tempsVol 
FROM Trajets
START WITH d�part='Lyon'
CONNECT BY PRIOR  arriv�e =d�part;

--mise en forme : indentation
COLUMN DepartParis FORMAT A15
SELECT LPAD(' ',4*LEVEL-4)||arriv�e DepartParis, tempsVol
FROM Trajets
START WITH d�part='Paris'
CONNECT BY PRIOR arriv�e = d�part;

--�lagage 
--sans Lyon
COLUMN DepartParis FORMAT A15
SELECT LPAD(' ',4*LEVEL-4)||arriv�e DepartParis, tempsVol
FROM Trajets
WHERE NOT (d�part = 'Lyon' OR arriv�e = 'Lyon')
START WITH d�part='Paris'
CONNECT BY PRIOR arriv�e = d�part;

--sans l'arborescence sous Lyon
COLUMN DepartParis FORMAT A15
SELECT LPAD(' ',4*LEVEL-4)||arriv�e DepartParis, tempsVol
FROM Trajets
START WITH d�part='Paris'
CONNECT BY PRIOR arriv�e = d�part
AND NOT d�part = 'Lyon';

--sans l'arborescence sous Lyon et sans Lyon
COLUMN DepartParis FORMAT A15
SELECT LPAD(' ',4*LEVEL-4)||arriv�e DepartParis, tempsVol
FROM Trajets
WHERE NOT (arriv�e = 'Lyon')
START WITH d�part='Paris'
CONNECT BY PRIOR arriv�e = d�part
AND NOT d�part = 'Lyon';

--Join

DROP TABLE A�roports;
CREATE TABLE A�roports
(nomAero VARCHAR2(10), frequenceTWR NUMBER(6,3));

INSERT INTO  A�roports VALUES ('Blagnac', 118.10);
INSERT INTO  A�roports VALUES ('Paris', 123.40);
INSERT INTO  A�roports VALUES ('Lyon', 123.80);
INSERT INTO  A�roports VALUES ('Marseille', 118.70);
INSERT INTO  A�roports VALUES ('Pau', 117.90);
INSERT INTO  A�roports VALUES ('Grenoble', 115.60);
INSERT INTO  A�roports VALUES ('Valence', 126.90);
INSERT INTO  A�roports VALUES ('Gap', 122.70);
INSERT INTO  A�roports VALUES ('Ales', 120.30);
INSERT INTO  A�roports VALUES ('Frejus', 114.70);
INSERT INTO  A�roports VALUES ('Toulon', 119.90);
INSERT INTO  A�roports VALUES ('Nimes', 126.20);


SELECT LPAD(' ',4*LEVEL-4)||arriv�e DepartParis, tempsVol, frequenceTWR 
FROM Trajets, A�roports 
WHERE NOT (arriv�e = 'Lyon') AND arriv�e = nomAero 
START WITH d�part='Paris'
CONNECT BY PRIOR arriv�e = d�part
AND NOT d�part = 'Lyon';

--ORDRE
COLUMN DepartParis FORMAT A15
SELECT LPAD(' ',4*LEVEL-4)||arriv�e DepartParis, tempsVol
FROM Trajets
START WITH d�part='Paris'
CONNECT BY PRIOR arriv�e = d�part
ORDER SIBLINGS BY arriv�e DESC;



DROP TABLE A�roports;
DROP TABLE Trajets;
