
CREATE TABLE Compagnie
	(comp VARCHAR2(4), nrue NUMBER(3), rue VARCHAR2(20), ville VARCHAR2(15), nomComp VARCHAR2(15),
 	CONSTRAINT pk_Compagnie PRIMARY KEY(comp));

CREATE TABLE Pilote
	(brevet VARCHAR2(6), nom CHAR(20), nbHVol NUMBER(7,2), compa VARCHAR2(4), chefPil VARCHAR2(6),
	 CONSTRAINT pk_Pilote PRIMARY KEY(brevet),
	 CONSTRAINT fk_Pil_compa_Comp FOREIGN KEY(compa) REFERENCES Compagnie(comp),
	 CONSTRAINT fk_Pil_chefPil_Pil FOREIGN KEY(chefPil) REFERENCES Pilote(brevet));

INSERT INTO Compagnie
	VALUES ('AF', 124, 'Port Royal', 'Paris', 'Air France');
INSERT INTO Compagnie
   VALUES ('SING', 7, 'Camparols', 'Singapour', 'Singapore AL');
INSERT INTO Compagnie
   VALUES ('CAST', 1, 'G. Brassens', 'Blagnac', 'Castanet AL');

INSERT INTO Pilote
 VALUES ('PL-4', 'Henri Alqui�', 3400, 'AF',NULL);
INSERT INTO Pilote
 VALUES ('PL-1', 'Pierre Lamothe', 450, 'AF', 'PL-4');
INSERT INTO Pilote
 VALUES ('PL-2', 'Didier Linxe', 900, 'AF','PL-4');
INSERT INTO Pilote
 VALUES ('PL-3', 'Christian Soutou', 1000, 'SING',NULL);

--R1
--relationnelle
SELECT  brevet, nom
	FROM Pilote, Compagnie
	WHERE comp    = compa 
	AND   nomComp = 'Air France'
	AND   nbHVol  > 500;

SELECT  pil.brevet, pil.nom
	FROM Pilote pil, Compagnie cpg
	WHERE cpg.comp    = pil.compa 
	AND   cpg.nomComp = 'Air France'
	AND   pil.nbHVol  > 500;


--SQL2
SELECT  brevet, nom
	FROM Compagnie JOIN Pilote ON comp = compa
	WHERE nomComp = 'Air France'
	AND   nbHVol  > 500;


--R2
--relationnelle
SELECT  cpg.nomComp, cpg.nrue, cpg.rue, cpg.ville
	FROM Pilote pil, Compagnie cpg
	WHERE cpg.comp    = pil.compa 
	AND   pil.nbHVol  > 950;

--SQL2
SELECT  nomComp, nrue, rue, ville
	FROM Compagnie JOIN Pilote ON comp = compa
	WHERE nbHVol  > 950;

--R3
--relationnelle
SELECT p1.brevet, p1.nom 
	FROM Pilote p1, Pilote p2
	WHERE p1.chefPil = p2.brevet
	AND p2.nom LIKE '%Alqui�%';
--SQL2
SELECT  p1.brevet, p1.nom 
	FROM Pilote p1 JOIN Pilote p2 ON p1.chefPil = p2.brevet
	WHERE p2.nom LIKE '%Alqui�%';
--R4
--relationnelle
SELECT SUM(p1.nbHVol) 
	FROM Pilote p1, Pilote p2, Compagnie cpg
	WHERE p1.chefPil = p2.brevet
	AND cpg.comp = p2.compa
	AND cpg.nomComp = 'Air France';
--SQL2
SELECT  SUM(p1.nbHVol)
	FROM Pilote p1 JOIN Pilote p2 ON p1.chefPil = p2.brevet
		JOIN Compagnie ON comp = p2.compa
		WHERE nomComp = 'Air France';


--in�quijoin

CREATE TABLE HeuresVol
	(titre CHAR(20), basnbHVol NUMBER(7,2), hautnbHVol NUMBER(7,2));
INSERT INTO HeuresVol VALUES ('D�butant', 0, 500);
INSERT INTO HeuresVol VALUES ('Initi�', 501, 1000);
INSERT INTO HeuresVol VALUES ('Expert', 1001, 5000);


--R5
--relationnelle
SELECT p1.brevet, p1.nom, p1.nbHVol, p2.nbHVol "R�f�rence"
	FROM Pilote p1, Pilote p2
	WHERE p1.nbHVol > p2.nbHVol
	AND p2.brevet = 'PL-2';
--SQL2
SELECT  p1.brevet, p1.nom, p1.nbHVol, p2.nbHVol "R�f�rence"
	FROM Pilote p1 JOIN Pilote p2 ON p1.nbHVol > p2.nbHVol
		WHERE p2.brevet = 'PL-2';

--R6
--relationnelle
SELECT  pil.brevet, pil.nom, pil.nbHVol, hv.titre
	FROM Pilote pil, HeuresVol hv
	WHERE pil.nbHVol BETWEEN hv.basnbHVol AND hv.hautnbHVol;
--SQL2
SELECT  brevet, nom, nbHVol, titre
	FROM Pilote INNER JOIN HeuresVol ON nbHVol BETWEEN basnbHVol AND hautnbHVol;


--externes

CREATE TABLE Qualifs
	(brevet VARCHAR2(6), typeAv CHAR(4), validite DATE);
INSERT INTO Qualifs VALUES ('PL-4', 'A320','24-06-2005');
INSERT INTO Qualifs VALUES ('PL-4', 'A340','24-06-2005');
INSERT INTO Qualifs VALUES ('PL-2', 'A320','04-04-2006');
INSERT INTO Qualifs VALUES ('PL-3', 'A330','13-05-2006');

--

--R7
SELECT  cpg.nomComp, pil.brevet, pil.nom
	FROM Pilote pil, Compagnie cpg
	WHERE cpg.comp    = pil.compa(+);
--pareil
SELECT  cpg.nomComp, pil.brevet, pil.nom
	FROM Pilote pil, Compagnie cpg
	WHERE  pil.compa(+) = cpg.comp  ;

--SQL2
--�quivalents
SELECT  nomComp, brevet, nom
	FROM Compagnie LEFT OUTER JOIN Pilote ON comp = compa;
SELECT  nomComp, brevet, nom
	FROM Pilote RIGHT OUTER JOIN Compagnie ON comp = compa;

--R8
--relationnelle
SELECT  qua.typeAv, pil.brevet, pil.nom
	FROM Pilote pil, Qualifs qua
	WHERE qua.brevet (+) = pil.brevet;

--pareil
SELECT  qua.typeAv, pil.brevet, pil.nom
	FROM Pilote pil, Qualifs qua
	WHERE pil.brevet = qua.brevet (+) ;

--SQL2

--�quivalents
SELECT qua.typeAv, pil.brevet, pil.nom
	FROM Qualifs qua RIGHT OUTER JOIN Pilote pil ON pil.brevet = qua.brevet;
SELECT  qua.typeAv, pil.brevet, pil.nom
	FROM Pilote pil LEFT OUTER JOIN Qualifs qua ON pil.brevet = qua.brevet;


---2 sens
INSERT INTO Pilote
 VALUES ('PL-5', 'Michel Castaings', 0, NULL,NULL);
DELETE FROM Qualifs WHERE brevet = 'PL-4' AND typeAv = 'A340';
INSERT INTO Qualifs VALUES ('PL-7', 'A380','20-07-2007');

SELECT * FROM Qualifs;

SELECT * FROM Pilote;


--R9
--relationnelle
SELECT  cpg.nomComp, pil.brevet, pil.nom
	FROM Pilote pil, Compagnie cpg
	WHERE cpg.comp(+)    = pil.compa
UNION
SELECT  cpg.nomComp, pil.brevet, pil.nom
	FROM Pilote pil, Compagnie cpg
	WHERE cpg.comp   = pil.compa(+);

--SQL92
SELECT  nomComp, brevet, nom
	FROM Pilote FULL OUTER JOIN Compagnie ON comp = compa;
SELECT  nomComp, brevet, nom
	FROM Compagnie FULL OUTER JOIN Pilote ON comp = compa;

--R10
--relationnelle
SELECT  qua.typeAv, pil.brevet, pil.nom
	FROM Pilote pil, Qualifs qua
	WHERE qua.brevet (+) = pil.brevet
UNION
SELECT  qua.typeAv, pil.brevet, pil.nom
	FROM Pilote pil, Qualifs qua
	WHERE qua.brevet  = pil.brevet(+);

--SQL92
SELECT qua.typeAv, pil.brevet, pil.nom
	FROM Pilote pil FULL OUTER JOIN Qualifs qua ON pil.brevet = qua.brevet;
SELECT  qua.typeAv, pil.brevet, pil.nom
	FROM Qualifs qua FULL OUTER JOIN Pilote pil ON pil.brevet = qua.brevet;


--Autres directives SQL92
--Proc�durales
--R1
SELECT  brevet, nom
	FROM Pilote
	WHERE compa = (SELECT comp FROM Compagnie WHERE nomComp = 'Air France')
	AND nbHVol>500;

--R3
SELECT brevet, nom 
	FROM Pilote	 
	WHERE chefPil = (SELECT brevet FROM Pilote WHERE nom LIKE '%Alqui�%');

--R2
SELECT  nomComp, nrue, rue, ville
	FROM Compagnie
	WHERE comp IN (SELECT compa FROM Pilote WHERE nbHVol>950);
--R4
SELECT SUM(nbHVol) 
	FROM Pilote
	WHERE chefPil IN 
	(SELECT brevet FROM Pilote WHERE compa 
		= (SELECT comp FROM Compagnie WHERE nomComp = 'Air France')
	);

--R5
SELECT brevet, nom, nbHVol
 FROM Pilote
WHERE nbHVol > 
	(SELECT nbHVol FROM Pilote WHERE brevet = 'PL-2');

--R7
SELECT  nomComp, nrue, rue, ville
	FROM Compagnie
	WHERE comp IN (SELECT compa FROM Pilote WHERE compa IS NOT NULL)
UNION
SELECT  nomComp, nrue, rue, ville
	FROM Compagnie
	WHERE comp NOT IN (SELECT compa FROM Pilote WHERE compa IS NOT NULL);


CREATE TABLE Avion
	(immat VARCHAR2(6), typeAv CHAR(4), nbHVol NUMBER(7,2), compa VARCHAR2(4));

INSERT INTO Avion VALUES ('A1', 'A320', 1000, 'AF');
INSERT INTO Avion VALUES ('A2', 'A330', 1500, 'AF');
INSERT INTO Avion VALUES ('A3', 'A320', 550, 'SING');
INSERT INTO Avion VALUES ('A4', 'A340', 1800, 'SING');
INSERT INTO Avion VALUES ('A5', 'A340', 200, 'AF');
INSERT INTO Avion VALUES ('A6', 'A330', 100, 'AF');

--R11
SELECT  immat, typeAv, nbHVol
	FROM Avion 
	WHERE nbHVol < ANY (SELECT nbHVol FROM Avion WHERE typeAv='A320');

--R12
SELECT  immat, typeAv, nbHVol, compa
	FROM Avion 
	WHERE nbHVol > ANY (SELECT nbHVol FROM Avion WHERE compa = 'SING');

--R13
SELECT  immat, typeAv, nbHVol
	FROM Avion 
	WHERE nbHVol < ALL (SELECT nbHVol FROM Avion WHERE typeAv='A320');
--R14
SELECT  immat, typeAv, nbHVol, compa
	FROM Avion 
	WHERE nbHVol > ALL (SELECT nbHVol FROM Avion WHERE compa = 'AF');

--Mixte
--R4
SELECT SUM(p1.nbHVol)
	FROM Pilote p1, Pilote p2
	WHERE p1.chefPil = p2.brevet
	AND p2.compa = (SELECT comp FROM Compagnie WHERE nomComp = 'Air France');
---Synchronisation
--R15
SELECT  avi1.*
	FROM Avion avi1
	WHERE avi1.nbHVol > (SELECT AVG(avi2.nbHVol) FROM Avion avi2 WHERE avi2.compa = avi1.compa);


---EXISTS
--R16
SELECT  pil1.brevet, pil1.nom, pil1.compa
	FROM Pilote pil1 
	WHERE EXISTS (SELECT pil2.* FROM Pilote pil2 WHERE pil2.chefPil=pil1.brevet);

--NOT EXISTS
SELECT  cpg.*
	FROM Compagnie cpg
	WHERE NOT EXISTS (SELECT compa FROM Pilote WHERE compa=cpg.comp);


DROP TABLE Qualifs;
DROP TABLE Pilote;
DROP TABLE Compagnie;
DROP TABLE HeuresVol;

