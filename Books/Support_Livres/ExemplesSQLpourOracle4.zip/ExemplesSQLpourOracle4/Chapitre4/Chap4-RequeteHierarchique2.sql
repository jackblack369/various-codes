

---hi�rarchie 10g


DROP TABLE Trajets;

CREATE TABLE Trajets
	(depart VARCHAR2(10), arrivee VARCHAR2(10), tempsVol NUMBER(5,2));


INSERT INTO Trajets VALUES ('Paris', 'Blagnac', 1);
INSERT INTO Trajets VALUES ('Paris', 'Lyon', 0.8);
INSERT INTO Trajets VALUES ('Paris', 'Marseille', 0.9);

	INSERT INTO Trajets VALUES ('Blagnac', 'Pau', 0.4);

	INSERT INTO Trajets VALUES ('Lyon', 'Grenoble', 0.3);
	INSERT INTO Trajets VALUES ('Lyon', 'Valence', 0.2);

		INSERT INTO Trajets VALUES ('Grenoble', 'Gap', 0.35);
		INSERT INTO Trajets VALUES ('Valence', 'Ales', 0.25);

	INSERT INTO Trajets VALUES ('Marseille', 'Frejus', 0.2);
	INSERT INTO Trajets VALUES ('Marseille', 'Toulon', 0.15);
	INSERT INTO Trajets VALUES ('Marseille', 'Nimes', 0.35);


SELECT * FROM Trajets;

--colonneSup : depart
--colonneInf : arrivee

---

--SYS_CONNECT_BY_PATH

COL chemin FORMAT A30 HEADING "H�las tout part de Paris..."
SELECT LPAD(' ', 2*LEVEL-1) || SYS_CONNECT_BY_PATH(arrivee, '/') chemin,tempsVol 
	FROM Trajets
	START WITH depart='Paris'
	CONNECT BY PRIOR arrivee = depart;

--CONNECT_BY_ROOT 

--de bas en haut destinations de 2 escales + d�tail du chemin
COL chemin FORMAT A30 HEADING "Chemin..."
SELECT arrivee "De Paris �", CONNECT_BY_ROOT depart,
   LEVEL-1 "Pathlen", SYS_CONNECT_BY_PATH(depart, '/') chemin
   FROM Trajets
   WHERE LEVEL > 1 AND LEVEL < 3
   CONNECT BY PRIOR arrivee = depart;


--de bas en haut destinations avec deux escales + d�tail
COL chemin FORMAT A30 HEADING "Chemin..."
SELECT arrivee "De Paris �", tempsVol, CONNECT_BY_ROOT depart,
   LEVEL-1 "Pathlen", SYS_CONNECT_BY_PATH(depart, '/') chemin
   FROM Trajets
   WHERE LEVEL > 2
   CONNECT BY PRIOR arrivee = depart;


--de bas en haut destinations avec deux escales + d�tail
COL chemin FORMAT A30 HEADING "Chemin..."
SELECT arrivee "De Paris �", CONNECT_BY_ROOT arrivee "arrivee", SYS_CONNECT_BY_PATH(depart, '/') chemin
   FROM Trajets
   WHERE LEVEL > 2
   CONNECT BY PRIOR arrivee = depart;


SELECT depart, arrivee, tempsVol 
	FROM Trajets
	START WITH depart='Paris'
	CONNECT BY PRIOR arrivee = depart;


The following example uses a GROUP BY clause to return the total salary of each employee in 
department 110 and all employees below that employee in the hierarchy:

SELECT depart, SUM(tempsVol) FROM 
	(
SELECT depart, arrivee, tempsVol 
	FROM Trajets
	START WITH depart='Paris'
	CONNECT BY PRIOR arrivee = depart) group by depart;




SELECT name, SUM(salary) "Total_Salary" FROM (
   SELECT CONNECT_BY_ROOT last_name as name, Salary
      FROM employees
      WHERE department_id = 110
      CONNECT BY PRIOR employee_id = manager_id)
      GROUP BY name;

NAME                      Total_Salary
------------------------- ------------
Gietz                             8300
Higgins                          20300
King                             20300
Kochhar                          20300


DROP TABLE Trajets;
