import java.sql.*;
import oracle.jdbc.driver.*;

class FETCHDirections
{  
public static void main (String args []) throws SQLException
{  
try{
 DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
 Connection cx = DriverManager.getConnection("jdbc:oracle:thin:@CAMPAROLS:1521:BDSoutou","soutou","ingres");

 Statement etatSimple = 
     cx.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
 
 etatSimple.setFetchDirection(ResultSet.FETCH_REVERSE);
 ResultSet curseurJava = 
     etatSimple.executeQuery("SELECT immat,typeAvion,cap FROM Avion");
     
 System.out.println(" FETCH_FORWARD : "+ResultSet.FETCH_FORWARD);
 System.out.println(" FETCH_REVERSE : "+ResultSet.FETCH_REVERSE);
 System.out.println(" FETCH_UNKNOWN : "+ResultSet.FETCH_UNKNOWN);
 
 int directionCourante = curseurJava.getFetchDirection();
 if (directionCourante == ResultSet.FETCH_FORWARD) 
   System.out.println("Curseur par d�faut  FETCH_FORWARD :");
 else if (directionCourante == ResultSet.FETCH_REVERSE)
   System.out.println("Curseur par d�faut  FETCH_REVERSE : ");
   else
   System.out.println("Curseur par d�faut  FETCH_UNKNOWN : ");
  
  curseurJava.setFetchDirection(ResultSet.FETCH_REVERSE);
  
 if (directionCourante == ResultSet.FETCH_FORWARD) 
   System.out.println("Curseur par d�faut  FETCH_FORWARD :");
 else if (directionCourante == ResultSet.FETCH_REVERSE)
   System.out.println("Curseur par d�faut  FETCH_REVERSE : ");
   else
   System.out.println("Curseur par d�faut  FETCH_UNKNOWN : ");
    
  //parcours sens inverse
  curseurJava.afterLast();
  while(curseurJava.next()) 
    {System.out.print("Immat: "+curseurJava.getString(1));    
	 System.out.println(" type : "+curseurJava.getString(2));    
   	 System.out.println(" capacit� : "+curseurJava.getInt(3));}
   
   curseurJava.close(); 

}
catch(SQLException ex){
	System.out.println("Erreur  \n");
	while ((ex != null))
	{
	System.out.println("\nStatut SQL : "+ ex.getSQLState());
	System.out.println("\nMessage : "+ ex.getMessage());
	System.out.println("\nCode Erreur: "+ ex.getErrorCode());
	ex = ex.getNextException();
    } } } }
