import java.sql.*;
import oracle.jdbc.driver.*;

class SELECTPositions
{  
public static void main (String args []) throws SQLException
{  
try{
 DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
 Connection cx = DriverManager.getConnection("jdbc:oracle:thin:@CAMPAROLS:1521:BDSoutou","soutou","ingres");

 Statement etatSimple = 
     cx.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
 
 ResultSet curseurPosJava = 
     etatSimple.executeQuery("SELECT immat,typeAvion,cap FROM Avion");
 
 curseurPosJava.absolute(1); // idem first 
 System.out.println("absolute(1), Immat: "+curseurPosJava.getString(1));
  
 if (curseurPosJava.relative(2)) // acc�s au 3�me
    System.out.println("relative(2), Immat: "+curseurPosJava.getString(1));
   else 
    System.out.println("Pas de 3�me avion!");
    
 if (curseurPosJava.relative(-2)) // retour au 1er
    System.out.println("relative(-3), Immat: "+curseurPosJava.getString(1));
  else 
    System.out.println("Pas de 3�me avion donc pas de retour -2!");
 
 if (curseurPosJava.absolute(-2)) // avant dernier
   System.out.println("absolute(-2), avant-dernier Immat: "+curseurPosJava.getString(1));
 else 
   System.out.println("Pas d'avant dernier avion");
   
  //parcours sens inverse
  curseurPosJava.afterLast();
  while(curseurPosJava.previous()) 
    {System.out.print("Immat: "+curseurPosJava.getString(1));    
	 System.out.println(" type : "+curseurPosJava.getString(2));    
   	 System.out.println(" capacit� : "+curseurPosJava.getInt(3));}
         
   curseurPosJava.close(); 

}
catch(SQLException ex){
	System.out.println("Erreur  \n");
	while ((ex != null))
	{
	System.out.println("\nStatut SQL : "+ ex.getSQLState());
	System.out.println("\nMessage : "+ ex.getMessage());
	System.out.println("\nCode Erreur: "+ ex.getErrorCode());
	ex = ex.getNextException();
    } } } }

/*
absolute(1), Immat: F-WTSS
relative(2), Immat: F-GLFS
Pas de 3�me avion donc pas de retour -3!
absolute(-2), avant-dernier Immat: F-GKUB
Immat: F-GLZV type : A330
 capacit� : 250
Immat: F-GKUB type : A330
 capacit� : 240
Immat: F-GLKT type : A340
 capacit� : 300
Immat: F-GLFS type : A320
 capacit� : 140
Immat: F-FGFB type : Concorde
 capacit� : 95
Immat: F-WTSS type : Concorde
 capacit� : 90
Press any key to continue...
*/