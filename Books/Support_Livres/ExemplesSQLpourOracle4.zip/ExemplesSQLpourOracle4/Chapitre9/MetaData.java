import java.sql.*;
import oracle.jdbc.driver.*;

class MetaData
{  
public static void main (String args []) throws SQLException
{  
try{
 DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
 Connection cx = DriverManager.getConnection("jdbc:oracle:thin:@CAMPAROLS:1521:BDSoutou","soutou","ingres");
 DatabaseMetaData infoBase = cx.getMetaData();
 ResultSet toutesLesTables = infoBase.getTables("", infoBase.getUserName(), null, null);
 
 System.out.println("Objets du sch�ma "+ infoBase.getUserName());
 while (toutesLesTables.next())
 {  System.out.print("Nom de l'objet: "+toutesLesTables.getString(3));
    System.out.println("Type : "+toutesLesTables.getString(4)); } 
  toutesLesTables.close(); 
  
  System.out.println("Nom base : "+infoBase.getDatabaseProductName());
  System.out.println("Version base : "+infoBase.getDatabaseProductVersion());
  
  if (infoBase.supportsSelectForUpdate())
	System.out.println("Supporte les SelectForUpdate");
  if (infoBase.supportsTransactions())
	System.out.println("Supporte les Transactions");
}
catch(SQLException ex){
	System.out.println("Erreur  \n");
	while ((ex != null))
	{
	System.out.println("\nStatut SQL : "+ ex.getSQLState());
	System.out.println("\nMessage : "+ ex.getMessage());
	System.out.println("\nCode Erreur: "+ ex.getErrorCode());
	ex = ex.getNextException();
    } } } }

