import java.sql.*;
import oracle.jdbc.driver.*;

class ResulSetMeta
{  
public static void main (String args []) throws SQLException
{  
try{
 DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
 Connection cx = DriverManager.getConnection("jdbc:oracle:thin:@CAMPAROLS:1521:BDSoutou","soutou","ingres");

 Statement etatSimple = 
     cx.createStatement(ResultSet.TYPE_FORWARD_ONLY,ResultSet.CONCUR_UPDATABLE);
 
 ResultSet curseurJava = 
     etatSimple.executeQuery("SELECT immat,typeAvion,cap FROM Avion");

 ResultSetMetaData rsmd = curseurJava.getMetaData();
 
 int nbCol = rsmd.getColumnCount();
 String nom2emeCol = rsmd.getColumnName(2);
 String type2emeCol = rsmd.getColumnTypeName(2);
 int codeType2emeCol = rsmd.getColumnType(2);

 System.out.println("Nombre de col dans le curseur : "+nbCol);
 System.out.println("Nom 2eme col : "+nom2emeCol);
 System.out.println("Type 2eme col : "+type2emeCol);
 System.out.println("Code type 2eme col : "+codeType2emeCol);

 if ( rsmd.isNullable(1) == ResultSetMetaData.columnNoNulls) 
    System.out.println("Premi�re col ne peut pas �tre nulle");
 else
     System.out.println("Premi�re col peut �tre nulle");
     
  int p1 = rsmd.getPrecision(3);
  int t1 = rsmd.getScale(3);
  System.out.println("chiffres avant , / d�cimales : "+p1+"/"+t1);
  
 String nomSch�ma = rsmd.getSchemaName(2);
 String nomTable = rsmd.getTableName(1);
 System.out.println("Sch�ma : "+nomSch�ma+" Table : "+nomTable);

 
  curseurJava.close(); 
}
catch(SQLException ex){
	System.out.println("Erreur  \n");
	while ((ex != null))
	{
	System.out.println("\nStatut SQL : "+ ex.getSQLState());
	System.out.println("\nMessage : "+ ex.getMessage());
	System.out.println("\nCode Erreur: "+ ex.getErrorCode());
	ex = ex.getNextException();
    } } } }
