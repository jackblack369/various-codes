import java.sql.*;
import oracle.jdbc.driver.*;

class Exceptions1
{  
public static void main (String args []) throws SQLException
{  
try{
 DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
 Connection cx = DriverManager.getConnection("jdbc:oracle:thin:@CAMPAROLS:1521:BDSoutou","soutou","ilngres");


 
 cx.close(); 
}
catch(SQLException ex){
	System.err.println("Erreur");
	while ((ex != null))
	{System.err.println("Statut : "+ ex.getSQLState());
	System.err.println("Message : "+ ex.getMessage());
	System.err.println("Code Erreur base : "+ ex.getErrorCode());
	ex = ex.getNextException();} 
	} } }
