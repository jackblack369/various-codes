import java.sql.*;
import oracle.jdbc.driver.*;

class JDBCThin
{  
public static void main (String args []) throws SQLException
{ 
String lienBD = "jdbc:oracle:thin:@CAMPAROLS:1521:BDSoutou";
Connection cx1, cx2, cx3, cx4;
try{
DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
cx1 = DriverManager.getConnection
("jdbc:oracle:thin:@CAMPAROLS:1521:BDSoutou","soutou","ingres");
Statement stmt = cx1.createStatement ();
ResultSet rset = stmt.executeQuery ("SELECT SYSDATE FROM DUAL");    
while (rset.next ())
   System.out.println ("Nous sommes le : "+rset.getString (1));
System.out.println ("CX1 correctement configur�e");
cx2 = DriverManager.getConnection(lienBD,"soutou","ingres");
stmt = cx2.createStatement ();
rset = stmt.executeQuery ("SELECT SYSDATE FROM DUAL");    
while (rset.next ())
   System.out.println ("Nous sommes le : "+rset.getString (1));
System.out.println ("CX2 correctement configur�e");
cx3 = DriverManager.getConnection("jdbc:oracle:thin:@192.168.4.118:1521:BDSoutou","soutou","ingres");
stmt = cx3.createStatement ();
rset = stmt.executeQuery ("SELECT SYSDATE FROM DUAL");    
while (rset.next ())
   System.out.println ("Nous sommes le : "+rset.getString (1));
System.out.println ("CX3 correctement configur�e");
cx4 = DriverManager.getConnection("jdbc:oracle:thin:@camparols:1521:BDSoutou","soutou","ingres");
stmt = cx4.createStatement ();
rset = stmt.executeQuery ("SELECT SYSDATE FROM DUAL");    
while (rset.next ())
   System.out.println ("Nous sommes le : "+rset.getString (1));
System.out.println ("CX4 correctement configur�e");

}
catch(SQLException ex){
	System.out.println("Erreur connexion \n");
	while ((ex != null))
	{
	System.out.println("\nStatut SQL : "+ ex.getSQLState());
	System.out.println("\nMessage : "+ ex.getMessage());
	System.out.println("\nCode Erreur: "+ ex.getErrorCode());
	ex = ex.getNextException();
    } } } }
