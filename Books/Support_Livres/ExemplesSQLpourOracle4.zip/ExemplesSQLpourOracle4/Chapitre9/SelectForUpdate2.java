import java.sql.*;
import oracle.jdbc.driver.*;

class SelectForUpdate2
{  
public static void main (String args []) throws SQLException
{  
try{
 DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
 Connection cx = DriverManager.getConnection("jdbc:oracle:thin:@CAMPAROLS:1521:BDSoutou","soutou","ingres");

 PreparedStatement pstmt = cx.prepareStatement("SELECT immat,typeAvion,cap FROM Avion FOR UPDATE");
 pstmt.execute ();





 Statement etatSimple = 
     
 
 
 ResultSet curseurModifJava = 
     etatSimple.executeQuery("SELECT immat,typeAvion,cap FROM Avion FOR UPDATE");
//
  cx.setAutoCommit(false);
    
  if (curseurModifJava.absolute(5)) // acc�s au 5�me
 { 
   System.out.println("Avion � modifier  :  "+curseurModifJava.getString(1));
   //premi�re �tape
   /*
   curseurModifJava.updateString(2,"A380");
   curseurModifJava.updateInt(3,350);
   //deuxi�me �tape
   curseurModifJava.updateRow();
   cx.commit();
   System.out.println("Modifi� au niveau de la base.");
   */
  }
   else 
   System.out.println("Pas de 5�me avion!");
 
 //Parcours
 curseurModifJava.beforeFirst();
    while(curseurModifJava.next()) 
    {
      System.out.print("Immat: "+curseurModifJava.getString(1));    
	 System.out.println(" type : "+curseurModifJava.getString(2));
	 System.out.println(" capacit� : "+curseurModifJava.getInt(3));}    

  curseurModifJava.close(); 
}
catch(SQLException ex){
	System.out.println("Erreur  \n");
	while ((ex != null))
	{
	System.out.println("\nStatut SQL : "+ ex.getSQLState());
	System.out.println("\nMessage : "+ ex.getMessage());
	System.out.println("\nCode Erreur: "+ ex.getErrorCode());
	ex = ex.getNextException();
    } } } }
