import java.sql.*;
import oracle.jdbc.driver.*;

class Transaction1
{  
public static void main (String args []) throws SQLException
{  
try{
 DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
 Connection cx = DriverManager.getConnection("jdbc:oracle:thin:@CAMPAROLS:1521:BDSoutou","soutou","ingres");
 cx.setAutoCommit(false);
 
 String ordreSQL = "INSERT INTO Avion VALUES (?, ?, ?, ?)";
 PreparedStatement �tatPr�par� = cx.prepareStatement(ordreSQL);
 
 �tatPr�par�.setString(1, "F-NEW1");
 �tatPr�par�.setString(2, "A321");
  �tatPr�par�.setInt(3, 180);
 �tatPr�par�.setString(4, "AF");
 System.out.print(�tatPr�par�.executeUpdate()+" avion ins�r�.");  
 //pas de commit mais transaction effectu�e 
 cx.close();
 }
catch(SQLException ex){
	System.out.println("Erreur  \n");
	while ((ex != null))
	{
	System.out.println("\nStatut SQL : "+ ex.getSQLState());
	System.out.println("\nMessage : "+ ex.getMessage());
	System.out.println("\nCode Erreur: "+ ex.getErrorCode());
	ex = ex.getNextException();
    } } } }
