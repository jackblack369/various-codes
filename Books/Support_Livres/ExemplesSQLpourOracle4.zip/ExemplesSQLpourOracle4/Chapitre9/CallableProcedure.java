import java.sql.*;
import oracle.jdbc.driver.*;

class CallableProcedure
{  
public static void main (String args []) throws SQLException
{  
try{
 DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
 Connection cx = DriverManager.getConnection("jdbc:oracle:thin:@CAMPAROLS:1521:BDSoutou","soutou","ingres");

 String ordreSQL                 = "{call AugmenteCapacit�(?,?)}";
 System.out.println("Avant pr�pare ");  
 CallableStatement �tatAppelable = cx.prepareCall(ordreSQL);
 
   
 �tatAppelable.setString(1,"F-GLFS");
 �tatAppelable.setInt(2,50);
   
 System.out.println("Avant appel ");   
 
 �tatAppelable.execute();
    
   �tatAppelable.close(); 
   cx.close(); 
}
catch(SQLException ex){
	System.out.println("Erreur  \n");
	while ((ex != null))
	{
	System.out.println("\nStatut SQL : "+ ex.getSQLState());
	System.out.println("\nMessage : "+ ex.getMessage());
	System.out.println("\nCode Erreur: "+ ex.getErrorCode());
	ex = ex.getNextException();
    } } } }
