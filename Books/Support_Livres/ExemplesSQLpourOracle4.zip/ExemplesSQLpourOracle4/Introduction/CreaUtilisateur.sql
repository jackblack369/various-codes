
--Suppression de l'utilisateur (s'il existait d�j�)

DROP USER <nom de l'utilisateur> CASCADE;


--Cr�ation de l'utilisateur

CREATE USER    <nom de l'utilisateur>
 IDENTIFIED BY <mot de passe>
 DEFAULT    TABLESPACE USERS
 TEMPORARY  TABLESPACE TEMP
 QUOTA      UNLIMITED  ON USERS;

--Attribution de quelques autorisations � l'utilisateur

GRANT CONNECT, RESOURCE TO <nom de l'utilisateur> ;
