DROP TABLE Avion;
DROP TABLE Compagnie;
CREATE TABLE Compagnie
	(comp CHAR(4), nomComp VARCHAR(30),
 	CONSTRAINT pk_Compagnie PRIMARY KEY(comp));


CREATE TABLE Avion
	(immat CHAR(6), typeAvion CHAR(15) NOT NULL, capacite NUMBER(3), compa CHAR(4),
	CONSTRAINT pk_Avion PRIMARY KEY(immat),
	CONSTRAINT ck_Avion CHECK (capacite < 500),
	CONSTRAINT fk_Avion_comp_Compag FOREIGN KEY(compa) REFERENCES Compagnie(comp));


INSERT INTO Compagnie
	VALUES ('AF', 'Air France');
INSERT INTO Compagnie
   VALUES ('SING', 'Singapore AL');


INSERT INTO Avion
   VALUES ('F-WTSS', 'Concorde', 90, 'AF');
INSERT INTO Avion
   VALUES ('F-GLFS', 'A320', 170, 'AF');
INSERT INTO Avion
   VALUES ('F-GAFU', 'A320', 160, 'AF');
INSERT INTO Avion
   VALUES ('F-WOWW', 'A380', NULL, 'AF');

select * from avion;

select * from Compagnie;

DROP TABLE Avion;
DROP TABLE Compagnie;
