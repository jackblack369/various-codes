<html> <head> <title>M�ta donn�es 1 </title> </head>
<body>
<?php
	$service = "(DESCRIPTION = (ADDRESS = (PROTOCOL = TCP)(HOST = localhost)(PORT = 1521))
		    (CONNECT_DATA = (SERVER = DEDICATED) (SERVICE_NAME = bdcs10g)))";
	$utilisateur = "soutou";
	$mdp = "iut";
	$cx = oci_connect($utilisateur ,$mdp, $service);
	if (!$cx) 
		{print "L'utilisateur $utilisateur n'a pu se connecter � la base";
		} 
	else 
		{
		print "<BR>User : <B>$utilisateur</B> se connecte � la base version : <BR>";
		print oci_server_version($cx);
	// oci_field_is_null

	// extraction 
	
	$requete   = "SELECT * FROM Avion";
	$ordre = oci_parse ($cx, $requete);

	oci_define_by_name($ordre, "IMMAT", $immatriculation);
	oci_define_by_name($ordre, "TYPEAVION", $typav);
	oci_define_by_name($ordre, "CAPACITE", $cap);

	oci_execute ($ordre);
		
        print "<BR><B>Liste des avions de capacit� NULLE</B>";
	print "<TABLE BORDER=1> ";
	while (oci_fetch_array($ordre))
		{
		if (oci_field_is_null($ordre,"CAPACITE"))
			{	
			print "<TR> <TD> $immatriculation </TD>" ;
			print "     <TD> $typav     </TD> </TR> ";
			}
		}
	print "</TABLE> ";
		oci_free_statement($ordre);
		oci_close($cx);
		}
?>
</body> </html>