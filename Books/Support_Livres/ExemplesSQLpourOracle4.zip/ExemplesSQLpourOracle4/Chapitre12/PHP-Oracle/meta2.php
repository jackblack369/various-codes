<html> <head> <title>M�ta donn�es </title> </head>
<body>
<?php
	$service = "(DESCRIPTION = (ADDRESS = (PROTOCOL = TCP)(HOST = localhost)(PORT = 1521))
		    (CONNECT_DATA = (SERVER = DEDICATED) (SERVICE_NAME = bdcs10g)))";
	$utilisateur = "soutou";
	$mdp = "iut";
	$cx = oci_connect($utilisateur ,$mdp, $service);
	if (!$cx) 
		{print "L'utilisateur $utilisateur n'a pu se connecter � la base";
		} 
	else 
		{
		

    $ordre = oci_parse($cx, "SELECT * FROM Avion");
    oci_execute($ordre);
    
print "Structure de la table <B>Avion</B>";
    print "<table border=1>";
    print "<tr>";
    print "<th>Nom</th>";
    print "<th>Type</th>";
    print "<th>Taille</th>";
    print "</tr>";
   
    $ncols = oci_num_fields($ordre);
   
    for ($i = 1; $i <= $ncols; $i++) {
        $col_nom   = oci_field_name($ordre, $i);
        $col_type  = oci_field_type($ordre, $i);
        $col_size  = oci_field_size($ordre, $i);
        
        print "<tr>";
        print "<td>$col_nom</td>";
        print "<td>$col_type</td>";
        print "<td>$col_size</td>";
        print "</tr>";
    }
       
    print "</table>\n"; 


		oci_free_statement($ordre);
		oci_close($cx);
		}
?>
</body> </html>