<html> <head> <title>test Apache 1.3 PHP5 </title> </head>
<body>
	Test de la configuration Apache1.3 - PHP5
	<?php
		phpinfo();
	?>
</body> </html>