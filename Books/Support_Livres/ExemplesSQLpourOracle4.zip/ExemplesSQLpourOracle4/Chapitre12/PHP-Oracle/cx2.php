<html> <head> <title>Connexion et version de la base </title> </head>
<body>
<?php
	$service = "(DESCRIPTION = (ADDRESS = (PROTOCOL = TCP)(HOST = localhost)(PORT = 1521))
		    (CONNECT_DATA = (SERVER = DEDICATED) (SERVICE_NAME = bdcs10g)))";
	$utilisateur = "soutou";
	$mdp = "iut";
	$cx = oci_connect($utilisateur ,$mdp, $service);
	if (!$cx) 
		{print "L'utilisateur $utilisateur n'a pu se connecter � la base";
		} 
	else 
		{print "<BR>User : <B>$utilisateur</B> se connecte � la base version : <BR>";
		 print oci_server_version($cx);
		 oci_close($cx);
		}
?>	
</body> </html>