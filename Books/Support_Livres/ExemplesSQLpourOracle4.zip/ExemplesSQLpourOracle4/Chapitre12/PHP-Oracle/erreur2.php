<html> <head> <title>Erreur SELECT </title> </head>
<body>
<?php
	$service = "(DESCRIPTION = (ADDRESS = (PROTOCOL = TCP)(HOST = localhost) (PORT = 1521))
		    (CONNECT_DATA = (SERVER = DEDICATED) (SERVICE_NAME = bdcs10g)))";
	$utilisateur = "soutou";
	$mdp = "iut";
	$cx = oci_connect($utilisateur ,$mdp, $service);
	if (!$cx) 
		{print "L'utilisateur <B>$utilisateur</B> n'a pu se connecter � la base <BR>";
		 } 
	else 
		{
		$requetePB = "SELECT ! FROM Avion";
		$ordre = oci_parse($cx,$requetePB);
  		
		if (!@oci_execute($ordre)) 
		{
		  print "Probl�me sur : <B> ". $requetePB . "</B><BR>";
		  $taberr = oci_error($ordre);
		  print "<B>Message : </B>" . $taberr['message'];
		  print "<BR><B>Code    : </B>" . $taberr['code'];
	  	  print "<BR><B>sqltext   : </B>" . $taberr['sqltext'];
	  	  print "<BR><B>offset    : </B>" . $taberr['offset'];
		}
		oci_close($cx);
		}
?>
</body> </html>
 
 