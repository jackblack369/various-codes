CREATE OR REPLACE PROCEDURE afficheAvions(cp IN VARCHAR2) IS
CURSOR curs IS SELECT immat, typeAvion, cap FROM Avion WHERE comp = cp;
begin
HTP.htmlOpen; HTP.bodyOpen;
HTP.line;
HTP.tableOpen('BORDER');
HTP.tableCaption('Flotte','CENTER');
HTP.tableRowOpen;
   HTP.tableHeader('Numero');
   HTP.tableHeader('Type');
   HTP.tableHeader('Capacit�');
HTP.tableRowClose;
FOR ligne IN curs LOOP
   HTP.tableRowOpen;
   HTP.tableData(ligne.immat);
   HTP.tableData(ligne.typeAvion);
   HTP.tableData(ligne.cap);
   HTP.tableRowClose;
END LOOP;
HTP.tableClose;
HTP.bodyClose; HTP.htmlClose;
END;
/
