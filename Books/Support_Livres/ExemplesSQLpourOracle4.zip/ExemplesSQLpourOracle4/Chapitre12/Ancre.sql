CREATE OR REPLACE PROCEDURE Ancre AS
BEGIN
HTP.htmlOpen;
HTP.bodyOpen;
HTP.header(1,'Pose d''ancres vers : ');
HTP.anchor('http://www.oracle.fr', 'Le site d''Oracle France');
HTP.print(' ou ');
HTP.anchor('http://www.air-france.fr', 'Air France');
HTP.print(', vous pr�f�rez voyager, pas vrai? ');
HTP.bodyClose;
HTP.htmlClose;
END;
/
