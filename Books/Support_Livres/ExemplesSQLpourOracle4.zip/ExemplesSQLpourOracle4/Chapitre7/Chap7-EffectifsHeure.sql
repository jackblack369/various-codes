CREATE OR REPLACE FUNCTION
 EffectifsHeure(pcomp IN VARCHAR2, pheuresVol IN NUMBER) RETURN NUMBER
IS
	r�sultat NUMBER := 0;
BEGIN
	IF (pcomp IS NULL) THEN
        	SELECT	COUNT(*) INTO r�sultat FROM Pilote
			WHERE    nbHVol >  pheuresVol ;
	ELSE
        	SELECT	COUNT(*) INTO r�sultat FROM Pilote
			WHERE    nbHVol >  pheuresVol
			AND      comp = pcomp;
	END IF;
	RETURN r�sultat;
END EffectifsHeure;
/