
--Cr�ation dynamique de tables

--
DROP TABLE Softs;

CREATE TABLE Softs (nomSoft, Version)
	AS SELECT nomLog, Version FROM Logiciel;

SELECT * FROM Softs;

--

DROP TABLE PCseuls;

CREATE TABLE PCSeuls (np, nomP, seg, ad, typeP,lieu)
	AS SELECT nPoste, nomPoste, IndIP, ad, typePoste, nSalle
	FROM Poste
	WHERE typePoste = 'PCNT' OR typePoste = 'PCWS';

SELECT * FROM PCSeuls;







