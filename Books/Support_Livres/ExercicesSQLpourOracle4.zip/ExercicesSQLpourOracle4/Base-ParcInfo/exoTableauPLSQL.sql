
SET SERVEROUTPUT ON

DECLARE
  TYPE nomComp_tytab IS TABLE 
      OF VARCHAR2(15)
      INDEX BY BINARY_INTEGER;
-- tableaux
  tab_compFrance nomComp_tytab;
  tab_compMonde  nomComp_tytab;
  tab_r�sultat   nomComp_tytab;
  v_indiceFrance NUMBER(1) := 1;
  v_indiceMonde  NUMBER(1) := 1;
  v_indiceR�sultat  NUMBER(2) := 1;
BEGIN
  tab_compFrance(1) := 'AERIS';   
  tab_compFrance(2) := 'Air France';     
  tab_compFrance(3) := 'Air Littoral';  
  tab_compFrance(4) := 'Regional';  
  tab_compMonde(1)  := 'ALITALIA';  
  tab_compMonde(2)  := 'Quantas';  
  tab_compMonde(3)  := 'SABENA';  				
--
  WHILE (tab_compFrance.EXISTS(v_indiceFrance) AND tab_compMonde.EXISTS(v_indiceMonde)) LOOP
   IF tab_compFrance(v_indiceFrance) > tab_compMonde(v_indiceMonde)THEN
     tab_r�sultat(v_indiceR�sultat) :=  tab_compMonde(v_indiceMonde);
     v_indiceMonde    := v_indiceMonde    + 1; 
   ELSE
     tab_r�sultat(v_indiceR�sultat) :=  tab_compFrance(v_indiceFrance);
     v_indiceFrance   := v_indiceFrance   + 1; 
   END IF;
   v_indiceR�sultat := v_indiceR�sultat + 1;
  END LOOP;
--
  WHILE (tab_compFrance.EXISTS(v_indiceFrance)) LOOP
   tab_r�sultat(v_indiceR�sultat) :=  tab_compFrance(v_indiceFrance);
   v_indiceR�sultat := v_indiceR�sultat + 1;
   v_indiceFrance   := v_indiceFrance   + 1; 
  END LOOP;
--
  WHILE (tab_compMonde.EXISTS(v_indiceMonde)) LOOP
   tab_r�sultat(v_indiceR�sultat) :=  tab_compMonde(v_indiceMonde);
   v_indiceR�sultat := v_indiceR�sultat + 1;
   v_indiceMonde    := v_indiceMonde    + 1; 
  END LOOP;
--
  DBMS_OUTPUT.PUT_LINE('Nombre �l�ments de tab_r�sultat ' || tab_r�sultat.COUNT);	
--
  FOR v_entier IN 1 ..tab_r�sultat.COUNT LOOP 
    DBMS_OUTPUT.PUT_LINE('tab_r�sultat(' || v_entier || ') : ' || tab_r�sultat(v_entier)) ;	
  END LOOP;
END;
/