
--lance le tout

@dropParc.sql

@creParc.sql

@insparc.sql

@�volution.sql

@modification

@cr�aDynamique.sql

@modifSynchronis�es.sql

@voirbase