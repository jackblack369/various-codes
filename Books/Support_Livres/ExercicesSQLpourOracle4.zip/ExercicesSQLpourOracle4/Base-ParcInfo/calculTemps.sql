
CREATE OR REPLACE PROCEDURE calculTemps IS
   CURSOR curseur IS SELECT l.nomLog,p.nomPoste,l.dateAch,i.dateIns,i.nLog, i.nPoste
	   FROM Installer i, Logiciel l, Poste p
	   WHERE i.nPoste = p.nPoste AND i.nLog = l.nLog;
   atte NUMBER(4);
BEGIN
   FOR enreg IN curseur LOOP
	IF enreg.dateIns IS NULL THEN
	  DBMS_OUTPUT.PUT_LINE('Pas de date d''installation pour le logiciel ' 
         || enreg.nomLog  || ' sur ' || enreg.nomPoste);
	ELSE
	     IF enreg.dateAch IS NULL THEN
	        DBMS_OUTPUT.PUT_LINE('Date d''achat inconnue pour le logiciel ' 
                   || enreg.nomLog  || ' sur ' || enreg.nomPoste);
	     ELSE 
		   atte :=  enreg.dateIns - enreg.dateAch;
		   IF atte < 0 THEN
		      DBMS_OUTPUT.PUT_LINE('Logiciel ' ||  enreg.nomLog || ' install� sur ' || 
		        enreg.nomPoste || ' ' ||  -atte || ' jour(s) avant d''�tre achet�!');	
		   ELSE
	   IF atte = 0 THEN
		DBMS_OUTPUT.PUT_LINE('Logiciel ' || enreg.nomLog  || ' sur ' || 
		 enreg.nomPoste || ' achet� et install� le m�me jour!');		
	   ELSE 
		DBMS_OUTPUT.PUT_LINE('Logiciel ' || enreg.nomLog  || ' sur ' || 
		 enreg.nomPoste || ', attente ' || atte || ' jour(s).');
		UPDATE Installer SET delai = NUMTODSINTERVAL(enreg.dateIns - enreg.dateAch,'DAY')
		       WHERE  nPoste = enreg.nPoste AND nLog = enreg.nLog;
	  END IF;	
		  END IF;
	      END IF;
	END IF;
   END LOOP;
   COMMIT;
END calculTemps;
/

SET SERVEROUT ON
EXECUTE calculTemps;
SELECT * FROM Installer;