--exo1 bloc PL/SQL

SET SERVEROUTPUT ON

DECLARE
  v_sequenceInsMax Installer.numIns%TYPE;
  v_nPoste         Installer.nPoste%TYPE;
  v_nLog           Installer.nLog%TYPE; 
  v_dateIns        Installer.dateIns%TYPE;
  v_nSalle         Poste.nSalle%TYPE;
  v_nomLog         Logiciel.nomLog%TYPE; 
BEGIN
 SELECT   numIns, nPoste, nLog, dateIns INTO v_sequenceInsMax, v_nPoste, v_nLog, v_dateIns
    FROM  Installer WHERE numIns = (SELECT MAX(numIns) FROM Installer);
--
  SELECT  nSalle INTO  v_nSalle
    FROM  Poste  WHERE nPoste = v_nPoste;
--
  SELECT  nomLog   INTO  v_nomLog
    FROM  Logiciel WHERE nLog = v_nLog;
--
  DBMS_OUTPUT.PUT_LINE('Derni�re installation en salle : '|| v_nSalle);
  DBMS_OUTPUT.PUT_LINE('--------------------------------------------');
  DBMS_OUTPUT.PUT_LINE('Poste : '|| v_nPoste || ' Logiciel : ' || v_nomLog || ' en date du ' || v_dateIns);
END;
/
