
DROP VIEW SallePoste;
DROP VIEW Installer0;
DROP VIEW SallePrixTotal;
DROP VIEW SalleInterm�diaire;
DROP VIEW SallePrix;
DROP VIEW Poste0;
DROP VIEW LogicielsUnix;


DROP TABLE Rejets;
DROP TABLE PCseuls;
DROP TABLE Softs;
DROP SEQUENCE sequenceIns;


DROP TABLE  Installer;
DROP TABLE  Logiciel;
DROP TABLE  Poste;
DROP TABLE  Types;
DROP TABLE  Salle;
DROP TABLE  Segment;
