--exo2 bloc PL/SQL

ACCEPT s_nSalle        PROMPT 'Num�ro de Salle : '
ACCEPT s_typePoste     PROMPT 'Type de poste : '
VARIABLE g_nbPoste     NUMBER;
VARIABLE g_nbInstall   NUMBER;

DECLARE
BEGIN
  SELECT  COUNT(*) INTO :g_nbPoste
    FROM  Poste  WHERE nSalle = '&s_nSalle' AND typePoste = '&s_typePoste';
--
  SELECT  COUNT(*)  INTO :g_nbInstall
    FROM  Installer 
    WHERE nPoste IN (SELECT nPoste FROM Poste  
                     WHERE nSalle = '&s_nSalle' AND typePoste = '&s_typePoste');
END;
/
PRINT :g_nbPoste;
PRINT :g_nbInstall;