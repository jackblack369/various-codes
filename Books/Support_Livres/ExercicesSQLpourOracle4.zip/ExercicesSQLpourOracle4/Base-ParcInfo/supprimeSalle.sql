CREATE OR REPLACE FUNCTION supprimeSalle(ns IN VARCHAR2) RETURN INTEGER IS
 ligne Salle%ROWTYPE;
BEGIN
-- test exception
 SELECT * INTO ligne FROM Salle WHERE nsalle = ns;
-- suppression
 DELETE FROM Salle WHERE nsalle = ns;
 RETURN 0;
EXCEPTION
	WHEN NO_DATA_FOUND THEN RETURN -1;
	WHEN OTHERS        THEN RETURN -2;
END supprimeSalle;
/

