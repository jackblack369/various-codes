--
CREATE TABLE AvionsdeAF
	(immat CHAR(6), typeAvion CHAR(10), nbHVol NUMBER(10,2),
	CONSTRAINT pk_AvionsdeAF PRIMARY KEY (immat));

CREATE TABLE AvionsdeSING
	(immatriculation CHAR(6), typeAv CHAR(10), prixAchat NUMBER(14,2),
	CONSTRAINT pk_AvionsdeSING PRIMARY KEY (immatriculation));

INSERT INTO AvionsdeAF VALUES ('F-WTSS', 'Concorde', 6570);
INSERT INTO AvionsdeAF VALUES ('F-GLFS', 'A320', 3500);
INSERT INTO AvionsdeAF VALUES ('F-GTMP', 'A340', NULL);

INSERT INTO AvionsdeSING VALUES ('S-ANSI', 'A320', 104500);
INSERT INTO AvionsdeSING VALUES ('S-AVEZ', 'A320', 156000);
INSERT INTO AvionsdeSING VALUES ('S-MILE', 'A330', 198000);
INSERT INTO AvionsdeSING VALUES ('F-GTMP', 'A340', 204500);

----------------
SELECT immat FROM AvionsdeAF INTERSECT SELECT immatriculation FROM AvionsdeSING 
	UNION SELECT immat FROM AvionsdeAF MINUS SELECT immatriculation FROM AvionsdeSING; 
--diff�rent de
SELECT immat FROM AvionsdeAF INTERSECT SELECT immatriculation FROM AvionsdeSING 
	UNION (SELECT immat FROM AvionsdeAF MINUS SELECT immatriculation FROM AvionsdeSING); 
---------------

--INTERSECT 

SELECT typeAvion FROM AvionsdeAF INTERSECT 
SELECT typeAv FROM AvionsdeSING;

SELECT immat, typeAvion FROM AvionsdeAF INTERSECT 
SELECT immatriculation,typeAv FROM AvionsdeSING;

--UNION 

SELECT typeAvion FROM AvionsdeAF UNION 
SELECT typeAv FROM AvionsdeSING;


SELECT typeAvion FROM AvionsdeAF UNION ALL
SELECT typeAv FROM AvionsdeSING;

--MINUS 

SELECT typeAvion FROM AvionsdeAF MINUS
SELECT typeAv FROM AvionsdeSING;


SELECT typeAv FROM AvionsdeSING MINUS
SELECT typeAvion  FROM AvionsdeAF ;


--ordre

SELECT typeAvion FROM AvionsdeAF UNION 
SELECT typeAv FROM AvionsdeSING
ORDER BY typeAvion DESC;


SELECT typeAvion FROM AvionsdeAF UNION 
SELECT typeAv FROM AvionsdeSING
ORDER BY 1 DESC;

--Ordonner un r�sultat
SELECT typeAvion FROM
(SELECT typeAvion FROM AvionsdeAF UNION 
SELECT typeAv FROM AvionsdeSING) ORDER BY typeAvion DESC;

--produit cart�sien
CREATE TABLE Pilote
	(brevet VARCHAR(6) CONSTRAINT pk_Pilote PRIMARY KEY,
	 nom VARCHAR(16), nbHVol NUMBER(7,2), compa CHAR(4));

INSERT INTO Pilote VALUES ('PL-1', 'Gratien Viel', 450, 'AF');
INSERT INTO Pilote VALUES ('PL-2', 'Richard Grin', 1000, 'SING');
INSERT INTO Pilote VALUES ('PL-3', 'Placide Fresnais', 2450, 'CAST');
INSERT INTO Pilote VALUES ('PL-4', 'Daniel Vielle', 5000, 'AF');

--Possibilit�s Pilotes-Avions

SELECT p.brevet, avAF.immat
FROM Pilote p, AvionsdeAF avAF
WHERE p.compa = 'AF';

SELECT p.brevet, avSING.immatriculation
FROM Pilote p, AvionsdeSING avSING
WHERE p.compa = 'SING';

--Ajout colonnes

SELECT immatriculation,prixAchat FROM AvionsdeSING 
UNION 
SELECT immat, 0 FROM AvionsdeAF 
ORDER BY 2 DESC;
--

SELECT immatriculation,1.2*prixAchat px FROM AvionsdeSING 
UNION 
SELECT immat, 0 FROM AvionsdeAF 
ORDER BY px DESC;

DROP TABLE Pilote;
DROP TABLE AvionsdeAF;
DROP TABLE AvionsdeSING;




