--



DROP TABLE Flottants ;

CREATE TABLE Flottants (bfloat BINARY_FLOAT, bdouble BINARY_DOUBLE);

INSERT INTO Flottants VALUES (+3.4e+38f,+1.77e+308d) ;

SELECT * FROM Flottants;

UPDATE Flottants 
	SET bfloat = bfloat/0, bdouble= 2*bdouble;

SELECT * FROM Flottants WHERE bfloat IS INFINITE OR bdouble IS INFINITE;

DELETE FROM Flottants ;
INSERT INTO Flottants VALUES (+3.4e+38f,+1.77e+308d) ;


SELECT TO_BINARY_DOUBLE(13.56767) FROM DUAL;

SELECT TO_BINARY_DOUBLE('-INF') FROM DUAL;

SELECT DUMP(TO_BINARY_DOUBLE(13.56767),10) FROM DUAL;

SELECT DUMP('C.Soutou', 10) "C.Soutou en ASCII" FROM DUAL;

SELECT DUMP('C.Soutou', 17) "C.Soutou en caract�res" FROM DUAL;

--NANVL

DELETE FROM Flottants ;

INSERT INTO Flottants VALUES (+3.4e+38f,+1.77e+308d) ;
INSERT INTO Flottants VALUES ('NaN','NaN') ;

SELECT * FROM Flottants WHERE bfloat IS NOT NAN AND bdouble IS NOT NAN;

SELECT * FROM Flottants;

SELECT NANVL(bfloat,0), NANVL(bdouble,-1) FROM Flottants;

--

DELETE FROM Flottants ;

INSERT INTO Flottants VALUES (1234.56,1234.56) ;

SELECT * FROM Flottants;

SELECT bfloat, bdouble, REMAINDER(bfloat, bdouble) FROM Flottants;


CREATE TABLE FlottantsBis (bfloat1 BINARY_FLOAT, bfloat2 BINARY_FLOAT);

INSERT INTO FlottantsBis VALUES (1234.56,1234.56) ;

SELECT * FROM FlottantsBis;

SELECT bfloat1, bfloat2, REMAINDER(bfloat1, bfloat2) FROM FlottantsBis;




DROP TABLE Flottants ;
DROP TABLE FlottantsBis ;

--