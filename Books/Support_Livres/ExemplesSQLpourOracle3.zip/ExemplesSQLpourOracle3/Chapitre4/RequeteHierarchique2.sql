

---hi�rarchie 10g


DROP TABLE Trajets;

CREATE TABLE Trajets
	(d�part VARCHAR2(10), arriv�e VARCHAR2(10), tempsVol NUMBER(5,2));


INSERT INTO Trajets VALUES ('Paris', 'Blagnac', 1);
INSERT INTO Trajets VALUES ('Paris', 'Lyon', 0.8);
INSERT INTO Trajets VALUES ('Paris', 'Marseille', 0.9);

	INSERT INTO Trajets VALUES ('Blagnac', 'Pau', 0.4);

	INSERT INTO Trajets VALUES ('Lyon', 'Grenoble', 0.3);
	INSERT INTO Trajets VALUES ('Lyon', 'Valence', 0.2);

		INSERT INTO Trajets VALUES ('Grenoble', 'Gap', 0.35);
		INSERT INTO Trajets VALUES ('Valence', 'Ales', 0.25);

	INSERT INTO Trajets VALUES ('Marseille', 'Frejus', 0.2);
	INSERT INTO Trajets VALUES ('Marseille', 'Toulon', 0.15);
	INSERT INTO Trajets VALUES ('Marseille', 'Nimes', 0.35);


SELECT * FROM Trajets;

--colonneSup : d�part
--colonneInf : arriv�e

---

--SYS_CONNECT_BY_PATH

COL chemin FORMAT A30 HEADING "H�las tout part de Paris..."
SELECT LPAD(' ', 2*LEVEL-1) || SYS_CONNECT_BY_PATH(arriv�e, '/') chemin,tempsVol 
	FROM Trajets
	START WITH d�part='Paris'
	CONNECT BY PRIOR arriv�e = d�part;

--CONNECT_BY_ROOT 

--de bas en haut destinations de 2 escales + d�tail du chemin
COL chemin FORMAT A30 HEADING "Chemin..."
SELECT arriv�e "De Paris �", CONNECT_BY_ROOT d�part,
   LEVEL-1 "Pathlen", SYS_CONNECT_BY_PATH(d�part, '/') chemin
   FROM Trajets
   WHERE LEVEL > 1 AND LEVEL < 3
   CONNECT BY PRIOR arriv�e = d�part;


--de bas en haut destinations avec deux escales + d�tail
COL chemin FORMAT A30 HEADING "Chemin..."
SELECT arriv�e "De Paris �", tempsVol, CONNECT_BY_ROOT d�part,
   LEVEL-1 "Pathlen", SYS_CONNECT_BY_PATH(d�part, '/') chemin
   FROM Trajets
   WHERE LEVEL > 2
   CONNECT BY PRIOR arriv�e = d�part;


--de bas en haut destinations avec deux escales + d�tail
COL chemin FORMAT A30 HEADING "Chemin..."
SELECT arriv�e "De Paris �", CONNECT_BY_ROOT arriv�e, SYS_CONNECT_BY_PATH(d�part, '/') chemin
   FROM Trajets
   WHERE LEVEL > 2
   CONNECT BY PRIOR arriv�e = d�part;


SELECT d�part, arriv�e, tempsVol 
	FROM Trajets
	START WITH d�part='Paris'
	CONNECT BY PRIOR arriv�e = d�part;


The following example uses a GROUP BY clause to return the total salary of each employee in 
department 110 and all employees below that employee in the hierarchy:

SELECT d�part, SUM(tempsVol) FROM 
	(
SELECT d�part, arriv�e, tempsVol 
	FROM Trajets
	START WITH d�part='Paris'
	CONNECT BY PRIOR arriv�e = d�part) group by d�part;




SELECT name, SUM(salary) "Total_Salary" FROM (
   SELECT CONNECT_BY_ROOT last_name as name, Salary
      FROM employees
      WHERE department_id = 110
      CONNECT BY PRIOR employee_id = manager_id)
      GROUP BY name;

NAME                      Total_Salary
------------------------- ------------
Gietz                             8300
Higgins                          20300
King                             20300
Kochhar                          20300


DROP TABLE Trajets;
