
--


SELECT REGEXP_INSTR('IUTReims','(IUT)(R(ei)(ms))',1,1,0,'i',3
                    "REGEXP_INSTR" FROM DUAL;


--

SELECT REGEXP_SUBSTR('IUTReims','(IUT)(R(ei)(ms))',1,1,'i',3)
                    "REGEXP_SUBSTR" FROM DUAL;

SELECT REGEXP_SUBSTR('IUTReims','(IUT)(R(ei)(ms))',1,1,'i',7)
                    "REGEXP_SUBSTR" FROM DUAL;

--


SELECT REGEXP_COUNT('IUT-BlagnacIUT', '(IU)T', 1, 'i') REGEXP_COUNT
   FROM DUAL;
