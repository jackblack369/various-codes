-- 
CREATE TABLE Compagnie
	(comp CHAR(4), nomComp CHAR(15), pays CHAR(4));
INSERT INTO Compagnie   VALUES ('SING', 'Singapore AL', 'SG');
INSERT INTO Compagnie	VALUES ('AF','Air France', 'F');
INSERT INTO Compagnie	VALUES ('ALIB','Air Lib', 'F');


CREATE TABLE Affr�tements
	(immat CHAR(5), typeAv CHAR(8),	compa CHAR(4), dateAFF DATE);
INSERT INTO Affr�tements VALUES ('A1', 'A320', 'SING', '13-05-1995');
INSERT INTO Affr�tements VALUES ('A2', 'A340', 'AF', '22-06-1968');
INSERT INTO Affr�tements VALUES ('A3', 'Mercure', 'AF', '05-02-1965');
INSERT INTO Affr�tements VALUES ('A4', 'A330', 'ALIB', '16-01-1965');
INSERT INTO Affr�tements VALUES ('A3', 'Mercure', 'ALIB', '05-03-1942');
INSERT INTO Affr�tements VALUES ('A3', 'Mercure', 'SING', '01-03-1987');


--Division
--inexacte 
SELECT DISTINCT immat, typeAv FROM Affr�tements aliasAff
	WHERE NOT EXISTS
	(SELECT comp FROM Compagnie WHERE pays = 'F'
	MINUS
	SELECT compa FROM Affr�tements WHERE immat = aliasAff.immat);

DELETE FROM Affr�tements WHERE immat='A3' AND compa='SING';

--Division exacte
SELECT DISTINCT immat, typeAv FROM Affr�tements aliasAff
	WHERE NOT EXISTS
	(SELECT comp FROM Compagnie WHERE pays = 'F'
	MINUS
	SELECT compa FROM Affr�tements WHERE immat = aliasAff.immat)
	AND NOT EXISTS
	(SELECT compa FROM Affr�tements WHERE immat = aliasAff.immat
	MINUS
	SELECT comp FROM Compagnie WHERE pays = 'F');

DROP TABLE Compagnie;
DROP TABLE Affr�tements;

