<html> <head> <title>SELECT simple (fetch_all) </title> </head>
<body>
<?php
	$service = "(DESCRIPTION = (ADDRESS = (PROTOCOL = TCP)(HOST = localhost)(PORT = 1521))
		    (CONNECT_DATA = (SERVER = DEDICATED) (SERVICE_NAME = bdcs10g)))";
	$utilisateur = "soutou";
	$mdp = "iut";
//	$cx = oci_connect($utilisateur ,$mdp, $service);
	$cx = oci_connect($utilisateur ,$mdp);

	if (!$cx) 
		{print "L'utilisateur $utilisateur n'a pu se connecter � la base";
		} 
	else 
	{
	// extraction 
	$requete   = "SELECT immat, typeavion, capacite FROM Avion";
	$ordre = oci_parse ($cx, $requete);
	oci_execute ($ordre);
	$nblignes = oci_fetch_all($ordre, $tabresults,2);
	print "nb lignes : ". $nblignes ;
	if ($nblignes > 0) 
	{   	
		print "<table border=1>\n";
   		print"<tr>\n";   		
   		for ($i = 0; $i < $nblignes; $i++) 
		{
      			reset($tabresults);
     			print "<tr>\n";
      			while ($col = each($tabresults)) 
			{   
         		$donn�e = $col['value'];
         		print "<td>$donn�e[$i]</td>\n";
      			}
	 	print "</tr>\n";
   		}
   		print "</table>\n";
	}
	else 
	{ print "Pas de donn�es <br/>\n"; }
	oci_free_statement($ordre);
	oci_close($cx);      
    }
?>
</body> </html>



