<?php
	print "La date Oracle est :";
	$cx = oci_connect("soutou","iut","BDCS10G");
	// extraction de la date syst�me
	$req   = "SELECT SYSDATE FROM DUAL";
	$ordre = oci_parse ($cx, $req);
	oci_execute ($ordre);
	
	$ncols = oci_num_fields ($ordre);
	// affiche les lignes et les colonnes 
	print "<TABLE BORDER=1> ";
	while ($ligne = oci_fetch_array($ordre, OCI_NUM + OCI_RETURN_NULLS)) 
	{
	print "<TR> ";
	for ( $i=0;$i < $ncols; $i++) 
		{print "<TD> $ligne[$i] </TD>" ;}
	print "</TR> ";
	}
// libere les ressources
oci_free_statement($ordre);
oci_close($conn);
?>