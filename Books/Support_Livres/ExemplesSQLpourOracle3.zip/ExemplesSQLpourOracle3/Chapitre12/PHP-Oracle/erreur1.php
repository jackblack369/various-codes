<html> <head> <title>Erreur connexion </title> </head>
<body>
<?php
	$service = "(DESCRIPTION = (ADDRESS = (PROTOCOL = TCP)(HOST = toto)(PORT = 1521))
		    (CONNECT_DATA = (SERVER = DEDICATED) (SERVICE_NAME = bdcs10g)))";
	$utilisateur = "soutou";
	$mdp = "iut";
	$cx = @oci_connect($utilisateur ,$mdp, $service);
	if (!$cx) 
		{print "L'utilisateur <B>$utilisateur</B> n'a pu se connecter � la base <BR>";
		 $taberr = oci_error();
		 print "<B>Message : </B>" . $taberr['message'];
		 print "<BR><B>Code    : </B>" . $taberr['code'];
		 } 
	else 
		{
		// rien de sp�cial
		oci_close($cx);
		}
?>
</body> </html>
