<html> <head> <title>SELECT (fetch_array + define_by_name) </title> </head>
<body>
<?php
	$service = "(DESCRIPTION = (ADDRESS = (PROTOCOL = TCP)(HOST = localhost)(PORT = 1521))
		    (CONNECT_DATA = (SERVER = DEDICATED) (SERVICE_NAME = bdcs10g)))";
	$utilisateur = "soutou";
	$mdp = "iut";
	$cx = oci_connect($utilisateur ,$mdp, $service);
	if (!$cx) 
		{print "L'utilisateur $utilisateur n'a pu se connecter � la base";
		} 
	else 
		{
	// extraction 
	$requete   = "SELECT * FROM Avion";
	$ordre = oci_parse ($cx, $requete);

	oci_define_by_name($ordre, "IMMAT", $immatriculation);
	oci_define_by_name($ordre, "TYPEAVION", $typav);

	oci_execute ($ordre);
		
        print "<B>Liste des avions</B>";
	print "<TABLE BORDER=1> ";
	while (oci_fetch_array($ordre))
		{
		print "<TR> <TD> $immatriculation </TD>" ;
		print "     <TD> $typav     </TD> </TR> ";
		}
	print "</TABLE> ";
	// libere les ressources
	oci_free_statement($ordre);
	oci_close($cx);
	}
?>
</body> </html>