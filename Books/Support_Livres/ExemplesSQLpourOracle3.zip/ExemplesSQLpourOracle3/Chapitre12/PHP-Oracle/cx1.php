<?php
	$service = "(DESCRIPTION = (ADDRESS = (PROTOCOL = TCP)(HOST = camparols)(PORT = 1521))
		    (CONNECT_DATA = (SERVER = DEDICATED) (SERVICE_NAME = bdcs10g)))";
	$utilisateur = "soutou";
	$mdp = "iut";
	print "Avant la connexion <BR>";
//	$cx = oci_connect($utilisateur ,$mdp, $service );
	$cx = oci_connect($utilisateur ,$mdp);
	print "La connexion <B>passe </B>avec la description compl�te du service! ";
	oci_close($cx);
?>
