<html> <head> <title>SELECT simple (fetch_array) </title> </head>
<body>
<?php
	$service = "(DESCRIPTION = (ADDRESS = (PROTOCOL = TCP)(HOST = localhost)(PORT = 1521))
		    (CONNECT_DATA = (SERVER = DEDICATED) (SERVICE_NAME = bdcs10g)))";
	$utilisateur = "soutou";
	$mdp = "iut";
	$cx = oci_connect($utilisateur ,$mdp, $service);
	if (!$cx) 
		{print "L'utilisateur $utilisateur n'a pu se connecter � la base";
		} 
	else 
		{
	// extraction 
	$requete   = "SELECT * FROM Avion WHERE compa = 'AF'";
	$ordre = oci_parse ($cx, $requete);
	oci_execute ($ordre);
	
	$ncols = oci_num_fields ($ordre);
	// affiche les lignes et les colonnes 
        print "<B>Avions de la compagnie 'AF'</B>";
	print "<TABLE BORDER=1> ";
	while ($ligne = oci_fetch_array($ordre, OCI_NUM + OCI_RETURN_NULLS)) 
		{
		print "<TR> ";
		for ( $i=0;$i < $ncols; $i++) 
			{print "<TD> $ligne[$i] </TD>" ;}
		print "</TR> ";
		}
	print "</TABLE> ";
	oci_free_statement($ordre);
	oci_close($cx);
	}
?>
</body> </html>