<html> <head> <title>Appel d'une proc�dure catalogu�e </title> </head>
<body>
<?php
	$service = "(DESCRIPTION = (ADDRESS = (PROTOCOL = TCP)(HOST = localhost) (PORT = 1521))
		    (CONNECT_DATA = (SERVER = DEDICATED) (SERVICE_NAME = bdcs10g)))";
	$utilisateur = "soutou";
	$mdp = "iut";
	$cx = oci_connect($utilisateur ,$mdp, $service);
	if (!$cx) 
		{print "L'utilisateur <B>$utilisateur</B> n'a pu se connecter � la base <BR>";
		 } 
	else 
		{
		// d�claration et analyse de la proc�dure
		$procedure = "BEGIN augmenteCap(:nbre,:compag); END;";
		$ordre = oci_parse ($cx, $procedure);
		// liaison des variables Oracle et PHP
		// -1 indique que c'est la longueur de $nb qui est utilis�e pour le bind
		$nb   = 50;
		$comp = 'AF  ';
		oci_bind_by_name ($ordre, ":nbre"  , $nb,   -1);
		oci_bind_by_name ($ordre, ":compag", $comp, -1);

		oci_execute ($ordre);
		print "Proc�dure r�alis�e correctement.";
		oci_free_statement ($ordre);
		oci_close($cx);
		}
?>
</body> </html>
