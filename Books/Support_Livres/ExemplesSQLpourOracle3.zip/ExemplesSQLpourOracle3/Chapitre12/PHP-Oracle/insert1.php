<html> <head> <title>INSERT simple </title> </head>
<body>
<?php
	$service = "(DESCRIPTION = (ADDRESS = (PROTOCOL = TCP)(HOST = localhost)(PORT = 1521))
		    (CONNECT_DATA = (SERVER = DEDICATED) (SERVICE_NAME = bdcs10g)))";
	$utilisateur = "soutou";
	$mdp = "iut";
	$cx = oci_connect($utilisateur ,$mdp, $service);
	if (!$cx) 
		{print "L'utilisateur $utilisateur n'a pu se connecter � la base";
		} 
	else 
		{
		// ordre de mise � jour
		$insert1 = "INSERT INTO Compagnie VALUES ('AL', 'Air Lib') ";
		$ordre   = oci_parse ($cx, $insert1);
		//oci_execute($ordre, OCI_COMMIT_ON_SUCCESS);
		oci_execute($ordre);
		oci_commit($cx);

		print "<BR>". oci_num_rows($ordre)." ligne(s) trait�e(s).<BR>";
		// libere les ressources
		oci_free_statement($ordre);
		oci_close($cx);
		}
?>
</body> </html>