CREATE OR REPLACE PROCEDURE augmenteCap (nbre IN NUMBER, compag IN CHAR)
AS
BEGIN
   UPDATE Avion SET capacite = capacite + nbre
	WHERE compa = compag;
   COMMIT;
 END;
/
