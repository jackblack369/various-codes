CREATE OR REPLACE PROCEDURE afficheComp(codecomp IN VARCHAR2 DEFAULT NULL) IS
 v_nom Compagnie.nomComp%TYPE;
BEGIN
HTP.htmlOpen; 
HTP.bodyOpen;
SELECT nomComp INTO v_nom FROM Compagnie WHERE comp = codecomp;
HTP.header(3,'D�tail de la compagnie ' || codecomp ||'/ ' || v_nom );
HTP.hr;
HTP.bodyClose;
HTP.htmlClose;
END;
/