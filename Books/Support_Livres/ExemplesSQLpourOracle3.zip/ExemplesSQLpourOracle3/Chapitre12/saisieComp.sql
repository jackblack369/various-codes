CREATE OR REPLACE PROCEDURE saisieComp(comp IN VARCHAR2 DEFAULT NULL) IS
BEGIN
HTP.htmlOpen; HTP.bodyOpen;
HTP.header(1,'Avions d''une compagnie','CENTER');
HTP.hr;
HTP.formOpen('saisieComp');
HTP.print  ('Num�ro de la compagnie : ');
HTP.formText('comp');
HTP.hr;
HTP.formSubmit(cvalue=>'Executer');
HTP.formReset(cvalue=>'�Annuler');
IF comp IS NOT NULL THEN
  afficheAvions(comp);
ELSE
  HTP.print('<BR>Saisir un code compagnie <BR>');
END IF;
HTP.formClose;
HTP.bodyClose; 
HTP.htmlClose;
END;
/
