CREATE OR REPLACE PROCEDURE NousSommesLe AS
BEGIN
 HTP.htmlOpen;
 HTP.headOpen;
 HTP.title('Quelle heure?');
 HTP.headClose;
 HTP.bodyOpen;
 HTP.header(1, 'Nous sommes le : ' ||TO_CHAR(SYSDATE,'Day DD Month YYYY, HH24:MM:SS') );
 HTP.bodyClose;
 HTP.htmlClose;
END;
/