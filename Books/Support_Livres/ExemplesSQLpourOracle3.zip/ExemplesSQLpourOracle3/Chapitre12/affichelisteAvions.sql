CREATE or replace PROCEDURE affichelisteAvions(cp IN VARCHAR2) IS
 CURSOR curs IS SELECT immat, typeAvion, cap FROM Avion WHERE comp = cp;
 v_immat Avion.immat%TYPE;
 v_type Avion.typeAvion%TYPE;
 v_cap Avion.cap%TYPE;
BEGIN
HTP.htmlOpen; HTP.bodyOpen;
HTP.header(1,'Flotte de la compagnie '|| cp);
HTP.line;
HTP.ulistOpen;
OPEN curs;
LOOP
 FETCH curs INTO v_immat,v_type,v_cap;
 HTP.listItem( v_immat || ' type : ' || v_type || ' capacit� : ' || v_cap);
 EXIT WHEN curs%NOTFOUND;
END LOOP;
HTP.ulistClose;
HTP.bodyClose; 
HTP.htmlClose;
END;
/
