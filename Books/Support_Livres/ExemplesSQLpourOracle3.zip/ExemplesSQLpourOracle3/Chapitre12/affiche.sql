CREATE OR REPLACE PROCEDURE affiche IS
CURSOR curs IS SELECT immat, typeavion, comp FROM Avion;
BEGIN
HTP.htmlOpen; 
HTP.bodyOpen;
HTP.header(1,'Flotte');
FOR ligne IN curs LOOP
  HTP.anchor('afficheComp?codecomp='||TO_CHAR(ligne.comp), 'Immatriculation : '||ligne.immat);
  HTP.print(' '||ligne.typeavion);
  HTP.br;
END LOOP;
HTP.bodyClose;
HTP.htmlClose;
END;
/