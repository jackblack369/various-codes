
CREATE TABLE Compagnie
	(comp CHAR(4), nrue NUMBER(3), 
	rue CHAR(20), ville CHAR(15) DEFAULT 'Paris', nomComp CHAR(15),
 	CONSTRAINT pk_Compagnie PRIMARY KEY(comp));

CREATE TABLE Pilote
	(brevet CHAR(6), nom CHAR(15), nbHVol NUMBER(7,2), compa CHAR(4),
	 CONSTRAINT pk_Pilote PRIMARY KEY(brevet),
	 CONSTRAINT nn_nom    CHECK (nom IS NOT NULL),
	 CONSTRAINT ck_nbHVol CHECK (nbHVol BETWEEN 0 AND 20000),
	 CONSTRAINT un_nom    UNIQUE (nom),
	 CONSTRAINT fk_Pil_compa_Comp FOREIGN KEY(compa) REFERENCES Compagnie(comp));

INSERT INTO Compagnie
   VALUES ('SING', 7, 'Camparols', 'Singapour', 'Singapore AL');
INSERT INTO Compagnie
	VALUES ('AF', 124, 'Port Royal', DEFAULT, 'Air France');
INSERT INTO Compagnie
	VALUES ('AN1', NULL, 'Hoche', 'Blagnac', 'Air Nul1');
INSERT INTO Compagnie(comp, nrue, rue, nomComp)
	VALUES ('AC', 8, 'Champs Elys�es', 'Castanet Air');
INSERT INTO Compagnie(comp, rue, ville, nomComp)
	VALUES ('AN2', 'Foch', 'Blagnac', 'Air Nul2');
INSERT INTO Pilote
 VALUES ('PL-1', 'Am�lie Sulpice', 450, 'AF');
INSERT INTO Pilote
 VALUES ('PL-2', 'Thomas Sulpice', 900, 'AF');
INSERT INTO Pilote
 VALUES ('PL-3', 'Paul Soutou', 1000, 'SING');

SELECT * FROM Pilote;
SELECT * FROM Compagnie;

DELETE FROM Pilote WHERE compa = 'AF';

DELETE Compagnie WHERE comp = 'AF';

DELETE FROM Compagnie WHERE comp = 'SING';


DROP TABLE Pilote;
DROP TABLE Compagnie;

