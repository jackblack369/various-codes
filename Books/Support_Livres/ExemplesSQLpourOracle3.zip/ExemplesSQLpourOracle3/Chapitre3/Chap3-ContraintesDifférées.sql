

CREATE TABLE Compagnie
	(comp CHAR(4), nrue NUMBER(3), rue CHAR(20), ville CHAR(15), nomComp CHAR(15),
 	CONSTRAINT pk_Compagnie PRIMARY KEY(comp) NOT DEFERRABLE INITIALLY IMMEDIATE);

CREATE TABLE Avion
	(immat CHAR(6), typeAvion CHAR(15), nbhVol NUMBER(10,2), proprio CHAR(4),
	CONSTRAINT fk_Avion_comp_Compag FOREIGN KEY(proprio) REFERENCES Compagnie(comp)
	DEFERRABLE INITIALLY DEFERRED,
	CONSTRAINT pk_Avion PRIMARY KEY(immat));

--passe
INSERT INTO Avion
   VALUES ('F-WTSS', 'Concorde', 6570, 'SING');

--validation
COMMIT;

DROP TABLE Avion;
CREATE TABLE Avion
	(immat CHAR(6), typeAvion CHAR(15), nbhVol NUMBER(10,2), proprio CHAR(4),
	CONSTRAINT fk_Avion_comp_Compag FOREIGN KEY(proprio) REFERENCES Compagnie(comp)
	DEFERRABLE INITIALLY IMMEDIATE,
	CONSTRAINT pk_Avion PRIMARY KEY(immat));

INSERT INTO Avion
   VALUES ('F-WTSS', 'Concorde', 6570, 'SING');

SET CONSTRAINTS fk_Avion_comp_Compag DEFERRED;

INSERT INTO Avion
   VALUES ('F-WTSS', 'Concorde', 6570, 'SING');

COMMIT;


DROP TABLE Avion;
DROP TABLE Compagnie;

CREATE TABLE Compagnie
	(comp CHAR(4), nrue NUMBER(3), rue CHAR(20), ville CHAR(15), nomComp CHAR(15),
 	CONSTRAINT pk_Compagnie PRIMARY KEY(comp) NOT DEFERRABLE INITIALLY IMMEDIATE);

CREATE TABLE Avion
	(immat CHAR(6), typeAvion CHAR(15), nbhVol NUMBER(10,2), proprio CHAR(4),
	CONSTRAINT fk_Avion_comp_Compag FOREIGN KEY(proprio) REFERENCES Compagnie(comp)
	DEFERRABLE INITIALLY DEFERRED,
	CONSTRAINT pk_Avion PRIMARY KEY(immat));


ALTER SESSION SET CONSTRAINTS = IMMEDIATE;
ALTER SESSION SET CONSTRAINTS = DEFERRED;
SET CONSTRAINTS ALL IMMEDIATE;
SET CONSTRAINTS ALL DEFERRED;

--

DROP TABLE Avion;
DROP TABLE Compagnie;
CREATE TABLE Compagnie
	(comp CHAR(4), nrue NUMBER(3), rue CHAR(20), ville CHAR(15), nomComp CHAR(15),
 	CONSTRAINT pk_Compagnie PRIMARY KEY(comp) NOT DEFERRABLE INITIALLY IMMEDIATE);

CREATE TABLE Avion
	(immat CHAR(6), typeAvion CHAR(15), proprio CHAR(4),
	CONSTRAINT fk_Avion_comp_Compag FOREIGN KEY(proprio) REFERENCES Compagnie(comp) DISABLE,
	CONSTRAINT pk_Avion PRIMARY KEY(immat));

INSERT INTO Compagnie
   VALUES ('SING', 7, 'Camparols', 'Singapour', 'Singapore AL');

INSERT INTO Avion
   VALUES ('F-WTSS', 'Concorde', 'Toto');

ALTER TABLE Avion 
	ENABLE NOVALIDATE CONSTRAINT fk_Avion_comp_Compag;

--interdit
INSERT INTO Avion
   VALUES ('F-TB20', 'Concorde', 'Toto');

--possible
INSERT INTO Avion
   VALUES ('F-ABCD', 'Concorde', 'SING');

SELECT * FROM Avion;


--
DROP TABLE Avion;
DROP TABLE Compagnie;

CREATE TABLE Compagnie
	(comp CHAR(4), nrue NUMBER(3), rue CHAR(20), ville CHAR(15), nomComp CHAR(15),
 	CONSTRAINT pk_Compagnie PRIMARY KEY(comp) NOT DEFERRABLE INITIALLY IMMEDIATE);

CREATE TABLE Avion
	(immat CHAR(6), typeAvion CHAR(15), proprio CHAR(4),
	CONSTRAINT fk_Avion_comp_Compag FOREIGN KEY(proprio) REFERENCES Compagnie(comp),
	CONSTRAINT pk_Avion PRIMARY KEY(immat));

INSERT INTO Compagnie
   VALUES ('SING', 7, 'Camparols', 'Singapour', 'Singapore AL');

INSERT INTO Avion
   VALUES ('F-WTSS', 'Concorde', 'SING');

ALTER TABLE Avion 
	DISABLE CONSTRAINT fk_Avion_comp_Compag;
--permis
INSERT INTO Avion
   VALUES ('F-TB20', 'Concorde', 'Toto');

--interdit car le dernier avion ne v�rifie plus
ALTER TABLE Avion 
	DISABLE VALIDATE CONSTRAINT fk_Avion_comp_Compag;

SELECT * FROM Avion;

DROP TABLE Avion;
DROP TABLE Compagnie;

--


CREATE TABLE Pilote
 (brevet CHAR(6), nom CHAR(30) CONSTRAINT nn_nom NOT NULL DEFERRABLE INITIALLY DEFERRED DISABLE VALIDATE, 
 nbHVol NUMBER(7,2),
 CONSTRAINT ck_nbHVol CHECK (nbHVol BETWEEN 0 AND 20000) DEFERRABLE INITIALLY IMMEDIATE ENABLE NOVALIDATE,
 CONSTRAINT pk_Pilote PRIMARY KEY(brevet));

ALTER TABLE Pilote 
	MODIFY CONSTRAINT nn_nom INITIALLY IMMEDIATE ENABLE NOVALIDATE;
		
ALTER TABLE Pilote 
	MODIFY CONSTRAINT ck_nbHVol INITIALLY DEFERRED DISABLE VALIDATE;
DROP TABLE Pilote;




