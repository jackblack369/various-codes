
CREATE TABLE Pilote
(brevet VARCHAR2(4), nom VARCHAR2(20));

INSERT INTO Pilote
 VALUES ('PL-1', 'Agn�s Labat');


ALTER TABLE Pilote
      ADD (nbHVol NUMBER(7,2));

ALTER TABLE Pilote
      ADD (compa VARCHAR2(4) DEFAULT 'AF',
           ville VARCHAR2(30) DEFAULT 'Paris' NOT NULL);

SELECT * FROM Pilote;

ALTER TABLE Pilote
      RENAME COLUMN ville TO adresse;

ALTER TABLE Pilote
      MODIFY compa VARCHAR(6) DEFAULT 'SING';

INSERT INTO Pilote (brevet, nom)
 VALUES ('PL-2', 'Laurent Boutrand');

SELECT * FROM Pilote;

ALTER TABLE Pilote
      MODIFY compa CHAR(4) NOT NULL;


ALTER TABLE Pilote
      MODIFY compa NULL;

SELECT * FROM Pilote;

ALTER TABLE Pilote DROP COLUMN adresse;

SELECT * FROM Pilote;

ALTER TABLE Pilote SET UNUSED COLUMN compa;

SELECT * FROM USER_UNUSED_COL_TABS;

ALTER TABLE Pilote DROP UNUSED COLUMNS;

DESC Pilote

DROP TABLE Pilote;
