
--virtual colonnes

DROP TABLE Avion;

CREATE TABLE Avion
	(immat CHAR(6), typeAvion CHAR(15), nbhVol NUMBER(10,2), age NUMBER(4,1), 
	 freqVolMois GENERATED ALWAYS AS (nbhVol/age/12) VIRTUAL, nbPax NUMBER(3), 
	CONSTRAINT pkAvion PRIMARY KEY(immat));

INSERT INTO Avion (immat,typeAvion,nbhVol,age,nbPax)
   VALUES ('F-WTSS', 'Concorde', 20000, 18, 90);

INSERT INTO Avion (immat,typeAvion,nbhVol,age,nbPax)
   VALUES ('F-GHTY', 'A380', 450, 0.5, 460);

SELECT immat,freqVolMois  FROM Avion;

DESC Avion;

ALTER TABLE Avion
	ADD heurePax NUMBER(10,2) AS (nbhVol/age) CHECK (heurePax BETWEEN 0 AND 2000) NOT NULL;

DESC Avion;

SELECT immat,heurePax  FROM Avion;

--Table en lecture seule

ALTER TABLE Avion READ ONLY;

INSERT INTO Avion (immat,typeAvion,nbhVol,age,nbPax)
   VALUES ('F-NEW', 'A318', 90, 1, 140);


ALTER TABLE Avion READ WRITE;

INSERT INTO Avion (immat,typeAvion,nbhVol,age,nbPax)
   VALUES ('F-NEW', 'A318', 90, 1, 140);

SELECT immat,heurePax  FROM Avion;

DROP TABLE Avion;

    
---

