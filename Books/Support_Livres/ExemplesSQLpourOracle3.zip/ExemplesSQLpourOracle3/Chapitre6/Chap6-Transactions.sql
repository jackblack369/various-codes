--Transactions
SET SERVEROUTPUT ON

CREATE TABLE Compagnie
	(comp VARCHAR2(4), nrue NUMBER(3), rue VARCHAR2(20), ville VARCHAR2(15), nomComp VARCHAR2(15),
 	CONSTRAINT pk_Compagnie PRIMARY KEY(comp));
INSERT INTO Compagnie	VALUES ('AF', 124, 'Port Royal', 'Paris', 'Air France');
INSERT INTO Compagnie   VALUES ('SING', 7, 'Camparols', 'Singapour', 'Singapore AL');
INSERT INTO Compagnie   VALUES ('CAST', 1, 'G. Brassens', 'Blagnac', 'Castanet AL');

SELECT * FROM Compagnie;

COMMIT;
BEGIN
 INSERT INTO Compagnie VALUES ('C1', 1, 'Brassens', 'Blagnac', 'C1');
END;
/
SELECT * FROM Compagnie;

--sortie en cassant la fen�tre SQL*Plus
-->C1 pas dans la base 
--sortie avec exit sous SQL*Plus 
-->C1 dans la base 

BEGIN
 INSERT INTO Compagnie VALUES ('C2',2, 'Place Brassens', 'Blagnac', 'Easy Jet');
 SAVEPOINT P1;
 UPDATE Compagnie SET nrue = 125 WHERE comp = 'AF';
 UPDATE Compagnie SET ville = 'Castanet' WHERE comp = 'C1';
 SAVEPOINT P2;
 DELETE FROM Compagnie WHERE comp = 'C1';
 SAVEPOINT P3;
--a
-- ROLLBACK TO P1;
--b
--ROLLBACK TO P2;
--c
  ROLLBACK TO P3;
--ROLLBACK;
-- COMMIT; 
END;
/
SELECT * FROM Compagnie;

DROP TABLE Compagnie;

