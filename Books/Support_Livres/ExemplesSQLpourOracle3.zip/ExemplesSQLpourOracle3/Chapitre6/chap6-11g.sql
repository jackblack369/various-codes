
--CONTINUE

SET SERVEROUT ON

DECLARE
  x NUMBER := 0;
BEGIN
  LOOP 
    -- On arrive ici apr�s le CONTINUE
    DBMS_OUTPUT.PUT_LINE ('Dans la boucle, x = ' || TO_CHAR(x));
    x := x + 1;
    IF (x < 3) THEN
      CONTINUE;
    END IF;
    DBMS_OUTPUT.PUT_LINE ('Apr�s CONTINUE, x = ' || TO_CHAR(x));
    EXIT WHEN (x = 5);
  END LOOP;
  DBMS_OUTPUT.PUT_LINE ('Apr�s la structure,  x = ' || TO_CHAR(x));
END;
/


--CONTINUE WHEN 

DECLARE
  x NUMBER := 0;
BEGIN
  LOOP 
    -- On arrive ici apr�s le CONTINUE
    DBMS_OUTPUT.PUT_LINE ('Dans la boucle, x = ' || TO_CHAR(x));
    x := x + 1;
    CONTINUE WHEN x < 3;
    DBMS_OUTPUT.PUT_LINE ('Apr�s CONTINUE, x = ' || TO_CHAR(x));
    EXIT WHEN (x = 5);
  END LOOP;
  DBMS_OUTPUT.PUT_LINE ('Apr�s la structure,  x = ' || TO_CHAR(x));
END;
/

-- S�quences


DROP SEQUENCE seqAff;
DROP TABLE Affreter;

CREATE TABLE Affreter
	(numAff  NUMBER(5),comp CHAR(4), immat CHAR(6), dateAff DATE, nbPax NUMBER(3),
	CONSTRAINT pk_Affreter PRIMARY KEY (numAff));

CREATE SEQUENCE seqAff
  MAXVALUE 10000
  NOMINVALUE;

-- ALTER

--SELECT seqAff.CURRVAL "seqAff.CURRVAL" FROM DUAL;

INSERT INTO Affreter VALUES (seqAff.NEXTVAL,'AF','F-WTSS',SYSDATE,85);
INSERT INTO Affreter VALUES (seqAff.NEXTVAL,'SING','F-GAFU','05-02-2007',155);

SELECT * FROM Affreter ;

SET SERVEROUT ON
DECLARE
  seq_valeur NUMBER;
BEGIN
  seq_valeur := seqAff.CURRVAL;
  DBMS_OUTPUT.PUT_LINE
    ('Pour l''instant, il y a ' ||TO_CHAR(seq_valeur)||' affr�tements.');
  seq_valeur := seqAff.NEXTVAL;
  INSERT INTO Affreter VALUES (seq_valeur,'AF','F-WOWW',SYSDATE-5, 490);
END;
/


SELECT * FROM Affreter ;

DROP SEQUENCE seqAff;
DROP TABLE Affreter;
--