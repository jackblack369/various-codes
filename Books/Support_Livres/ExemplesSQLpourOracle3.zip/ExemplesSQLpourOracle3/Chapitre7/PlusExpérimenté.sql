
CREATE OR REPLACE PROCEDURE PlusExp�riment�
 (pcomp IN OUT VARCHAR2, pnomPil OUT VARCHAR2, pheuresVol OUT NUMBER) 
IS
	p1 NUMBER;
BEGIN
	IF (pcomp IS NULL) THEN
        	SELECT	COUNT(*) INTO p1 FROM Pilote
			WHERE   nbHVol =  (SELECT MAX(nbHVol) FROM Pilote);
	ELSE
        	SELECT	COUNT(*) INTO p1 FROM Pilote
			WHERE   nbHVol =  (SELECT MAX(nbHVol) FROM Pilote WHERE comp = pcomp)
			AND     comp = pcomp;
	END IF;
	IF p1 = 0 THEN
		DBMS_OUTPUT.PUT_LINE('Aucun pilote n''est le plus exp�riment�');
	ELSIF p1 > 1 THEN
		DBMS_OUTPUT.PUT_LINE('Plusieurs pilotes sont les plus exp�riment�s');
	ELSE
		IF (pcomp IS NULL) THEN
			SELECT	nom, nbHVol, comp INTO pnomPil, pheuresVol, pcomp 
			FROM Pilote
			WHERE   nbHVol =  (SELECT MAX(nbHVol) FROM Pilote);
		ELSE
			SELECT	nom, nbHVol INTO pnomPil, pheuresVol 
			FROM Pilote
			WHERE   nbHVol =  (SELECT MAX(nbHVol) FROM Pilote WHERE comp = pcomp)
			AND     comp = pcomp;
		END IF;
	END IF;
END PlusExp�riment�;
/