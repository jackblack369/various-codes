
--FOLLOWS 

DROP TABLE TypeAvion;
CREATE TABLE TypeAvion (typa VARCHAR2(5), nomtype VARCHAR2(30));

CREATE OR REPLACE TRIGGER Trig_follows_1
BEFORE INSERT ON TypeAvion
FOR EACH ROW
BEGIN
  DBMS_OUTPUT.put_line('Trig_follows_1 en ex�cution');
END;
/

CREATE OR REPLACE TRIGGER Trig_follows_2
BEFORE INSERT ON TypeAvion
FOR EACH ROW
BEGIN
  DBMS_OUTPUT.put_line('Trig_follows_2 en ex�cution');
END;
/

SET SERVEROUT ON

INSERT INTO TypeAvion VALUES ('A320', 'Bir�acteur Airbus 320');

--les r�f�rences avant ne sont pas possible

CREATE OR REPLACE TRIGGER Trig_follows_1
BEFORE INSERT ON TypeAvion
FOR EACH ROW
FOLLOWS Trig_follows_2
BEGIN
  DBMS_OUTPUT.put_line('Trig_follows_1 en ex�cution');
END;
/

INSERT INTO TypeAvion VALUES ('A330', 'Bir�acteur Airbus 330');

DROP TABLE TypeAvion;

----ENABLE / DISABLE



DROP TABLE TypeAvion;
CREATE TABLE TypeAvion (typa VARCHAR2(5), nomtype VARCHAR2(30));

CREATE OR REPLACE TRIGGER Trig_follows_1
BEFORE INSERT ON TypeAvion
FOR EACH ROW
DISABLE
BEGIN
  DBMS_OUTPUT.put_line('Trig_follows_1 en ex�cution');
END;
/


SET SERVEROUT ON

INSERT INTO TypeAvion VALUES ('A320', 'Bir�acteur Airbus 320');

DROP TABLE TypeAvion;

---


DROP TABLE TypeAvion;
DROP TABLE TypeAvionBis;

CREATE TABLE TypeAvion    (typa VARCHAR2(5), nomtype VARCHAR2(30));
CREATE TABLE TypeAvionBis (typa VARCHAR2(5), nomtype VARCHAR2(30));

INSERT INTO TypeAvion VALUES ('A320', 'Bir�acteur Airbus 320');
INSERT INTO TypeAvion VALUES ('A340', 'Quadrir�acteur Airbus 340');


DROP TRIGGER TrigCompose;
CREATE TRIGGER TrigCompose
  FOR  DELETE OR INSERT ON TypeAvionBis 
 COMPOUND TRIGGER
   TYPE typav_tytab IS TABLE OF VARCHAR2(30) INDEX BY BINARY_INTEGER;
   tab  typav_tytab;
   i    NUMBER := 0;
  BEFORE STATEMENT IS
  BEGIN
      i := i+1;
      CASE
      WHEN INSERTING THEN
        tab(i) := 'Avant insertion STATEMENT';
      WHEN DELETING THEN
        tab(i) := 'Avant suppression STATEMENT';
    END CASE;
  END BEFORE STATEMENT;
  AFTER STATEMENT IS
  BEGIN
      i := i+1;
      tab(i) := 'Apr�s STATEMENT';
	FOR i IN 1 .. tab.last LOOP
      		DBMS_OUTPUT.PUT_LINE(tab(i));
   	END LOOP;
  END AFTER STATEMENT;
  BEFORE EACH ROW IS 
   BEGIN
     i := i+1;
     tab(i) := 'Avant �v�nement niveau ligne';
  END BEFORE EACH ROW;
  AFTER EACH ROW IS
  BEGIN
     i := i+1;
      CASE
      WHEN INSERTING THEN
        tab(i) := :NEW.typa||' ins�r�';
      WHEN DELETING THEN
        tab(i) := :NEW.typa||' supprim�';
    END CASE;
  END AFTER EACH ROW;

END TrigCompose;
/
SHOW ERROR


SET SERVEROUT ON


--
INSERT INTO TypeAvionBis SELECT * FROM TypeAvion;

--

DELETE FROM TypeAvionBis ;

DROP TABLE TypeAvion;
DROP TABLE TypeAvionBis;

--
--mutating

DROP TABLE Trace ;
CREATE TABLE Trace (evenement VARCHAR2(100));

DROP TABLE TypeAvion;
CREATE TABLE TypeAvion    (typa VARCHAR2(5), nomtype VARCHAR2(30));

INSERT INTO TypeAvion VALUES ('A320', 'Bir�acteur Airbus 320');
INSERT INTO TypeAvion VALUES ('A340', 'Quadrir�acteur Airbus 340');

CREATE OR REPLACE TRIGGER TrigMutant1
 FOR INSERT ON Trace
 COMPOUND TRIGGER
 v_nombre NUMBER;
 BEFORE STATEMENT IS
  BEGIN
    SELECT COUNT(*) INTO v_nombre FROM Trace;
  END BEFORE STATEMENT;
  AFTER EACH ROW IS
  BEGIN
   DBMS_OUTPUT.PUT_LINE ('Nombre de traces : ' || v_nombre);
  END AFTER EACH ROW;
END;
/

SET SERVEROUT ON

--
INSERT INTO Trace VALUES ('Lisez Programmez!');
INSERT INTO Trace VALUES ('C''est tellement bien.');
--

INSERT INTO Trace SELECT nomtype from TypeAvion;
INSERT INTO Trace VALUES ('Insertion le ' || TO_CHAR(SYSDATE,'DD-MM-YYYY HH24:MI:SS'));

SELECT * FROM Trace;


INSERT INTO Trace SELECT nomtype from TypeAvion;


INSERT INTO Trace VALUES ('Insertion le '||TO_CHAR(SYSDATE,'DD-MM-YYYY HH24:MI:SS'));

SELECT * FROM Trace;

DROP TABLE Trace ;
DROP TABLE TypeAvion;