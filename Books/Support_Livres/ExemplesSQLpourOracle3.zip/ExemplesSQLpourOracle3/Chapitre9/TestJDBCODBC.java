import java.sql.*;
class TestJDBCODBC
{  
public static void main (String args []) throws SQLException
{  
try 
	{
	 System.out.println("Initialisation de la connexion a la base de donnees...");
	 Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
	} catch (ClassNotFoundException ex)
	{ System.out.println ("Probl�me au chargement");	}
try 
	{
	System.out.println("Avant la connexion a la base de donnees...");
	Connection conn = DriverManager.getConnection("jdbc:odbc:sourcebaseGTR","","");
	Statement stmt = conn.createStatement ();
	System.out.println ("Connexion ODBC OK.");       }
catch(SQLException ex)
	{	System.out.println("Erreur connexion \n");
	while ((ex != null))
		{
	System.out.println("\nStatut SQL : "+ ex.getSQLState());
	System.out.println("\nMessage : "+ ex.getMessage());
	System.out.println("\nCode Erreur: "+ ex.getErrorCode());
	ex = ex.getNextException(); } } } }