import java.sql.*;
import oracle.jdbc.driver.*;

class CallableFonction
{  
public static void main (String args []) throws SQLException
{  
try{
 DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
 Connection cx = DriverManager.getConnection("jdbc:oracle:thin:@CAMPAROLS:1521:BDSoutou","soutou","ingres");

 String ordreSQL                 = "{? = call LeNomCompagnieEst(?)}";
 CallableStatement �tatAppelable = cx.prepareCall(ordreSQL);
 
   // Affectation de valeurs pour les champs param�trables
   �tatAppelable.registerOutParameter(1, java.sql.Types.VARCHAR);
   �tatAppelable.setString(2,"F-GLFS");
   
   System.out.println("Avant appel ");   
 
   �tatAppelable.execute();
   System.out.println("Nom de la compagnie de F-GLFS : "+�tatAppelable.getString(1));   
 
   �tatAppelable.close(); 
   cx.close(); 
}
catch(SQLException ex){
	System.out.println("Erreur  \n");
	while ((ex != null))
	{
	System.out.println("\nStatut SQL : "+ ex.getSQLState());
	System.out.println("\nMessage : "+ ex.getMessage());
	System.out.println("\nCode Erreur: "+ ex.getErrorCode());
	ex = ex.getNextException();
    } } } }
