import java.sql.*;
import oracle.jdbc.driver.*;

class PrepareINSERT
{  
public static void main (String args []) throws SQLException
{  
try{
 DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
 Connection cx = DriverManager.getConnection("jdbc:oracle:thin:@CAMPAROLS:1521:BDSoutou","soutou","ingres");
 
 String ordreSQL = "INSERT INTO Avion VALUES (?, ?, ?, ?)";
 PreparedStatement �tatPr�par� = cx.prepareStatement(ordreSQL);
 
 �tatPr�par�.setString(1, "F-NEW");
 �tatPr�par�.setString(2, "A319");
  �tatPr�par�.setInt(3, 178);
 �tatPr�par�.setString(4, "AF");
 System.out.print(�tatPr�par�.executeUpdate()+" avion ins�r�.");  
 
 }
catch(SQLException ex){
	System.out.println("Erreur  \n");
	while ((ex != null))
	{
	System.out.println("\nStatut SQL : "+ ex.getSQLState());
	System.out.println("\nMessage : "+ ex.getMessage());
	System.out.println("\nCode Erreur: "+ ex.getErrorCode());
	ex = ex.getNextException();
    } } } }
