import java.sql.*;
import oracle.jdbc.driver.*;

class PrepareSELECT
{  
public static void main (String args []) throws SQLException
{  
try{
 DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
 Connection cx = DriverManager.getConnection("jdbc:oracle:thin:@CAMPAROLS:1521:BDSoutou","soutou","ingres");

 String ordreSQL = "SELECT immat, typeAvion, cap FROM Avion";
 PreparedStatement �tatPr�par� = cx.prepareStatement(ordreSQL);
  
 ResultSet curseurJava = �tatPr�par�.executeQuery();
 
 System.out.println("Liste des avions");   
 
  while(curseurJava.next()) 
    {
	 System.out.print("Immat: "+curseurJava.getString(1));    
	 System.out.println(" type : "+curseurJava.getString(2));
    }
   
   curseurJava.close(); 

}
catch(SQLException ex){
	System.out.println("Erreur  \n");
	while ((ex != null))
	{
	System.out.println("\nStatut SQL : "+ ex.getSQLState());
	System.out.println("\nMessage : "+ ex.getMessage());
	System.out.println("\nCode Erreur: "+ ex.getErrorCode());
	ex = ex.getNextException();
    } } } }
