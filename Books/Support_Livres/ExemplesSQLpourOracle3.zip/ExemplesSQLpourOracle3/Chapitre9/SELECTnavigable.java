import java.sql.*;
import oracle.jdbc.driver.*;

class SELECTnavigable
{  
public static void main (String args []) throws SQLException
{  
try{
 DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
 Connection cx = DriverManager.getConnection("jdbc:oracle:thin:@CAMPAROLS:1521:BDSoutou","soutou","ingres");

 Statement etatSimple = 
     cx.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
 
 ResultSet curseurNaviJava = 
     etatSimple.executeQuery("SELECT immat,typeAvion,cap FROM Avion");
 
 System.out.println("Liste des avions");   
 
 if ( curseurNaviJava.isBeforeFirst() ) System.out.println("Curseur positionn� au d�but"); 
 if ( curseurNaviJava.isFirst() ) System.out.println("Curseur positionn� sur le 1er d�j�");

  while(curseurNaviJava.next()) 
    {
     if ( curseurNaviJava.isFirst() ) System.out.println("1er avion : "); 
     if ( curseurNaviJava.isLast() )  System.out.println("Dernier avion : ");  
	 System.out.print("Immat: "+curseurNaviJava.getString(1));    
	 System.out.println(" type : "+curseurNaviJava.getString(2));
    }
   if ( curseurNaviJava.isAfterLast() ) System.out.println("Curseur positionn� apr�s la fin"); 
   
   if ( curseurNaviJava.previous() ) 
     if ( curseurNaviJava.previous() ) 
     	{System.out.println("Avant dernier avion : "+curseurNaviJava.getString(1));}	
   
   if ( curseurNaviJava.first() ) 
	     {System.out.println("First avion : "+curseurNaviJava.getString(1));}	
         
   if ( curseurNaviJava.last() ) 
	     {System.out.println("Last avion : "+curseurNaviJava.getString(1));}	
         
   curseurNaviJava.close(); 

}
catch(SQLException ex){
	System.out.println("Erreur  \n");
	while ((ex != null))
	{
	System.out.println("\nStatut SQL : "+ ex.getSQLState());
	System.out.println("\nMessage : "+ ex.getMessage());
	System.out.println("\nCode Erreur: "+ ex.getErrorCode());
	ex = ex.getNextException();
    } } } }
