import java.sql.*;
import oracle.jdbc.driver.*;

class JDBCOCI
{  
public static void main (String args []) throws SQLException
{  
String chaineCx = "jdbc:oracle:oci:@CXBDSOUTOU";
try{
DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
Connection conn = DriverManager.getConnection (chaineCx,"scott", "tiger");
Statement stmt = conn.createStatement ();

ResultSet rset = stmt.executeQuery ("SELECT SYSDATE FROM DUAL");    
while (rset.next ())
   System.out.println ("Nous sommes le : "+rset.getString (1));
System.out.println ("JDBC correctement configur�");

}
catch(SQLException ex){
	System.out.println("Erreur connexion \n");
	while ((ex != null))
	{
	System.out.println("\nStatut SQL : "+ ex.getSQLState());
	System.out.println("\nMessage : "+ ex.getMessage());
	System.out.println("\nCode Erreur: "+ ex.getErrorCode());
	ex = ex.getNextException();
    } } } }
