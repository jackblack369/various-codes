import java.sql.*;
import oracle.jdbc.driver.*;

class JDBCTest
{  
public static void main (String args []) throws SQLException
{  
try{
	DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
	Connection conn = DriverManager.getConnection
		("jdbc:oracle:thin:@CAMPAROLS:1521:BDSoutou","scott", "tger");
	Statement stmt = conn.createStatement ();

	ResultSet rset = stmt.executeQuery ("SELECT SYSDATE FROM DUAL");    
	while (rset.next ())
   		System.out.println ("Nous sommes le : "+rset.getString (1));
	System.out.println ("JDBC correctement configur�");}
catch(SQLException ex){	System.err.println("Erreur : "+ex);} } }
