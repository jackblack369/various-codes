import java.sql.*;
import oracle.jdbc.driver.*;

class Etats
{  
public static void main (String args []) throws SQLException
{  
try{
 DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
 Connection cx = DriverManager.getConnection("jdbc:oracle:thin:@CAMPAROLS:1521:BDSoutou","soutou","ingres");

 Statement etatSimple = cx.createStatement();
 etatSimple.execute("CREATE TABLE Compagnie(comp VARCHAR(4),nomComp VARCHAR(30), CONSTRAINT pk_Compagnie PRIMARY KEY(comp))");
  
 int j = etatSimple.executeUpdate("CREATE TABLE Avion (immat VARCHAR(6),typeAvion VARCHAR(15), cap NUMBER(3), compa VARCHAR(4),"+
     "CONSTRAINT pk_Avion PRIMARY KEY(immat), CONSTRAINT fk_Avion_comp_Compagnie"+
     "   FOREIGN KEY(compa) REFERENCES Compagnie(comp))");
 System.out.println ("Nombre de lignes concern�es = "+j);
 
 int k = etatSimple.executeUpdate("INSERT INTO Compagnie VALUES ('AF','Air France')");
 System.out.println ("Nombre de lignes concern�es = "+k);
 
 etatSimple.execute("INSERT INTO Avion VALUES ('F-WTSS','Concorde',90,'AF')");
 etatSimple.execute("INSERT INTO Avion VALUES ('F-FGFB','A320',148,   'AF')");

 
 etatSimple.setMaxRows(10);
 ResultSet curseurJava = etatSimple.executeQuery("SELECT * FROM Avion");    
 
 while (curseurJava.next ())
   System.out.println ("Immat : "+curseurJava.getString(1));

  etatSimple.execute("DELETE FROM Avion"); 
  int l = etatSimple.getUpdateCount();
  System.out.println(l+" avions d�truits.");
  
  System.out.println ("Fin OK");
}
catch(SQLException ex){
	System.out.println("Erreur  \n");
	while ((ex != null))
	{
	System.out.println("\nStatut SQL : "+ ex.getSQLState());
	System.out.println("\nMessage : "+ ex.getMessage());
	System.out.println("\nCode Erreur: "+ ex.getErrorCode());
	ex = ex.getNextException();
    } } } }
