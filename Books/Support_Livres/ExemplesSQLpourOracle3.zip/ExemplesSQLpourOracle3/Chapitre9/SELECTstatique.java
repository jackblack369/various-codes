import java.sql.*;
import oracle.jdbc.driver.*;

class SELECTstatique
{  
public static void main (String args []) throws SQLException
{  
try{
 DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
 Connection cx = DriverManager.getConnection("jdbc:oracle:thin:@CAMPAROLS:1521:BDSoutou","soutou","ingres");

 Statement etatSimple = cx.createStatement();
 
 ResultSet curseurJava = 
     etatSimple.executeQuery("SELECT immat,cap FROM Avion WHERE comp = (SELECT comp FROM Compagnie WHERE nomComp='Air France')");
 
 System.out.println("Liste des avions d'Air France");   
 float moyenneCapacit� =0;
 int nbAvions = 0;
 while (curseurJava.next ())
 {
   System.out.print ("Immat : "+curseurJava.getString(1));
   System.out.println ("\tCapacit� : "+curseurJava.getInt(2));
   moyenneCapacit� += curseurJava.getInt(2);
   nbAvions ++;
 }
 moyenneCapacit� /= nbAvions;
 System.out.println("Moyenne des capacit� : "+moyenneCapacit�); 
 curseurJava.close();
}
catch(SQLException ex){
	System.out.println("Erreur  \n");
	while ((ex != null))
	{
	System.out.println("\nStatut SQL : "+ ex.getSQLState());
	System.out.println("\nMessage : "+ ex.getMessage());
	System.out.println("\nCode Erreur: "+ ex.getErrorCode());
	ex = ex.getNextException();
    } } } }
