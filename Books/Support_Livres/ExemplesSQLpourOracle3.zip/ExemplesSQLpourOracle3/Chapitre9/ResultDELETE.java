import java.sql.*;
import oracle.jdbc.driver.*;

class ResultDELETE
{  
public static void main (String args []) throws SQLException
{  
try{
 DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
 Connection cx = DriverManager.getConnection("jdbc:oracle:thin:@CAMPAROLS:1521:BDSoutou","soutou","ingres");


 
 Statement etatSimple = 
     cx.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
 
 ResultSet curseurModifJava = 
     etatSimple.executeQuery("SELECT immat,typeAvion,cap FROM Avion");

  cx.setAutoCommit(false);
    
  if (curseurModifJava.absolute(3)) // acc�s au 3�me
 { 
   System.out.println("Immat � supprimer :  "+curseurModifJava.getString(1));
   curseurModifJava.deleteRow();
   cx.commit();
   System.out.println("Supprim� au niveau de la base.");
  }
   else 
   System.out.println("Pas de 3�me avion!");
 
 //Parcours
 curseurModifJava.beforeFirst();
    while(curseurModifJava.next()) 
    {
      System.out.print("Immat: "+curseurModifJava.getString(1));    
	 System.out.println(" type : "+curseurModifJava.getString(2));
    }    

  curseurModifJava.close(); 
}
catch(SQLException ex){
	System.out.println("Erreur  \n");
	while ((ex != null))
	{
	System.out.println("\nStatut SQL : "+ ex.getSQLState());
	System.out.println("\nMessage : "+ ex.getMessage());
	System.out.println("\nCode Erreur: "+ ex.getErrorCode());
	ex = ex.getNextException();
    } } } }
