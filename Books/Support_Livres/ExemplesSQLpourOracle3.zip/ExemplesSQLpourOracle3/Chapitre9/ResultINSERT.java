import java.sql.*;
import oracle.jdbc.driver.*;

class ResultINSERT
{  
public static void main (String args []) throws SQLException
{  
try{
 DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
 Connection cx = DriverManager.getConnection("jdbc:oracle:thin:@CAMPAROLS:1521:BDSoutou","soutou","ingres");

 Statement etatSimple = 
     cx.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
 
 ResultSet curseurModifJava = 
     etatSimple.executeQuery("SELECT immat,typeAvion,cap FROM Avion");

  cx.setAutoCommit(false);
  
  //premi�re �tape
  curseurModifJava.moveToInsertRow();
    //deuxi�me �tape 
  curseurModifJava.updateString(1,"F-LUTE");
    curseurModifJava.updateString(2,"TB20");
   curseurModifJava.updateInt(3,4);
   //3eme  �tape
   curseurModifJava.insertRow();
   cx.commit();
   System.out.println("Ins�r� au niveau de la base.");
 
  
 //Parcours mais le dernier avion n'appara�t pas : NORMAL
 curseurModifJava.beforeFirst();
    while(curseurModifJava.next()) 
    {
      System.out.print("Immat: "+curseurModifJava.getString(1));    
	 System.out.println(" type : "+curseurModifJava.getString(2));
	 System.out.println(" capacit� : "+curseurModifJava.getInt(3));}    

  curseurModifJava.close(); 
}
catch(SQLException ex){
	System.out.println("Erreur  \n");
	while ((ex != null))
	{
	System.out.println("\nStatut SQL : "+ ex.getSQLState());
	System.out.println("\nMessage : "+ ex.getMessage());
	System.out.println("\nCode Erreur: "+ ex.getErrorCode());
	ex = ex.getNextException();
    } } } }
