import java.sql.*;
import oracle.jdbc.driver.*;

class Exceptions2
{  
public static void main (String args []) throws SQLException
{  
String ordreSQL = "INSERT INTO Avion VALUES ('F-A0','A319', 148, 'NEW')"; 
try
{
 DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
 Connection cx = DriverManager.getConnection("jdbc:oracle:thin:@CAMPAROLS:1521:BDSoutou","soutou","ingres");
 cx.setAutoCommit(false); 
 PreparedStatement �tatPr�par� = cx.prepareStatement(ordreSQL);
 System.out.println(�tatPr�par�.executeUpdate() + " avion ins�r�.");   
 cx.commit(); 
 cx.close(); 
}
catch(SQLException ex)
{
 if (ex.getErrorCode() == 1)  System.out.println("Avion d�j� existant!");   
 else if (ex.getErrorCode() == 913) System.out.println("Trop de valeurs!");
 else if (ex.getErrorCode() == 942) System.out.println("Nom de table inconnue!");
 else if (ex.getErrorCode() == 947) System.out.println("Manque de valeurs!");   
 else if (ex.getErrorCode() == 1401)       System.out.println("Valeur trop longue!");   
 else if (ex.getErrorCode() == 1438)       System.out.println("Valeur trop importante!");   
 else if (ex.getErrorCode() == 2291)      
  try { System.out.println("Compagnie inconnue, on ins�re!");
       Connection cx = DriverManager.getConnection("jdbc:oracle:thin:@CAMPAROLS:1521:BDSoutou","soutou","ingres");
       cx.setAutoCommit(false); 
       String ordreSQL2 = "INSERT INTO Compagnie VALUES ('NEW','Nouvelle Compagnie')";
       PreparedStatement �tatPr�par�2 = cx.prepareStatement(ordreSQL2);
       System.out.println(�tatPr�par�2.executeUpdate() + " compagnie ins�r�e.");
       �tatPr�par�2 = cx.prepareStatement(ordreSQL);
       System.out.println(�tatPr�par�2.executeUpdate() + " avion ins�r�.");  
       cx.commit(); 
       cx.close();  
      } 
  catch (SQLException e) {System.err.println("Erreur : " + e); }       
} } } 
