


DROP TABLE Avion;
DROP TABLE Compagnie;

CREATE TABLE Compagnie
	(comp VARCHAR(4), nomComp VARCHAR(25),
 	CONSTRAINT pk_Compagnie PRIMARY KEY(comp));

CREATE TABLE Avion (immat CHAR(6), typeAvion VARCHAR(15), cap NUMBER(3), 
comp VARCHAR(4) REFERENCES Compagnie(comp), CONSTRAINT pk_Avion PRIMARY KEY(immat)) ;


INSERT INTO Compagnie VALUES ('AF', 'Air France');
INSERT INTO Compagnie VALUES ('TAT', 'Transport Air Tour');
INSERT INTO Compagnie VALUES ('AERI', 'Air Aeris Tlse');

INSERT INTO Avion VALUES ('F-WTSS', 'Concorde', 90, 'AF');
INSERT INTO Avion VALUES ('F-FGFB', 'Concorde', 95, 'AF');
INSERT INTO Avion VALUES ('F-GLFS', 'A320', 140, 'TAT');
INSERT INTO Avion VALUES ('F-GLKT', 'A340', 300, 'AERI');
INSERT INTO Avion VALUES ('F-GKUB', 'A330', 240, 'AERI');
INSERT INTO Avion VALUES ('F-GLZV', 'A330', 250, 'AERI');
INSERT INTO Avion VALUES ('F-GLDX', 'A319', 150, 'AERI');
COMMIT;

SELECT * FROM Avion;
SELECT * FROM Compagnie ;
----

 

