public class PremierExemple {
	public static String affiche(String message) 
	{int nc=0;
	for (int i=0;i<message.length();i++)
			if (((message.charAt(i)>='a')&&(message.charAt(i)<='z'))
			|| ((message.charAt(i)>='A')&&(message.charAt(i)<='Z')))
				nc++;
	return "Le message contient "+nc+" lettres!";}}
 