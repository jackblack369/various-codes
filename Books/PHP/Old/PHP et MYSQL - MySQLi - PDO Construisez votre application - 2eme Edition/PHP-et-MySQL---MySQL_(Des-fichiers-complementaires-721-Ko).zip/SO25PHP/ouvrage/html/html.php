<html>
<head>
<title>1ere exemple</title>
</head>
<body>
<?php
echo "Bonjour, tout le monde";
?>
</body>
</html>

