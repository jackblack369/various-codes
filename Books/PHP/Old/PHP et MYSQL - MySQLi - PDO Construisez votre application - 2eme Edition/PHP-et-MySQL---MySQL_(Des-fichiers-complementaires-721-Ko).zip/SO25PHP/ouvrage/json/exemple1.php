<?php
$arr = array (
		'a'=>'Les editions ENI',
		'b'=>'Christophe Villeneuve',
		'c'=>'2007-2010');

echo json_encode($arr);
?>
