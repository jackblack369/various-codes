<?php 
echo realpath('chemin.php'); 
?>