<?php
$a = 1+1;
echo "a : $a<br>";

$d = 5;
$d = $d + $a;
echo "d : $d<br>";;

$c = 5;
$c += $a;
echo "c : $c<br>";

?>
