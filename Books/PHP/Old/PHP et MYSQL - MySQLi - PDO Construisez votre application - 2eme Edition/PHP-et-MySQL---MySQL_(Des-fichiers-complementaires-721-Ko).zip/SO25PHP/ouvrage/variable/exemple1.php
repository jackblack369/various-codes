<?php
$a="Editions";
$b="ENI";

echo "$a<br>";
echo "$b<br>";
echo "$a $b<br>";


$c=$a." ".$b;
echo "$c<br>";
?>