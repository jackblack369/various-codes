<html> 
<body> 
<form action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>"> 
<input type="text" name="exemple" value="reussi" /> 
<input type="submit" value="Submit" /> 
</form> 
</body> 
</html> 