<?php
$exemple="Editions ENI";
echo $exemple."<br />";

echo md5($exemple)."<br />";
?>
