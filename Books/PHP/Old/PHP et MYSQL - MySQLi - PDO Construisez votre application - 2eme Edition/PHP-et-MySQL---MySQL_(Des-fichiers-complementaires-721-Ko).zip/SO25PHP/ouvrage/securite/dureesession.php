<?php
session_start();

$_SESSION['dernier_passage']=time(); 
$_SESSION['duree']=5 * 60; 

?>
