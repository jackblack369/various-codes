<?php
$titre="Un petit exemple <script>alert ('Editions ENI')</script>";

echo htmlentities($titre)."<br>";
 
?>
