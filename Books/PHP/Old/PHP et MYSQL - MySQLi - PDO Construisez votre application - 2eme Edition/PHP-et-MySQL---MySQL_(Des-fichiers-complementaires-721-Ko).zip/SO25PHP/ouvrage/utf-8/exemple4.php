<?php
$chaine="Les �ditions ENI : Caract�res accept�s ";
echo $chaine."<br>";


$chaine_encoder=utf8_encode($chaine);
echo $chaine_encoder."<br>";

?>