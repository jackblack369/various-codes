<?php

echo "Caract�res accept�s :".$_SERVER['HTTP_ACCEPT_CHARSET']."<br>";

?>