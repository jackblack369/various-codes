<?php
$message="Bonjour";
echo "<a href=exemple4-resultat.php?message=$message> Cliquer ici</a>"
?>