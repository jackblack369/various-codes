<?php
echo "Nous sommes le : ";

setlocale (LC_TIME, "fr_FR");
echo strftime("%d-%m-%Y");


?>

