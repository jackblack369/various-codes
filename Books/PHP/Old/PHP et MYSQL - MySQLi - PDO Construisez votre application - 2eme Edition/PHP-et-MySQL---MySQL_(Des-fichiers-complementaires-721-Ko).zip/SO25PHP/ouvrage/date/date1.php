<?php
echo "Nous sommes le : ";
echo DATE("d-m-Y");
?>
