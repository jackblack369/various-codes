<?php
echo "Nous sommes le : ".DATE("d-m-Y")."<br>";
echo "Il est ".DATE("l H \h i")." et ".DATE ("s")." secondes<br>";
?>