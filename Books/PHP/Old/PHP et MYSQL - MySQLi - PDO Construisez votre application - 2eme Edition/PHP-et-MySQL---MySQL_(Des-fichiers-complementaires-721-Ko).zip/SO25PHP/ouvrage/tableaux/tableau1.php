<?php
$tableau = array( 4, 1, 1, 1,  1, 8=>1,  4=>1, 19, 3=>13);
print_r ($tableau);
/*echo "<br>";
echo  $tableau[4];*/
?>

