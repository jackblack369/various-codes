<?php
echo "Frame : Partie en haut de l'ecran";
?>