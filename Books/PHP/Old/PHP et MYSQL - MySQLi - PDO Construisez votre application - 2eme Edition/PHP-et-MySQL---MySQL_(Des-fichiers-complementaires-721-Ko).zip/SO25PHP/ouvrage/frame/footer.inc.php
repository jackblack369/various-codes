<?php
echo "Frame : Partie en bas de l'ecran";
?>