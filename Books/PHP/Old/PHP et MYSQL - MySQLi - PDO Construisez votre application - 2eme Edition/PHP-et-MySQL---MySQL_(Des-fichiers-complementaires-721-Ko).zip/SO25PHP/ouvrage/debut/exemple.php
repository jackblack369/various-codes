<html>
<head>
</head>
<body>
<?php
echo "Bonjour, tout le monde";
?>
</body>
</html>
