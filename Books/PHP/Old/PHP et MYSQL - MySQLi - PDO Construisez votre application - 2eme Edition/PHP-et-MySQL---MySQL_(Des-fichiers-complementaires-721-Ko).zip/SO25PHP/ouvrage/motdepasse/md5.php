<?php
$exemple="Editions ENI2007";
echo md5($exemple)."<br />";
?>
