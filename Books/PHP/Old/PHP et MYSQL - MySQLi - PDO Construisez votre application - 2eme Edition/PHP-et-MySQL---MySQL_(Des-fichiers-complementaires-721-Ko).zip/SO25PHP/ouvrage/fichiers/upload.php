<html>
<body>
<form enctype="multipart/form-data" action="upload_execution.php"  method="POST">
<input type="hidden" name="MAX_FILE_SIZE" value="500000" >
Choisir un fichier : <input name="fichier" type="file" >
<input type="submit" name="action" value="Envoi" >
</form>
</body>
</html>