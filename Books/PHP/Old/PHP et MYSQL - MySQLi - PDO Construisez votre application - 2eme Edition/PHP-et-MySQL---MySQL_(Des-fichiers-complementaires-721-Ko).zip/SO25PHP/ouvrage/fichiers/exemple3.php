<?php
$texte1="Bonjour des Editions ENI";

$fichier =  file_put_contents('exemple2.txt',$texte1);

?> 