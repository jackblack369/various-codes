<?php
     $fichier = file_get_contents('exemple2.txt');

     echo $fichier;
?> 