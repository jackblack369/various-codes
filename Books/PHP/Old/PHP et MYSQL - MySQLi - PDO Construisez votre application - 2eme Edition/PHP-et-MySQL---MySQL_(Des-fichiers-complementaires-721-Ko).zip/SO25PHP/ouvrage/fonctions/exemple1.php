<?php
function retourne_message ($text)
{
	return $text;
}

echo retourne_message ("Bonjour");
?>