<?php 
echo "</td></tr>";

echo "<tr><td colspan=2 align=center>";
echo "(c) Hello-Design";
echo "</td></tr>";
echo "</table>";
?>
