<?php 
$menu="carnet"; 
require_once ("head.inc.php");
echo "Fichier Rubrique";
require_once ("footer.inc.php");
?>
