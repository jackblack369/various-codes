<?php
require_once "head.inc.php";
?>
<html>
<body>
<center><br>Feuille index</center>
</body>
</html>
<?php require "footer.inc.php"; ?>