<?php
$a="Edition ENI";
$b="hello";

if ($a == "Edition ENI" && $b=="hello")
{
	echo "Vrai";
}
else
{
	echo "Faux";
}

?>