<?php
$a="Edition ENI";

if ($a == "Edition ENI")
{
	echo "Vrai";
}
else
{
	echo "Faux";
}

?>