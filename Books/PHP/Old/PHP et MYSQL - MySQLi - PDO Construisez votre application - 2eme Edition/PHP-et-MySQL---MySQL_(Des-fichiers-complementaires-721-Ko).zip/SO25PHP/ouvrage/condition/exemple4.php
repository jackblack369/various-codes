<?php
$tranche=2;

switch ($tranche)
{
case 0:	echo "Tranche 0<br>"; break;
case 1: echo "Tranche 1<br>"; break;
case 2:	echo "Tranche 2<br>"; break;
case 3:	echo "Tranche 3<br>"; break;
case 4: echo "Tranche 4<br>"; break;
case 5: echo "Tranche 5<br>"; break;
case 6:	echo "Tranche 6<br>"; break;
case 7:	echo "Tranche 7<br>"; break;
case 8:	echo "Tranche 8<br>"; break;
case 9: echo "Tranche 9<br>"; break;

default:
	echo "Hors tranche";
break;
}


?>
