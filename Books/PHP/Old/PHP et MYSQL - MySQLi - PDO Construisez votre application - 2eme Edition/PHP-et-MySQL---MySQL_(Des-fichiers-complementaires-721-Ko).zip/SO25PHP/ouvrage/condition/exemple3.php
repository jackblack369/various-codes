<?php
$tranche=2;

if ($tranche<=0)
	echo "Tranche 0<br>";
elseif ($tranche==1)
	echo "Tranche 1<br>";
elseif ($tranche==2)
	echo "Tranche 2<br>";
elseif ($tranche==3)
	echo "Tranche 3<br>";
elseif ($tranche==4)
	echo "Tranche 4<br>";
elseif ($tranche==5)
	echo "Tranche 5<br>";
elseif ($tranche==6)
	echo "Tranche 6<br>";
elseif ($tranche==7)
	echo "Tranche 7<br>";
elseif ($tranche==8)
	echo "Tranche 8<br>";
elseif ($tranche==9)
	echo "Tranche 9<br>";
else
	echo "Hors tranche<br>";
?>
