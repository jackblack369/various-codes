<?php

echo "Serveur ip : ".$_SERVER['SERVER_ADDR']."<br>";

?>
