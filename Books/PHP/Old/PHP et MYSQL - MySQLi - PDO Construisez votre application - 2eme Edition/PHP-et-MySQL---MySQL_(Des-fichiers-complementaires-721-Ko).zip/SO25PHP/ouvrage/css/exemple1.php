<?php
echo "<link rel='stylesheet' href='css.css' type='text/css'>";

echo "<span class=texte>";
echo "Bonjour, tout le monde";
echo "</span>";
?>
