<?php
require_once('lib-namespace.php');


ESPACEdeNOM\nom();
echo "<br />";
ESPACEdeNOM\prenom();

?>