<?php
namespace ESPACEdeNOM;


function nom() {
    echo 'ESPACEdeNOM\nom';
}
 
function prenom() {
    echo 'ESPACEdeNOM\prenom';
}
?>