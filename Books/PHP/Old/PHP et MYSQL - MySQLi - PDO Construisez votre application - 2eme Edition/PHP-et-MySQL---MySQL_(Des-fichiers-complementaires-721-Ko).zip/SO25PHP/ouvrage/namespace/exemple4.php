<?php
require_once('lib-namespace4.php');

$row = new ESPACEdeNOM\MaClasse;
echo $row->position(); 
unset ($row);

?>