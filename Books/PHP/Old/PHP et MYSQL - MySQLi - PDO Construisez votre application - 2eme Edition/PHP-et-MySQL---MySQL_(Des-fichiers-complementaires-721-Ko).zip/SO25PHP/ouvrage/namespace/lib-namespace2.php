<?php

namespace PRODUIT;

function nom() 
{
    echo 'PRODUIT\nom';
}
?>