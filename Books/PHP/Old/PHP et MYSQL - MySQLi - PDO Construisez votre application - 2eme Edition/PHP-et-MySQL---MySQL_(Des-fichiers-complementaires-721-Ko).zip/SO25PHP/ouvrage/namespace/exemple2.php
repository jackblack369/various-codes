<?php
require_once('lib-namespace.php');
require_once('lib-namespace2.php');


ESPACEdeNOM\nom();
echo "<br />";
PRODUIT\nom();

?>