<?php
require_once('lib-namespace3.php');

$row = new ESPACEdeNOM\MaClasse;
$row->afficheNom(); 
unset ($row);

?>