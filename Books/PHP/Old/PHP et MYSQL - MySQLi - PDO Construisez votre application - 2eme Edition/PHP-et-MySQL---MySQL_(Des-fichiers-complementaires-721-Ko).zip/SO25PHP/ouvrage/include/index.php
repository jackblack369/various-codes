<?php
include "page.php";
?>