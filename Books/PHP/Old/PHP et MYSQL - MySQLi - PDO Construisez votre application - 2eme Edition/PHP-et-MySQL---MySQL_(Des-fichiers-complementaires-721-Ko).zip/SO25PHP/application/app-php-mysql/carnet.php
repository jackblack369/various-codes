<?php $menu="carnet";
require_once "include/config.inc.php";
?>
<?php require_once "head.inc.php"; ?>

<html>
<body>
S�lectionner un menu de la partie Carnet
</body>
</html>
<?php require_once "footer.inc.php"; ?>