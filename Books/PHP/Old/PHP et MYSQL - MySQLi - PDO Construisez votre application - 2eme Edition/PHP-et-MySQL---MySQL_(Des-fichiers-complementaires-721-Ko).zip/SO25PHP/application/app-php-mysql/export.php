<?php $menu="export";
require_once "include/config.inc.php";
?>
<?php require_once "head.inc.php"; ?>

S�lectionner un menu de la partie Exportation

<?php require_once "footer.inc.php"; ?>