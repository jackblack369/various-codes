<?php
$serveur = "localhost";
$user    = "root";
$passwd  = "";
$bdd     = "eni";

?>