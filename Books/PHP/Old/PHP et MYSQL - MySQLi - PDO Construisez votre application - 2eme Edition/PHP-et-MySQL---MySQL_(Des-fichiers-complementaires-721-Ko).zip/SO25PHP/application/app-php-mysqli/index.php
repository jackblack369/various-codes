<?php session_start(); ?>
<html>
<head></head>
<body>
<?php require_once "head.inc.php"; ?>
<center><h1> 
APM <br><br>
    <i>Application Php Mysqli</i><br> 
</h1>
</center>
<?php require_once "footer.inc.php"; ?>
</body>
</html>
