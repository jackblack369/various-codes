<?php session_start(); ?>
<html>
<head></head>
<body>
<?php require_once "head.inc.php"; ?>
<center><h1>
Application r�alis�e par : <br>
Christophe Villeneuve
Alias Hello<br>
<br><br>
Editeur : 
Les �ditions ENI
</h1>
</center>
<?php require "footer.inc.php"; ?>
</body>
</html>
