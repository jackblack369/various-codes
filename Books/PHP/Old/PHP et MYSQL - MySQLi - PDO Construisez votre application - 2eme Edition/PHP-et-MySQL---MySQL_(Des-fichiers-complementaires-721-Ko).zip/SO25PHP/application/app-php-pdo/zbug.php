<?php $menu="carnet";
require_once "include/config.inc.php";
?>

