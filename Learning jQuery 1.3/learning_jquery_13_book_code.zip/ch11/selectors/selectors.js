$(document).ready(function() {
  $('div:css(width < 100)').addClass('highlight');
});
