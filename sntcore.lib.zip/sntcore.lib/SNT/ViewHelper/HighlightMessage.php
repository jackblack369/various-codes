<?php
/*
 * Highlight Message View Helper
 * 
 * Uses jQuery UI elements to create a highlighted
 * message.
 * 
 * $type can be 'error' or 'alert'
 */


class SNT_ViewHelper_HighlightMessage extends Zend_View_Helper_Abstract
{
    public function highlightMessage($type = 'error', $messages = array())
    {
    	$html = '';
    	// Make the data an array if it isn't already.
    	$messages = (is_array($messages)) ? $messages : array($messages);
		foreach($messages as $message){
			$html .= '<div class="ui-state-';
			$html .= ($type == 'error') ? $type : 'highlight';
			$html .= ' ui-corner-all">';
			$html .= '<p><span class="ui-icon ui-icon-alert" style="float: left; margin-right: .3em;"></span>';
			$html .= '<strong>Error:</strong>';
			$html .= $message;
			$html .= '</div>';
		}
        return $html;
    }
}
