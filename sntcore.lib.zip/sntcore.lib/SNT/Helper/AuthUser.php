<?php
/*
 * Based upon snippet by neeraj:
 * http://www.zfsnippets.com/snippets/view/id/109
 * 
 * This class requires that a $user public variable is 
 * set on every controller. 
 * 
 * The results of the methods in this class will produce the 
 * following variables in every view:
 * 
 * ->isLoggedInUser	 	// True or False
 * ->user			 	// User object
 * ->error				// String with error message
 * 
 * Add this to your Application/Bootstrap.php to use this helper as a plugin
 * 	public function run()
 *  {
 *		Zend_Controller_Action_HelperBroker::addPrefix('SNT_Helper');
 *		Zend_Controller_Action_HelperBroker::addHelper(new SNT_Helper_AuthUser());
 *       parent::run();
 *   }
 * 
 */

class SNT_Helper_AuthUser extends Zend_Controller_Action_Helper_Abstract
{
	private $userModel			= "Application_Model_User";
	private $userMapper			= "Application_Model_Mapper_UserMapper";
	private $userTable			= "user";
	// These represent the columns in the database used to authorise the user.
	private $userColumn 		= "user_name";
	private $credentialColumn 	= "password";
	// This is the value of the submit button used for logging in.
	private $loginButton 		= "Login";
	
	
    /**
     * Constructor
     *     
     * @return void
     */
    public function __construct()
    {
    }
	
	
    public function preDispatch()
    {		
        if ($this->getRequest()->isPost() && $this->getRequest()->getParam($userColumn) && $this->getRequest()->getParam($loginButton))
		// Only run this if the request is a form, username is set and the form is the login form. 
        {
            $username = $this->getRequest()->getParam($userColumn);
            $password = $this->getRequest()->getParam($credentialColumn);
            
            if ($this->authenticateUser($username, $password)){
                ; 
            }else{
                $this->getActionController()->view->loginformerror = true;
            }
        } 
		if ($this->isLoggedInUser()){
			$session = new Zend_Session_Namespace("auth");
			$this->getActionController()->view->isLoggedInUser = $session->userLoggedIn;
			$this->getActionController()->view->user = $session->user;
		}               
       
    }	
	
	/**
	 * Returns true if user is authenticated as user
	 * @return bool
	 */
    public function isLoggedInUser()
    {
        $session = new Zend_Session_Namespace("auth");
        return (isset($session->userLoggedIn) && $session->userLoggedIn);
    }

    /**
	 *
	 * @param string $user_name - username or email
	 * @param string $password - password
	 * @return bool
	 */
	public function authenticateUser($user_name, $password)
	{
		$auth = Zend_Auth::getInstance();
		
        $db = Zend_Db_Table::getDefaultAdapter();

		$authAdapter = new Zend_Auth_Adapter_DbTable($db, $userTable, $userColumn, $credentialColumn);
		
		// Password is a Sha256 hash of the user's password with their name as a salt.
        $authAdapter->setIdentity($user_name)->setCredential(hash("sha256", $password . $user_name));
		
		$authResult = $auth->authenticate($authAdapter);
		if ($authResult->isValid()){
			//valid username and password
			$userInfo = $authAdapter->getResultRowObject();
            $user = new $userModel((array) $userInfo);
			
			$userMap = new $userMapper();
			
			#$user->last_login = $userMap->updateLogin($user->id);
			
			// Add/Modify this code to your user Mapper to make use of the above line:
			
			// public function updateLogin($id)			// {				// $date = new Zend_Date(); 				// $last_login = $date->toString('YYYY-MM-dd HH:mm:ss');							// $this->save(array(					// 'id' 		=> $id,					// 'last_login' => $last_login					// )				// );				// return $last_login;			// }
			
			
			//save userinfo in session
            $session = new Zend_Session_Namespace("auth");
            $session->userLoggedIn = true;
            $session->userId = $userInfo->id;
            $session->user = (array)$user; // Needs to be an array, or will become an incomplete object.
			
			// Return the user to the controller's user object
			$this->getActionController()->user = $user;  
			$this->getActionController()->view->user = $user;
			$this->getActionController()->view->success = true;         
			return true;
		}else{
			$this->getActionController()->error = "Incorrect username or password.";
			$this->getActionController()->view->error = $this->getActionController()->error;
			return false;
		}
	}
    
	public function logout()
	{
		$auth = Zend_Auth::getInstance();
		$auth->clearIdentity();
        $session = new Zend_Session_Namespace("auth");
        $session->userLoggedIn = false;
        $session->userId = null;
        $session->user = null;        
		Zend_Session::forgetMe();
	}	
	
	
	
	
}