<?php
/**
 * SNT/Model/MapperAbstract.php
 * 	-class SNT_MapperAbstract{}
 * 
 * This model class features some standard methods
 * that can be used within child classes or overloaded
 * for modification. 
 * 
 * Classes that abstract this class need two protected variables:
 * 
 *  protected $dbTableClassName = 'Application_Model_DbTable_xxx';
 *  protected $modelClassName = 'Application_Model_xxx';
 * 
 * These are used to create a DB Table object and 
 * and object of whatever the appropriate model is.
 * 
 * -Alex Winton 02/2012
 */

abstract class SNT_Model_MapperAbstract
{
    protected $dbTable;
    protected $dbTableClassName;
    protected $modelClassName;
    protected $primaryKey;
	
	public function setDbTable($dbTable)
	{
		if (is_string($dbTable)){
			$dbTable = new $dbTable();
		}
		if (!$dbTable instanceof Zend_Db_Table_Abstract){
			throw new Exception('Invalid table data gateway provided');
		}
		$this->dbTable = $dbTable;
		return $this;
	}
	
	public function getDbTable()
	{
		if (null === $this->dbTable){
			$this->setDbTable($this->dbTableClassName);
		}
		return $this->dbTable;
	}
	
	/* 
	 * Save($data)
	 * 
	 * Returns the id of the inserted row. 
	 * Data must be an array where the keys are the column names 
	 */
	
	public function save($data)
	{
		if (null === $data['id'] || $data['id'] == ''){
			unset ($data['id']);
			$id = $this->getDbTable()->insert($data);
			return $id;
		}
		else{
			$this->getDbTable()->update($data,array('id = ?' => $data['id']));
			return $data['id'];
		}
	}
	
	/* 
	 * find($id)
	 * 
	 * Returns an object of $modelClassName with populated data
	 * where the passed $id parameter is matched in the DB.
	 */
	
	public function find($id)
	{
		$result = $this->getDbTable()->find($id);
		if (0 == count($result)){
			return false;
		}
		$row = $result->current();
		#return $row;
		
		$class = $this->modelClassName;
		foreach($row as $k=>$v){
			$data[$k] = $v;
		}
		$object = new $class($data);
		return $object;		
	}
	
	/* 
	 * findBy($field,$search)
	 * 
	 * Returns an object of $modelClassName with populated data
	 * where the passed $field parameter is a column in the DB
	 * and $search is the value to match within that column
	 */	
	
	public function findBy($field,$search)
	{
		$select = $this->getDbTable()->select();
    	$select ->where($field.' = ?', $search);
    	$result = $this->getDbTable()->fetchAll($select);
		
		if (0 == count($result)){
			return false;
		}
	
		$row = $result->current();
		
		$class = $this->modelClassName;
		foreach($row as $k=>$v){
			$data[$k] = $v;
		}
		$object = new $class($data);
		return $object;		
	}	
		
	/* 
	 * delete($id)
	 * 
	 * Returns true if a numeric $id is passed
	 * and the row is deleted.
	 */	
	
	public function delete($id)
	{
		if (isset($id) && is_numeric($id)){
	    	$this->getDbTable()->delete(
	    		array(
	    			'id = ?' => $id
	    		)
	    	);
	    	return true;
    	}
    	else{
    		return false;
    	}
	}		
}