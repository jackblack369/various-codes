<?php 
/**
 * SNT/Model/DbTableAbstract.php
 * 	-class SNT_Model_DbTableAbstract{}
 * 
 * This class should be abstracted only when using
 * a multiple database set up.
 * 
 * DbTable classes that abstract this and aren't using the
 * default adapter will need to add one extra protected var:
 * 
 * protected $_use_adapter = 'altdb';
 * 
 * The name passed to the variable is the name used in config.ini
 *
 * -Alex Winton 05/2012
 */

abstract class SNT_Model_DbTableAbstract extends Zend_Db_Table_Abstract
{
	function SNT_DbTableAbstract($config = null) {
		if (isset ( $this->_use_adapter )) {

			$dbAdapter = Zend_Registry::get ( 'db_'.$this->_use_adapter );
			$config = ($dbAdapter);
		}
		return parent::__construct ( $config );
	}
}

/*
 * These snippets are the other pieces of the puzzle to set up
 * multiple databases.
 * 
*/

/*######################################################################
 * Add this to application/Bootstrap.php
*/

    /**
     * Add databases to the registry
     * 
     * @return void
     */
    // public function _initDbRegistry()    // {        // $this->bootstrap('multidb');        // $multidb = $this->getPluginResource('multidb');        // Zend_Registry::set('db_feedback', $multidb->getDb('feedback'));        // Zend_Registry::set('db_matrix', $multidb->getDb('matrix'));    // }
    
/*######################################################################
 * Add this to application/configs/application.ini
*/
	// ;Default Database Name	// resources.multidb.defaultdb.adapter = PDO_MYSQL	// resources.multidb.defaultdb.host = "localhost"	// resources.multidb.defaultdb.username = ""	// resources.multidb.defaultdb.password = ""	// resources.multidb.defaultdb.dbname = ""	// resources.multidb.defaultdb.isDefaultTableAdapter = true
	
	// ;Alternate Database Name
	// resources.multidb.altdb.adapter = PDO_MYSQL
	// resources.multidb.altdb.host = "localhost"
	// resources.multidb.altdb.username = ""
	// resources.multidb.altdb.password = ""
	// resources.multidb.altdb.dbname = ""
	
	// etc etc etc.
    