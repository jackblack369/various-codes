<?php
/**
 * SNT/Model/ModelAbstract.php
 * 	-class SNT_ModelAbstract{}
 * 
 * This model class features some standard methods
 * that can be used within child classes or overloaded
 * for modification. 
 *
 * -Alex Winton 02/2012
 */

abstract class SNT_Model_ModelAbstract
{
	public function __construct(array $data = null, array $options = null)
    {
    	if (is_array($data)){
    		foreach($data as $k=>$v){
    			if (property_exists($this,$k)){
    				$this->$k = $v;
    			}
    		}
    	}

        if (is_array($options)) {
            $this->setOptions($options);
        }
   }
 
    public function __set($name, $value)
    {
        $method = 'set' . $name;
        if (('mapper' == $name) || !method_exists($this, $method)) {
            throw new Exception("Invalid property ( $name )");
        }
        $this->$method($value);
    }
 
    public function __get($name)
    {
        $method = 'get' . $name;
        if (('mapper' == $name) || !method_exists($this, $method)) {
            throw new Exception("Invalid property ( $name )");
        }
        return $this->$method();
    }
 
    public function setOptions(array $options)
    {
        $methods = get_class_methods($this);
   
        foreach ($options as $key => $value) {
            $method = 'set' . ucfirst($key);
            if (in_array($method, $methods)) {
                $this->$method($value);
            }
        }
        return $this;
    }
    
    
	
}