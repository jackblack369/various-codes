##################################################
Add these to your application.ini config file:

resources.layout.layoutPath = APPLICATION_PATH "../library/Layouts/scripts/"
resources.view.helperPath.SNT_ViewHelper_ = "SNT/ViewHelper"
autoloaderNamespaces.snt = "SNT_"

#################################################
Copy/Merge the contents of the public folder to your root public directory.

