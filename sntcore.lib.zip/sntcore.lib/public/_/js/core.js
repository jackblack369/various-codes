/*###########################
 * Script.js
 *###########################
 * 
 * This is a basic script for loading up certain things
 * in the core library
 * 
 */

// This might be useful, but it will be blank by default.
var baseUrl = "";

// These are the default dialog heights and widths. 
var defaultDialogWidth = 350;
var defaultDialogHeight = 200;

/*************************************************************
 * Explode function
 * Source: http://www.webmasterworld.com/forum91/3262.htm
 * 
 * This can be used to replicate the explode function in PHP.
 */

function explodeArray(item,delimiter) { 
	tempArray=new Array(1); 
	var Count=0; 
	var tempString=new String(item);
	
	while (tempString.indexOf(delimiter)>0) { 
	tempArray[Count]=tempString.substr(0,tempString.indexOf(delimiter)); 
	tempString=tempString.substr(tempString.indexOf(delimiter)+1,tempString.length-tempString.indexOf(delimiter)+1); 
	Count=Count+1 
	}
	
	tempArray[Count]=tempString; 
	return tempArray; 
}


//************************************************************
// Document Ready function

$(function () {
	init();
	// On page load, call the initialisation stuff.
});


//************************************************************
// Initialise upon document load.

function init(){
	
	//##############################################################
	//						Create DataTable
	//##############################################################	
		
	$('.tableList').dataTable({
		"bJQueryUI": true,
		"sPaginationType": "full_numbers"
	});	
	
	
	//##############################################################
	//						 Create Buttons
	//##############################################################
	
	/*
	 * These are some basic button classes based on what's used in Feedback.
	 */
	$(".button_edit")			.button({icons:{primary:"ui-icon-pencil"},	text:false});
	$(".button_delete")			.button({icons:{primary:"ui-icon-trash"},	text:false});
	$(".button_required")		.button({icons:{primary:"ui-icon-notice"},	text:false});
	$(".button_active")			.button({icons:{primary:"ui-icon-check"},	text:false});
	$(".button_inactive")		.button({icons:{primary:"ui-icon-close"},	text:false});
	$(".button_send")			.button({icons:{primary:"ui-icon-mail-open"},text:false});
	$(".button_clone")			.button({icons:{primary:"ui-icon-copy"},	text:false});
	$(".button_lock")			.button({icons:{primary:"ui-icon-locked"},	text:false});
	$(".button_unlock")			.button({icons:{primary:"ui-icon-unlocked"},text:false});
	$(".button_up")				.button({icons:{primary:"ui-icon-triangle-1-n"},text:false});
	$(".button_down")			.button({icons:{primary:"ui-icon-triangle-1-s"},text:false});
	$(".button_left")			.button({icons:{primary:"ui-icon-triangle-1-w"},text:false});
	$(".button_right")			.button({icons:{primary:"ui-icon-triangle-1-e"},text:false});
	
	/*
	 * The .button_link class is used to create a jQuery UI button from an
	 * a href link.
	 */
	$(".button_link")				.button();
	
	/*
	 * The .button_dialog class is used to create a jQuery UI button from an
	 * a href link and open a dialog with the linked page loaded 
	 * through AJAX instead of redirecting.
	 */
	
	$(".button_dialog")				.button();
	
	/*
	 * Automatically turn submit and reset buttons into jQuery UI buttons.
	 */
	
	$("input[type='submit']")	.button();
	$("input[type='reset']")	.button();
	
	/*
	 * Show different icons depending on whether button_checkBox is
	 * checked or not.
	 */

	$(".button_checkBox").each(function(){
		if ($(this).is(':checked')){
			$(this).button({icons: {primary: "ui-icon-minusthick"},text: false});
		}
		else{
			$(this).button({icons: {primary: "ui-icon-plusthick"},text: false});
		}
	});
	
	//##############################################################
	//						Click Buttons
	//##############################################################	
		
	$("a.button_dialog").on("click",function(event){
		event.preventDefault();
		var id 			= $(this).attr('id');
		var css 		= explodeArray($(this).attr('class')," "); 	// Grab the css classes for the object as array.
		var url 		= $(this).attr('href');
		var dialogTitle	= $(this).text();							// Grabs the text within the link tag as a title for dialog.
		var dialogText 	= '';
		$('#dialogWindow').html('<div align="center"><img src="'+baseUrl+'/_/images/ajax-loader.gif"></div>');
		
		var button = this;											// Save the clicked button to a variable.

		// Create the dialog object. 
		$("#dialogWindow").dialog({
			autoOpen: false,
			resizable: false,
			width:  defaultDialogWidth,
			height: defaultDialogHeight,
			title: dialogTitle,
			show: 'clip',
			buttons: {
				"Close": function(){
					$(this).dialog("close");
				}
			}
		});
		
		// Run an AJAX request to grab the content from the url in 'href'
		$.ajax({
			type: 'POST',
			url: url,
			success: function(data){
				$('#dialogWindow').html(data);
			}
		});
		
		// Open the dialog window. 
		$("#dialogWindow").dialog('open');
				
	});
}

//************************************************************
// Tiny MCE Setup

tinyMCE.init({
    // General options
    mode : "textareas",
    elements : "ajaxfilemanager",
    theme : "advanced",
    editor_selector : "mceEditor",
    plugins : "pagebreak,style,layer,table,save,advhr,advimage,advlink,emotions,iespell,inlinepopups,insertdatetime,preview,media,searchreplace,print,contextmenu,paste,directionality,fullscreen,noneditable,visualchars,nonbreaking,xhtmlxtras,template",

    // Theme options
    theme_advanced_buttons1 : "newdocument,|,bold,italic,underline,strikethrough,|,justifyleft,justifycenter,justifyright,justifyfull,|,formatselect,fontselect,fontsizeselect",
    theme_advanced_buttons2 : "cut,copy,paste,pastetext,pasteword,|,search,replace,|,bullist,numlist,|,outdent,indent,blockquote,|,undo,redo,|,link,unlink,anchor,image,cleanup,code,|,insertdate,inserttime,preview,|,forecolor,backcolor",
    theme_advanced_buttons3 : "tablecontrols,|,hr,removeformat,visualaid,|,sub,sup,|,charmap,iespell,ibrowser",
    theme_advanced_toolbar_location : "top",
    theme_advanced_toolbar_align : "left",
    theme_advanced_statusbar_location : "bottom",
    theme_advanced_resizing : true,
    file_browser_callback : "ajaxfilemanager",
    paste_use_dialog : false,
    force_br_newlines : true,
	force_p_newlines : false,	
	relative_urls : false,
	convert_urls : false,
    // Example content CSS (should be your site CSS)
    content_css : baseUrl+"/_/css/core.css"

});

function ajaxfilemanager(field_name, url, type, win) {
	var ajaxfilemanagerurl = baseUrl+"/_/jslib/tiny_mce/plugins/ajaxfilemanager/ajaxfilemanager.php";
	var view = 'detail';
	switch (type) {
		case "image":
		view = 'thumbnail';
			break;
		case "media":
			break;
		case "flash": 
			break;
		case "file":
			break;
		default:
			return false;
	}
	
	tinyMCE.activeEditor.windowManager.open({
	    url: baseUrl+"/_/jslib/tiny_mce/plugins/ajaxfilemanager/ajaxfilemanager.php?view=" + view,
	    width: 782,
	    height: 440,
	    inline : "yes",
	    close_previous : "no"
	},{
	    window : win,
	    input : field_name
	});
}