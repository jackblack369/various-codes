<?php die(); ?>
gc start at 02/May/2012 14:09:28
